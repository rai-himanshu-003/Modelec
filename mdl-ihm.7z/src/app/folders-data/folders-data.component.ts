import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { C3label } from '../models/campaign-list';
import { CampaignNumberService } from '../service/campaign-number.service';
import { HeaderService } from '../service/header.service';

@Component({
  selector: 'app-folders-data',
  templateUrl: './folders-data.component.html',
  styleUrls: ['./folders-data.component.scss']
})
export class FoldersDataComponent implements OnInit {
  val: any[];
  vehSearchRecords: [];
  pages:String="C3"
  campaignValue: string;
  campaignData: any;
  labeltranslation= {} as C3label
  constructor(
    private campaignNumberService: CampaignNumberService,
    private headerService:HeaderService,
    private translate: TranslateService,
    public router: Router) { }

  ngOnInit(): void {
    this.getCampaignLabel();
    this.headerService.notifyObservable.subscribe(res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          this.getCampaignLabel();
        }
      })
    this.storeCampaignCode();
    // this.val = [
    //   { field: 'filedata', header: 'File N°' },
    //   { field: 'folder', header: 'Folder label' },
    // ];
  }

  storeCampaignCode() {
    // Set the value of Vin number in variable
    this.campaignData = window.localStorage.getItem('campaignSearch');

    // If value is not null or undefined then call get data
    if (this.campaignData != null && this.campaignData != undefined) {
      window.localStorage.setItem('campaignData', this.campaignData);
      this.getRecordsFromDB();
    }

  }

  getRecordsFromDB() {

    const campaignNumber: string = window.localStorage.getItem('campaignData');

    if (campaignNumber != null && campaignNumber != undefined) {
      // console.log("vin"+ vinNumber);
      this.campaignValue = campaignNumber;
      console.log(this.campaignValue);
    } else {
      console.log('no Vin found');
    }

    this.campaignNumberService.getRecords(this.campaignValue).subscribe(

      // (data:any) => console.log(data),
      (data: any) => {

        this.vehSearchRecords = data.datalist.folderAreaDTO;
        console.log(this.vehSearchRecords);
      }
    );
  }

  redirectTo(key, value) {
    this.router.navigate(['/vehicle-list', key, value]);
  }

  getCampaignLabel()
  {
  let lang= this.headerService.getlang(); 
  this.headerService.getLabel(lang, this.pages).subscribe(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     console.log(this.labeltranslation)
    });  
  }
}
