import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FoldersDataComponent } from './folders-data.component';

const routes: Routes = [
  {
      path: '',
      component: FoldersDataComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FoldersDataRoutingModule { }
