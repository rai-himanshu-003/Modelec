import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoldersDataComponent } from './folders-data.component';

describe('FoldersDataComponent', () => {
  let component: FoldersDataComponent;
  let fixture: ComponentFixture<FoldersDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoldersDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoldersDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
