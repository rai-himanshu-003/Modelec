import { CampaignManagementModule } from './campaign-management.module';

describe('CampaignManagementModule', () => {
  let campaignManagementModule: CampaignManagementModule;

  beforeEach(() => {
    campaignManagementModule = new CampaignManagementModule();
  });

  it('should create an instance', () => {
    expect(campaignManagementModule).toBeTruthy();
  });
});
