import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
//import { DataService } from '../service/data.service';
import { SelectItem } from 'primeng/api';
import { Router } from '@angular/router';
import { CampaignListDTO, CampaignListLabel } from '../models/campaign-list';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Table } from 'primeng/table';
import { RoutingService } from '../service/routing.service';
import { DataService } from '../service/data.service';
import { TranslateService } from '@ngx-translate/core';
import {HeaderService} from '../service/header.service';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CampaignComponent implements OnInit {

  formData: FormGroup;
  @ViewChild('campaignForm', { static: false }) form: FormControl;
  @ViewChild('dt', { static: false }) table: Table;
  
  item: string;
  localData: any;
  isDataAvailable = false;
  isAvailable = true;

  linked_to_the_program: string;
  vin: string;
  campaign_number: string;
  localProgram: string;
  user_id: string;
  selectedCampaigns1: any[];
  selectedCampaigns2: string;
  value: SelectItem[];
  collapse = false;
  toDate: Date;
  fromDate: Date;

  // pagination variables
  first = 0;
  page: number;
  rows = 10;
  totalNumberRecords: number;
  data: any;

  collapsedVal: boolean = false;

  index: number = null;
  lastIndex = -1;

  dbDetails = {} as CampaignListDTO;
  campaignNature: any;
  campaignStatusOptionOne: any[];
  campaignStatusOptionTwo: any[];

  campListData:any[]=[];
  associatedCampaign: string;
  flagAssociate: boolean;
  programList: string;
  flagValid:boolean;
  natureDropDown: any[];
  role: any;
  createProgBTN : boolean = true;
  impactNumero: string;
  pages="C1";
  labeltranslation= {} as  CampaignListLabel;
  


  constructor(
    private dataService: DataService,
    public router: Router,
    private datePipe: DatePipe,
    private routingService:RoutingService,
    private translate: TranslateService,
    private headerService:HeaderService

  ) {
    

    this.routingService.getValidatedValue().subscribe((value) => {
      this.flagValid = value;
      console.log(this.flagValid,"flagValid")
    });

    this.routingService.getImpactCamp().subscribe((value)=>{
      this.impactNumero=value;
      console.log(this.impactNumero,"this.impactNumero")
    });
    
    this.routingService.getValue().subscribe((value) => {
      this.flagAssociate = value;
      console.log(this.flagAssociate,"flag")
     this.programList= window.localStorage.getItem('associated');
      console.log(this.programList)
      
    });
    this.routingService.getAccessRole().subscribe((value) => {
      console.log(value,"Program Role")
      this.role=value;
      if(this.role.includes('RETOUCHEUR')){
        this.createProgBTN=false;
      }

     
    });
    
   
    this.natureDropDown = [
      { label: 'L', value: 'L' },
      { label: 'C', value: 'C' }
    ];
  }
  // ngAfterViewInit() {
  //   // Set null value to value property for clear the selected item
  //     document.getElementById('btn').onclick = () => {
  //       this.natureDropDown[0].value = null,
  //       this.natureDropDown[1].value = null;
  //     }
  // }
  async ngOnInit() {
    setTimeout(async () => {
      await this.getCampaignLabel();
      this.getCampaignStatus();
      this.getCampaignStatusTwo();
         }, 400);



     // await this.getCampaignLabel();    
     // this.getCampaignStatus();

    if(this.flagAssociate==true){
      this.linked_to_the_program=this.programList;
      this.dbDetails.linkToProgram = this.linked_to_the_program;
      this.getRecordsFromDB(this.dbDetails);
     }
     if(this.impactNumero){
       this.campaign_number = this.impactNumero
      this.dbDetails.campaignNo = this.campaign_number;
      this.getRecordsFromDB(this.dbDetails)
    }
    
  
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getCampaignLabel();
          this.getCampaignStatus();
          this.getCampaignStatusTwo();
        }
      })
  }

getCampaignStatus()
{
      this.campaignStatusOptionOne=[];
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.alim, value: 'ALIM' });
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.initialise, value: 'INITIALISE' });
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.valide, value: 'VALIDE' });
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.invalide, value: 'INVALIDE' });
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.engage, value: 'ENGAGE' });
      this.campaignStatusOptionOne.push({ label: this.labeltranslation.clos, value: 'CLOS' })
    
    if(this.flagValid==true){
      this.selectedCampaigns1=[this.campaignStatusOptionOne[2].value,this.campaignStatusOptionOne[4].value]
      this.linked_to_the_program=this.programList;
      this.dbDetails.linkToProgram = this.linked_to_the_program;
      this.dbDetails.status=this.selectedCampaigns1.toString();
      this.getRecordsFromDB(this.dbDetails);
    }
    else{
     this.selectedCampaigns1=[];
     this.campaignStatusOptionOne.forEach((item) =>
     this.selectedCampaigns1.push(item.value));
     this.selectedCampaigns1.pop();
      console.log("val",this.selectedCampaigns1);
    }
}

getCampaignStatusTwo()
{
  this.campaignStatusOptionTwo=[];
  this.campaignStatusOptionTwo.push({ label: this.labeltranslation.reprendre, value: 'To be taken up again' });
  this.campaignStatusOptionTwo.push({ label: this.labeltranslation.toberefresh, value: 'To be refreshed' });
  this.campaignStatusOptionTwo.push({ label: this.labeltranslation.chantierBlanc, value: 'White campaign' });

}

async getCampaignLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
  
  ngOnDestroy(){
    this.routingService.setValue(false);
    this.routingService.setValidatedValue(false);
    this.routingService.setProgAssociate(null);
    this.routingService.setidGamme(null);
    window.localStorage.removeItem("draftRuleset");
    window.localStorage.removeItem("gammeType");
  }

  createProgram() {
    this.router.navigate(['/campaign-information']);
  }

  createVehicle(_campaign_number, localProgram, user_id, fromDate, toDate, selectedCampaigns1, selectedCampaigns2, vin, _linked_to_the_program) {
    console.log(selectedCampaigns2);

    
    this.dbDetails.campaignNo = this.campaign_number;
    this.localData = localProgram;
    if (this.localData == true) {
      this.localData = 'L';
    }
    else{
      this.localData=null;
    }
    this.dbDetails.campaignNature = this.localData;
    console.log(this.localData);
    this.dbDetails.userCreation = user_id;

    const dateVal = this.datePipe.transform(fromDate, 'yyyy-MM-dd');
    if (dateVal == null) {
      this.dbDetails.fromDate = null;
    } else {
      const newDate = dateVal + 'T00:00:00.000Z';
      this.dbDetails.fromDate = newDate;
    }
    const todateVal = this.datePipe.transform(toDate, 'yyyy-MM-dd');
    if (todateVal == null) {
      this.dbDetails.toDate = null;
    } else {
      const tonewDate = todateVal + 'T00:00:00.000Z';
      this.dbDetails.toDate = tonewDate;
    }
    this.dbDetails.status = null;
    if (selectedCampaigns1) {
      this.dbDetails.status = selectedCampaigns1.toString();
    }
    this.dbDetails.resume = null;
    this.dbDetails.toRefresh = null;
    this.dbDetails.white = null;
    if (selectedCampaigns2) {
      if(this.dbDetails.resume = selectedCampaigns2.includes('To be taken up again')){
        this.dbDetails.resume = true;
      }
      else{
        this.dbDetails.resume =null;
      }
      if(this.dbDetails.toRefresh = selectedCampaigns2.includes('To be refreshed')){
        this.dbDetails.toRefresh = true;
      }
      else{
        this.dbDetails.toRefresh =null;
      }
      if(this.dbDetails.white = selectedCampaigns2.includes('White campaign')){
        this.dbDetails.white = true;
      }
      else{
        this.dbDetails.white =null;
      }
      
    }
    this.dbDetails.vin = vin;
    this.dbDetails.linkToProgram = this.linked_to_the_program;

    this.getRecordsFromDB(this.dbDetails);
    

  }
  
 
  getRecordsFromDB(dbDetails) {
    const totalRecords = true;
    this.dataService.getRecords(this.first, this.rows, totalRecords, JSON.stringify(dbDetails)).subscribe(
      (data: any) => {
       this.campListData=null;
       this.campListData=data.datalist;
        console.log("this.campListData",this.campListData);
        if (data.datalist.responseList) {
          this.collapsedVal = true;
          this.isDataAvailable = true;
          if (this.isDataAvailable == true) {
            this.index = this.lastIndex--;
          }
        }
        this.totalNumberRecords = data.datalist.totalRecords;
        window.localStorage.removeItem('associated');
        console.log(this.programList,"ppp")
      });
      
   }

  
  dateField() { }

   recieveCamplistData($event){
    this.campListData=$event;
  }

}
