export class Pagination<T> {
    responseList: T[];
    pageNumber: number;
    pageSize: number;
    totalRecords: number;
}
