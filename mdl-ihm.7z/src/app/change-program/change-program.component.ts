import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItem, Message, ConfirmationService } from 'primeng/api';
import { Actionlabels } from '../models/breadcrumbsDTO';
import { G4Label } from '../models/problemList';
import { iRangeDetails } from '../models/range-Details';
import { HeaderService } from '../service/header.service';
import { ProgramDetailService } from '../service/program-detail.service';
import { RoutingService } from '../service/routing.service';

@Component({
  selector: 'app-change-program',
  templateUrl: './change-program.component.html',
  styleUrls: ['./change-program.component.scss'],

})
export class ChangeProgramComponent implements OnInit {
  fleet: boolean;
  vnv: boolean;
  validates: string;
  campaigns: string;
  property: string;
  by: string;
  process: string;
  validate: string;
  pLabel: string;
  publish: string;
  textValue: string;
  name: string;
  number: string;
  areaData: any[];
  programsData: iRangeDetails = {} as iRangeDetails;
  nameVal: string;
  created: string;
  released: string;
  textVale: string;
  code: string;
  valField: string;
  items: MenuItem[];
  progSearch:string;
  
  familySelected: { familyLabel: string; codeFamily: string; };
  isEdit: string;
  ruleMessage: string;
  msgs: Message[] = [];
  programType={
    "programType":""
  }
  fromAssociation: string;
  previousUrl: any;
  currentUrl: string;
pages:string="G4"
labeltranslation= {} as G4Label
actionpage="action";
actiontranslation= {} as Actionlabels;

  constructor(
    private route: Router,
    private programDetailService: ProgramDetailService, 
    private translate: TranslateService,
    private routingService:RoutingService,
    private confirmationService: ConfirmationService,
    private headerService:HeaderService
      
  ) { }

  async ngOnInit() {
   await  this.getCampaignLabel();
   await this.getActionLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getCampaignLabel();
          await this.getActionLabel();
          this.getPathName();
        }
      })
    this.previousUrl = this.routingService.getPreviousUrl();
    console.log("edit previous url == ", this.previousUrl);
    
    this.progSearch = window.localStorage.getItem('progSearch');
    this.fromAssociation = window.localStorage.getItem('fromAssociation');
    if(this.progSearch == undefined || this.progSearch == null || this.progSearch == ""){
      this.progSearch = this.fromAssociation;
    }
    this.getPathName();
    this.isEdit = window.localStorage.getItem('isEdit');
    this.fromAssociation = window.localStorage.getItem('fromAssociation');
    if(this.progSearch == undefined || this.progSearch == null || this.progSearch == ""){
      this.progSearch = this.fromAssociation;
    }
    
    if(this.isEdit == "false") {
      this.programDetailService.getSeq().subscribe((data: any) => {
        this.programsData.programNo = data;
      });
    } else {
      this.programDetailService.getProgInfo(this.progSearch).subscribe(
        (data: any) => {
          data.datalist.createdDate = new Date(data.datalist.createdDate as Date);
          let { noOfCampaignsOrder, noOfValidCampaignsOrder, outstandingEditOrder, programLabelOrder, programNoOrder, toDate, updatedDateOrder,
             userModifierOrder, fromDate, includingFamily, linkToCampaign, ...programsData } = data.datalist;
          this.programsData = programsData;

          if (this.previousUrl.includes('/impact')) 
          {  
              this.programsData.definitionValable = window.localStorage.getItem('draftRuleset'); 
          }   
        }
      );
     
    }
    // this.translate.stream(["programType"]).subscribe(value => {
    //   this.programType = value;
    // })
  }
  // Confirm method to show family code required message
  confirmMthd1(type) {
    this.confirmationService.confirm({
      message: this.programType[type]
    });
  }
// method to close confirm box on click of OK
  okMth(){
    this.confirmationService.close();
  }
  

  checkRules() {
    if(this.programsData.type==undefined||this.programsData.type==null||this.programsData.type==''){
      this.confirmMthd1("programType");
    }
    else{
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    this.programDetailService.checkRules(this.programsData).subscribe(
      (data: any) => {
        this.ruleMessage = data.message;
      }
    );
    }
  }

  updateLabel() {
    this.programDetailService.updateLabel(this.programsData).subscribe(
      (_data: any) => {
      }
    )
  }

  saveProgram() {
    if(this.programsData.type==undefined||this.programsData.type==null||this.programsData.type==''){
       this.confirmMthd1("programType");
    }
    else{
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    this.programDetailService.checkRules(this.programsData).subscribe(
      (ruleData: any) => {
        this.ruleMessage = ruleData.message;
        if(ruleData.msg) {
          this.programDetailService.saveProgram(this.programsData).subscribe(
            (programData: any) => {
              if(programData.msg) {
                if(this.isEdit == "true"){
                 this.route.navigate(['/program-list/'+this.progSearch]) 
                }
                else if(this.isEdit == "false"){ 
                  this.msgs.push({severity:'success', summary:'Success', detail:'Program created successfully'});
                  setTimeout(() => {
                    this.route.navigate(['/program-management']);
                  }, 3000);
                 }

              } else {
                this.msgs = [{ severity: 'info', detail: this.labeltranslation.errorComplier }];
              }
            }
          );
        } else {
          this.msgs = [{ severity: 'info', detail: this.labeltranslation.errorComplier }];
        }
      }
    );
    }
  }

  redirectToImpact() {
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    let data = {
      'draftRuleset': this.programsData.definitionValable,
      'gammeType': this.programsData.type
    }
    this.routingService.setImpactDetailsRules(data);
    this.routingService.setImpactRules(data);
    window.localStorage.setItem("draftRuleset",this.programsData.definitionValable);
    window.localStorage.setItem("gammeType",this.programsData.type);
    this.route.navigate(['/impact', this.progSearch, 'VALIDATE_DRAFT_GAMME']);
  }

  saveProgramDraft() {
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    this.programDetailService.saveProgramDraft(this.programsData).subscribe(
      (data: any) => {
        if(data.msg) {
          this.route.navigate(['/program-list/'+this.progSearch]);
        } else {
          this.msgs = [{ severity: 'info', detail: this.labeltranslation.errorComplier }];
        }
      }
    );
  }

  validateProgram() {
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    this.programDetailService.validateProgram(this.programsData).subscribe(
      (data: any) => {
        if(data.msg) {
          this.route.navigate(['/program-list/'+this.progSearch]);
        } else {
          this.redirectToImpact();
        }
      }
    );
  }

  returnValidateVersion() {
    var node = <HTMLInputElement>document.getElementById('regles');
    this.programsData.definitionValable = node.value;
    this.programDetailService.returnValidateVersion(this.programsData).subscribe(
      (data: any) => {
        if(data.msg) {
          this.route.navigate(['/program-list/'+this.progSearch]);
        } else {
          this.msgs = [{ severity: 'info', detail: this.labeltranslation.errorComplier }];
        }
      }
    );
  }

  familySel(famEve) {
    this.familySelected = famEve;
  }

  redirectToAssociate(associated){
    this.routingService.setValue(true);
    if(associated>0){
     window.localStorage.setItem('associated', this.programsData.programNo);
    this.route.navigate(['/campaign-management']);
    }
  }

  redirectToValidate(validate){
   
    if(validate>0){
      this.routingService.setValidatedValue(true);
      this.routingService.setValue(true);
      window.localStorage.setItem('associated', this.programsData.programNo);
    this.route.navigate(['/campaign-management']);
    }
  }

  saveCaretPos() {
    this.programDetailService.saveCaretPos()
  }

  async getCampaignLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.programType.programType = this.labeltranslation.programselect;
     console.log(this.labeltranslation)
    });  
  }
  async getActionLabel()
  {
    let lang= this.headerService.getlang(); 
    await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
      (data: any) => {
       this.actiontranslation = data.datalist.record;
       console.log(this.actiontranslation)
      });  
    }

  getPathName()
  {
       this.items = [
        { label: this.actiontranslation.listeGammes, url: '../program-management' },
        { label: this.actiontranslation.detailGamme+this.progSearch, url: '../program-list/' + this.progSearch },
        { label: this.actiontranslation.editionGamme }
      ];
  }
}
