import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributeAssistantComponent } from './attribute-assistant.component';

describe('AttributeAssistantComponent', () => {
  let component: AttributeAssistantComponent;
  let fixture: ComponentFixture<AttributeAssistantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttributeAssistantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttributeAssistantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
