import { Input, OnChanges, SimpleChanges } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ProgramDetailService } from 'src/app/service/program-detail.service';
import { IAttributeRefVals } from '../../models/attributeRefVals';
import { IAttributeVals } from '../../models/attributeVals';
import { ProgramStatusService } from '../../service/program-status.service';
import { ConfirmationService } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { R2label } from 'src/app/models/problemList';
import { HeaderService } from 'src/app/service/header.service';

@Component({
  selector: 'app-attribute-assistant',
  templateUrl: './attribute-assistant.component.html',
  styleUrls: ['./attribute-assistant.component.scss']
})
export class AttributeAssistantComponent implements OnInit, OnChanges {
  @Input() familySel: { familyLabel: string; codeFamily: string; };

  familyCode: string;
  familyLabel: string;

  attributeCode: string;
  // when popup open only
  refCode: string;
  refValue: string;
  searchTerm: string;

  // when approved
  refCode1: string;
  refValue1: string;
  attributeLabel1: string;

  // to store selected attribute class and ref vals
  arrAttribute = [];
  arrAttrRef = [];

  attributeData: IAttributeVals[];
  selectedAttribute: IAttributeVals;
  refList: IAttributeRefVals[];
  selectedAttrRef: IAttributeRefVals;
  attributeLabel: string;
  attributeValue: string;
  displayBasic = false;
  approveReference = false;
  familyCodeChanged: boolean;
  alertMsg={
    "alertMsg":"",
    "programTypeAlert":""
  };
  
  pages:string="R2"
  labeltranslation= {} as R2label
  constructor(private programStatus: ProgramStatusService,
    private translateService: TranslateService,
    private confirmationService: ConfirmationService,
    private programDetailService: ProgramDetailService,
    private headerService:HeaderService

    ) { }

  async ngOnInit() { 
   await  this.getCampaignLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translateService.currentLang=res.lang;
          await this.getCampaignLabel();
         
        }
      })
     // this.alertMsg.alertMsg=this.labeltranslation.missCodeFamille
    // this.translateService.stream(["alertMsg", "programTypeAlert"]).subscribe(value => {
    //   this.alertMsg = value;
    // })
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.familySel && changes.familySel.currentValue) {
      this.familyCode = this.familySel.codeFamily;
      this.familyCodeChanged = true;
    }
  }

  // confirmMthd1() {
  //   this.confirmationService.confirm({
  //     message: 'The Family code must not be empty',
  //   });
  // }

  // Confirm method to show family code required message
  confirmMthd1(type) {
    this.confirmationService.confirm({
      message: this.alertMsg[type]
    });
  }
// method to close confirm box on click of OK
  okMth(){
    this.confirmationService.close();
  }

  famSelected(attribCode) {
    if (this.familySel) {
      this.showBasicDialog(attribCode);
    } else {
      this.confirmMthd1("alertMsg");
    }
  }

  // okMth(){
  //   setTimeout(() => {
  //     this.confirmationService.close();
  //   }, 100);
  // }


  showBasicDialog(attribCode) {
    this.displayBasic = true;
    this.searchTerm = attribCode;
    const mData = this.familySel.codeFamily;
    this.familyLabel = this.familySel.familyLabel;
    this.familyCode = mData;

    if (attribCode == null || attribCode == undefined || attribCode == '') {
      this.attributeCode = '';
    } else {
      this.attributeCode = attribCode; // 84BselectedRef
      this.afterSearch();
    }

    this.programStatus.getAttributRecords(this.familyCode, this.attributeCode).subscribe((data: any) => {
      this.attributeData = data.datalist;
    });
  }

  afterSearch() {
    const mthd = '';
    const var1 = [];
    this.programStatus.getAttributRecords(this.familyCode, mthd).subscribe((data: any) => {
      data.datalist.forEach(element => {
        var1.push(element);
      });
      this.attributeData = var1;
    });
  }

  selectedAttributeVal() {
    this.attributeCode = this.selectedAttribute.attributeCode;
    this.attributeLabel = this.selectedAttribute.attributeLabel;
    this.refValue = '';

    this.arrAttribute.push(this.selectedAttribute);

    this.programStatus.getAttributRecords(this.familyCode, this.attributeCode).subscribe((data: any) => {
      data.datalist.forEach(element => {
        const list = element.refList; // array of references
        this.refList = list;
      });
    });
  }

  selectedReferenceVal() {
    this.refCode = this.selectedAttrRef.refCode;
    this.refValue = this.selectedAttrRef.refValue;
    this.arrAttrRef.push(this.selectedAttrRef);
  }

  approveValuation() {
    this.displayBasic = false;
    this.approveReference = true;
    const strAttr = this.arrAttribute.pop();
    // this.attributeLabel1 = strAttr.attributeLabel;

    const ip = strAttr.attributeLabel;
    const fields = ip.split(':');
    this.attributeLabel1 = fields[1];

    const strAttrRef = this.arrAttrRef.pop();
    this.refCode1 = strAttrRef.refCode;
    // this.refValue1 = strAttrRef.refValue;

    const ipVal = strAttrRef.refValue;
    const fieldsVal = ipVal.split(':');
    this.refValue1 = fieldsVal[1];
  }

  closeMnemonicModal() {
    this.displayBasic = false;
  }

  getAttributeCode() {
    this.attributeCode = this.programDetailService.getTxt("nonAlphanum", 2);
    this.programStatus.getAttributRecords(this.familyCode, this.attributeCode).subscribe((data: any) => {
      this.familyCodeChanged = false;
      this.selectedAttribute = data.datalist.find(x=> x.attributeCode.toLowerCase() == this.attributeCode.toLowerCase())
      this.attributeLabel1 = this.selectedAttribute ? this.selectedAttribute.attributeLabel.split(':')[1] : null;
    });
  }

  getAttributeValue() {
    this.refCode1 = this.programDetailService.getTxt("nonAlphanum", 2);
    if(this.selectedAttribute.attributeCode == this.attributeCode && !this.familyCodeChanged) {
      this.refList = this.selectedAttribute.refList;
      this.selectedAttrRef = this.refList.find(x=> x.refCode.toLowerCase() == this.refCode1.toLowerCase());
      this.refValue1 = this.selectedAttrRef ? this.selectedAttrRef.refValue : null;
    } else {
      this.familyCodeChanged = false;
      this.programStatus.getAttributRecords(this.familyCode, this.attributeCode).subscribe((data: any) => {
        this.selectedAttribute = data.datalist.find(x=> x.attributeCode.toLowerCase() == this.attributeCode.toLowerCase())
        if(this.selectedAttribute) {
          this.attributeCode = this.selectedAttribute.attributeCode;
          this.attributeLabel1 = this.selectedAttribute.attributeLabel.split(':')[1];
          this.refList = this.selectedAttribute.refList;
          this.selectedAttrRef = this.refList.find(x=> x.refCode.toLowerCase() == this.refCode1.toLowerCase());
          this.refValue1 = this.selectedAttrRef ? this.selectedAttrRef.refValue.split(':')[1] : null;
        } else {
          this.attributeLabel = "";
        }
        
      });
    }
    
  }

  putAttributeCode(attributeCode) {
    this.programDetailService.putTxt(attributeCode, "nonAlphanum");
  }

  putAttributeValue(refCode1) {
    this.programDetailService.putTxt(refCode1, "nonAlphanum");
  }

  async getCampaignLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.alertMsg.alertMsg=this.labeltranslation.familyErr
     
     console.log(this.labeltranslation)
    });  
  }
}
