import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FamilyAssistantComponent } from './family-assistant.component';

describe('FamilyAssistantComponent', () => {
  let component: FamilyAssistantComponent;
  let fixture: ComponentFixture<FamilyAssistantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FamilyAssistantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FamilyAssistantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
