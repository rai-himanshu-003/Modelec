import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { R1Label } from 'src/app/models/problemList';
import { HeaderService } from 'src/app/service/header.service';
import { ProgramDetailService } from 'src/app/service/program-detail.service';

import { ProgramStatusService } from '../../service/program-status.service';

interface IFamilyVals {
  familyLabel: string;
  codeFamily: string;
}

@Component({
  selector: 'app-family-assistant',
  templateUrl: './family-assistant.component.html',
  styleUrls: ['./family-assistant.component.scss']
  // providers: [ConfirmationService]
})

export class FamilyAssistantComponent implements OnInit {

  displayBasic = false;
  @Output() familySelected = new EventEmitter<IFamilyVals>();
  @Output() familyGet = new EventEmitter<any>();
  familyLabel: string;
  codeFamily: string;
  fLabel: string;
  cFamily: string;
  array1 = [];
  // data receiving from API
  familyData: IFamilyVals[];
  selectedFamily: IFamilyVals;
  searchTerm: string;
  cancelCase = false;
  approveFamily = false;
  pages:string="R1"
  labeltranslation= {} as R1Label
  constructor(private programStatus: ProgramStatusService,
    private programDetailService: ProgramDetailService,
    private headerService:HeaderService,
    private translate: TranslateService
    ) { }
  
  ngOnInit(): void { 
    this.getCampaignLabel();
    this.headerService.notifyObservable.subscribe(res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          this.getCampaignLabel();
        }
      })
  }

  afterSearch() {
    const mthd = '';
    const var1 = [];
    this.programStatus.getRecords(mthd).subscribe((data: any) => {
      data.datalist.forEach(element => {
        var1.push(element);
      });
      this.familyData = var1;
    });
  }

  showBasicDialog(codeFamily) {
    this.displayBasic = true;
    this.searchTerm = codeFamily;
    this.programStatus.getRecords(this.codeFamily).subscribe((data: any) => {
      this.familyData = data.datalist;
    });

    if (this.codeFamily == null || this.codeFamily == undefined) {
      this.codeFamily = '';
    } else {
      this.codeFamily = codeFamily; // 84BselectedRef
      this.afterSearch();
    }
  }

  goBack() {
    this.displayBasic = false;
  }

  approveValuation() {
    const x = this.array1.pop();
    this.familySelected.emit(x);
    const fields = x.familyLabel.split(':');
    this.fLabel = fields[1];
    this.cFamily = fields[0];
    this.displayBasic = false;
    this.approveFamily = true;
  }

  onFamilySelect() {
    const ip = this.selectedFamily.familyLabel;
    const fields = ip.split(':');
    this.codeFamily = fields[0].trim(); // 015
    this.familyLabel = fields[1];
    this.array1.push(this.selectedFamily);
  }

  mdlFamilleGet() {
    this.codeFamily = this.programDetailService.getTxt("nonAlphanum", 4);
    this.getRecords();
  }

  mdlFamillePut(cFamily) {
    this.programDetailService.putTxt(cFamily, "nonAlphanum");
  }

  focusoutfunction() {
    this.codeFamily = this.cFamily;
    this.getRecords();
  }

  getRecords() {
    this.programStatus.getRecords(this.codeFamily).subscribe((data: any) => {
      this.selectedFamily = data.datalist.find(x=> x.codeFamily.toLowerCase() == this.codeFamily.toLowerCase())
      if(this.selectedFamily) {
        const fields = this.selectedFamily.familyLabel.split(':');
        this.fLabel = fields[1];
        this.cFamily = fields[0];
      } else {
        this.cFamily = this.codeFamily;
        this.fLabel = "";
      }
      this.familySelected.emit(this.selectedFamily);
    });
  }

  getCampaignLabel()
  {
  let lang= this.headerService.getlang(); 
  this.headerService.getLabel(lang, this.pages).subscribe(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     console.log(this.labeltranslation)
    });  
  }
}
