import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmationService } from 'primeng/api';
import {  R3Label } from 'src/app/models/problemList';
import { HeaderService } from 'src/app/service/header.service';
import { ProgramDetailService } from 'src/app/service/program-detail.service';
import { IMnemonicVals } from '../../models/mnemonicsVals';
import { IReferenceList } from '../../models/referenceList';
import { MenmonicAssistService } from '../../service/menmonic-assist.service';

@Component({
  selector: 'app-mnemonic-assistant',
  templateUrl: './mnemonic-assistant.component.html',
  styleUrls: ['./mnemonic-assistant.component.scss']
})

export class MnemonicAssistantComponent implements OnInit {

  @Input() familySel: { familyLabel: string; codeFamily: string; };
  @Input() programType: string;

  displayBasic = false;
  // to store selected array and selected reference after approve
  arrMnemonic = [];
  arrRef = [];

  familyCode: string;
  familyLabel: string;
  mnemonicCode: string;
  mnCode: string;

  // for popUp modal only
  mnemonicType: string; // 14x
  natureLabel: string; // HARD
  lengthLabel: string; // H --> H[20]
  mnemonicsLabel: string; // BTEL_HARD_000
  lengthLabelNum: string; // [20]
  referenceVal: string;

  // when approved
  mnType: string; // 14x
  natLabel: string; // HARD
  lgthLabel: string; // H --> H[20]
  mnLabel: string; // BTEL_HARD_000
  lgthLabelNum: string; // [20]
  refVal: string;
  alertMsg={
    "alertMsg":"",
    "programTypeAlert":""
  };
  
  // data receiving from API
  mnemonicData: IMnemonicVals[];
  selectedMnemonic: IMnemonicVals; // value selected from the mnemonic list

  // array of reference list
  mnemonicReference: IReferenceList[];
  selectedRef: IReferenceList; // value from reference list

  searchTerm: string;
  searchTermRef: string;
  foundInDB: boolean;
  pages:string="R3"
  labeltranslation= {} as R3Label
  constructor(private mnemonicStatus: MenmonicAssistService,
    private confirmationService: ConfirmationService,
    private translateService: TranslateService,
    private headerService:HeaderService,
    private programDetailService: ProgramDetailService) { }

  async ngOnInit(){

    await this.getCampaignLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translateService.currentLang=res.lang;
          await this.getCampaignLabel();
         
        }
      })
      
    // this.translateService.stream(["alertMsg", "programTypeAlert"]).subscribe(value => {
    //   this.alertMsg = value;
    // })
  } 
  // Confirm method to show family code required message
  confirmMthd1(type) {
    this.confirmationService.confirm({
      message: this.alertMsg[type]
    });
  }
// method to close confirm box on click of OK
  okMth(){
    this.confirmationService.close();
  }

  famSelected(mnemCode) {
    if (this.familySel) {
      if(this.programType) {
        this.showBasicDialog(mnemCode);
      } else {
        this.displayBasic = false;
        this.confirmMthd1("programTypeAlert");
      }

    } else {
      this.confirmMthd1("alertMsg");
    }
  }

  showBasicDialog(mnemCode) {
    this.displayBasic = true;
    this.searchTerm = mnemCode;
    this.searchTermRef = this.referenceVal;
    this.familyLabel = this.familySel.familyLabel;
    const mData = this.familySel.codeFamily;
    this.familyCode = mData;
    if (mnemCode == null || mnemCode === undefined || mnemCode === '') {
      this.mnemonicCode = '';
      this.mnemonicStatus.getMnemonicRecords(this.familyCode, this.mnemonicCode).subscribe((data: any) => {
        this.mnemonicData = data;
      });
    } else {
      this.mnemonicCode = mnemCode; 
      this.afterSearch();
    }

  }

  // when dialog box opens and user clicks backspace to remove searched mnemonic
  // to view all data
  afterSearch() {
    const mnCodeEmpty = '';
    const var1 = [];
    this.mnemonicStatus.getMnemonicRecords(this.familyCode, mnCodeEmpty).subscribe((data: any) => {
      data.forEach(element => {
        var1.push(element);
      });
      this.mnemonicData = var1;
    });
  }

  // after pop up opens user clicks on mnemonics
  selectedMnemonicData() {
    this.mnemonicCode = this.selectedMnemonic.mnemonicCode;

    //  values to display on mnemonic popup
    const ip = this.selectedMnemonic.mnemonicValue;
    const fields = ip.split('//');
    this.mnemonicType = fields[0]; // 015
    this.mnemonicsLabel = fields[1]; // IDT  _DATE_EXTENSION      _001
    this.lengthLabel = fields[2]; // A
    this.lengthLabelNum = fields[3]; // 8
    this.natureLabel = fields[4]; // DICO_ZERO
    this.referenceVal = null;

    this.arrMnemonic.push(this.selectedMnemonic);

    // call made to receive ReferenceList
    this.mnemonicStatus.getMnemonicRecords(this.familyCode, this.mnemonicCode).subscribe((data: any) => {
      data.forEach(element => {
        const list = element.refList; // array of references
        this.mnemonicReference = [];
        if (list) {
          for (const i in list) {
            const item = list[i];
            this.mnemonicReference.push({
              referenceVal: item
            });
          }
        }
      });
    });
  }

  selectedReferenceData() {
    this.referenceVal = this.selectedRef.referenceVal.replace(/\./g, '');
    this.arrRef.push(this.referenceVal);
    this.foundInDB = true;
  }

  // when user click approve button
  approveMnemonic() {
    const strMn = this.arrMnemonic.pop();
    const strRef = this.arrRef.pop();
    this.displayBasic = false;
    const ipMn = strMn.mnemonicValue;
    this.mnemonicCode = strMn.mnemonicCode;
    const fields = ipMn.split('//');
    this.mnType = fields[0]; // 015
    this.mnLabel = fields[1]; // IDT  _DATE_EXTENSION      _001
    this.lgthLabel = fields[2]; // A
    this.lgthLabelNum = fields[3]; // 8
    this.natLabel = fields[4]; // DICO_ZERO
    this.referenceVal = strRef;
    this.foundInDB = true;
  }

  // close pop up 
  closeMnemonicModal() {
    this.displayBasic = false;
  }

  getTypeHere() {
    this.mnemonicCode = this.programDetailService.getTxt("nonAlphanum", 3);
    this.familyCode = this.familySel.codeFamily;
    this.mnemonicStatus.getMnemonicRecords(this.familyCode, this.mnemonicCode).subscribe((data: any) => {
      if(data && data[0]) {
        this.selectedMnemonic = data[0]
        this.mnemonicCode = this.selectedMnemonic.mnemonicCode;
        const ip = this.selectedMnemonic.mnemonicValue;
        const fields = ip.split('//');
        this.mnemonicType = fields[0]; // 015
        this.mnemonicsLabel = fields[1]; // IDT  _DATE_EXTENSION      _001
        this.lengthLabel = fields[2]; // A
        this.lengthLabelNum = fields[3]; // 8
        this.natureLabel = fields[4]; // DICO_ZERO
        this.referenceVal = null;
        this.mnLabel = fields[1]; // IDT  _DATE_EXTENSION      _001
        this.lgthLabel = fields[2]; // A
        this.lgthLabelNum = fields[3]; // 8
        this.natLabel = fields[4]; // DICO_ZERO
      } else {
        this.mnemonicType = this.mnemonicCode;
        this.mnemonicsLabel = null;
        this.lengthLabel = null;
        this.lengthLabelNum = null;
        this.natureLabel = null;
        this.referenceVal = null;
        this.mnLabel = null; // IDT  _DATE_EXTENSION      _001
        this.lgthLabel = null; // A
        this.lgthLabelNum = null; // 8
        this.natLabel = null; // DICO_ZERO
      }
    });
    
  }

  getReferenceHere() {
    this.referenceVal = this.programDetailService.getTxt("dblquote", 22);
    this.foundInDB = this.selectedMnemonic.refList.find((x: any)=> x.replace(/\./g, '') == this.referenceVal) ? true : false;
  }

  putTypeHere(mnemonicCode) {
    this.programDetailService.putTxt(mnemonicCode, "nonAlphanum");
  }

  putReferenceHere(referenceVal) {
    this.programDetailService.putTxt(referenceVal, "dblquote");
  }

  async getCampaignLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.alertMsg.alertMsg=this.labeltranslation.familyErr;
     this.alertMsg.programTypeAlert=this.labeltranslation.chooseprogram
     console.log(this.labeltranslation)
    });  
  }
}
