import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface IAppConfig {
    // URL: string;
    // URI: string;
    apiURL: string;

    // variable for config.json file
    issuerURL:string,
    redirectUri:string;
    logoutURL:string,
    clientID:string,
    scopeVar:string
}

@Injectable()
export class AppConfig {

    public static settings;
    public static testURL:string;

    public testvar:string;
    public testURL:string;

    public exposedIssuerURL:string;
    public exposedRedirectURL:string;
    public exposedLogoutURL:string;
    public exposedClientID:string;
    public exposedScopeVar:string;
    public exposedClientSecretVar: string;

    constructor(private http: HttpClient) { }

    load(url: string) {
        return new Promise<void>((resolve, reject) => {
            this.http.get(url).toPromise().then((response: Response) => {
                AppConfig.settings = response;
                AppConfig.testURL = AppConfig.settings.redirectURI;
                this.testURL = AppConfig.settings.redirectURI;

                // Exposed value assigened to variables 
                this.exposedIssuerURL = AppConfig.settings.issuerURL;
                this.exposedRedirectURL = AppConfig.settings.redirectURI;
                this.exposedLogoutURL = AppConfig.settings.logoutURL;
                this.exposedClientID = AppConfig.settings.clientID;
                this.exposedScopeVar = AppConfig.settings.scopeVar;
                this.exposedClientSecretVar = AppConfig.settings.dummyClientSecretVar; 

                resolve();
            }).catch((response: any) => {
                reject(`Could not load file '${url}': ${JSON.stringify(response)}`);
            });
        });
    }

    getAppConfig(): IAppConfig {
        return AppConfig.settings;
    }
}
