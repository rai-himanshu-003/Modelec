export class RuleTableCode {

    private static ProjectList = 1;
    private static ChangeState = 2;
    private static ModelFunctionality = 3;
    private static PackagePowerTrain = 4;
    private static VersionFunctionality = 5;
    private static ExteriorColor  = 6;
    private static InteriorColor  =7;
    private static DesignBase = 8;
    private static CustomerTarget = 9;
    private static ForwardOption = 10;
    private static ReverseOption = 11;
    private static TransformationCode = 12;
    private static ErrorManagement = 13;

    public static getRuleName(code:any) {
        if(code == this.ProjectList) {
            return 'Project List';
        }
        if(code == this.ErrorManagement) {
            return 'Error Management';
        }

        if(code == this.ModelFunctionality) {
            return 'Model Functionality';
        }

        if(code == this.ExteriorColor) {
            return 'Exterior Color';
        }

        if(code == this.InteriorColor) {
            return 'Interior Color';
        }

        if(code == this.CustomerTarget) {
            return 'Customer Target';
        }

        if(code == this.ChangeState) {
            return 'Change State';
        }

        if(code == this.PackagePowerTrain) {
            return 'Package (Power Train)';
        }

        if(code == this.DesignBase) {
            return 'Design Base';
        }

        if(code == this.TransformationCode) {
            return 'Transformation Code';
        }

        if(code == this.ForwardOption) {
            return 'Forward Option';
        }

        if(code == this.ReverseOption) {
            return 'Reverse Option';
        }

        if(code == this.VersionFunctionality) {
            return 'Version Functionality';
        }

    }
}