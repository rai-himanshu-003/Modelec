8//import { AppConfig } from '../app.config';
import { Injectable } from '@angular/core';
import { AppConfig } from '../app.config';

@Injectable({
    providedIn: 'root'
})
export class ServiceURL {
    serviceHostName: string;
   // redirectURL:string;

    constructor(private appPrivate: AppConfig) {
        // this.serviceHostName = this.appPrivate.getAppConfig().URL + this.appPrivate.getAppConfig().URI;
        console.log(this.appPrivate.getAppConfig());
        this.serviceHostName = "http://localhost:9090/mdlmicroservice";
       // this.redirectURL = this.appPrivate.getAppConfig().redirectUri
        

        console.log(this.serviceHostName);

    }

}
