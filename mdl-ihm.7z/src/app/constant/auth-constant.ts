export const LOCAL_STORAGE_TOKEN_NAME = 'access_token';
export const LOCAL_STORAGE_USER_NAME = 'mdl_user';
export const LOCAL_STORAGE_USER_LOCALE = "userLocale";
export const ROLE_ADMIN = 'ADMIN';
export const ROLE_RULE_MANAGER = 'RULE_MANAGER';
export const MOD_PRD = 'mdl';
