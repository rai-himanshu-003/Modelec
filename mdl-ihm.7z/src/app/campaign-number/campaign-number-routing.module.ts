import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CampaignNumberComponent } from './campaign-number.component';

const routes: Routes = [
  {
    path: '',
    component: CampaignNumberComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CampaignNumberRoutingModule { }
