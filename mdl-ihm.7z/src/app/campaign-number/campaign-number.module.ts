import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { CampaignNumberRoutingModule } from './campaign-number-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { AccordionModule } from 'primeng/accordion';
import { PanelModule } from 'primeng/panel';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule } from 'primeng/fileupload';
import { CampaignNumberComponent } from './campaign-number.component';
import { TabViewModule } from 'primeng/tabview';
import { ProgramsComponent } from '../programs/programs.component';
import { FoldersDataComponent } from '../folders-data/folders-data.component';
import { VehiclesComponent } from '../vehicles/vehicles.component';
import { BreadcrumbModule } from 'primeng/breadcrumb';

@NgModule({
  imports: [
    PanelModule,
    BreadcrumbModule,
    DropdownModule,
    TabViewModule,
    FileUploadModule,
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    MultiSelectModule,
    CampaignNumberRoutingModule
  ],
  declarations: [CampaignNumberComponent,
    ProgramsComponent, VehiclesComponent, FoldersDataComponent],
  providers: [MessageService, DatePipe, ConfirmationService]
})
export class CampaignNumberModule { }
