import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignNumberComponent } from './campaign-number.component';

describe('CampaignNumberComponent', () => {
  let component: CampaignNumberComponent;
  let fixture: ComponentFixture<CampaignNumberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CampaignNumberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CampaignNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
