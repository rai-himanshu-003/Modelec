export class CampaignNumberDTO {
    codeChantier: string;
    name: string;
}
