export class Downloadzip{
    filename:any;
    image:any;
}