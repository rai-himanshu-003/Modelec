import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MenuItem, Message } from 'primeng/api';
import { Router } from '@angular/router';
import { CampaignNumberService } from '../service/campaign-number.service';
import { CampaignNumberDTO } from './campaign-number';
import { ConfirmationService } from 'primeng/api';
//import { ServiceURL } from '../constant/ServiceURL';
import { RoutingService } from '../service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import { C3label } from '../models/campaign-list';
import { HeaderService } from '../service/header.service';
import { Actionlabels } from '../models/breadcrumbsDTO';

@Component({
  selector: 'app-campaign-number',
  templateUrl: './campaign-number.component.html',
  styleUrls: ['./campaign-number.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class CampaignNumberComponent implements OnInit {
  cols: any[];
  selectedCities: string[] = [];
  vehSearchRecords: any;
  campaignData: string;
  campaignValue: string;
  concat: string;
  campaignType: string;
  IDO: string;
  campaignStatus: string;
  campaign: string;
  programsData: string;
  formData: any;
  formval: any;
  isdisabled = false;
  isDisabledmanual = true;
  isDisabledConsist = true;
  isDisabledAuto = true;
  isDisabledCancel = true;
  isDisabledDownload = true;
  items: MenuItem[];
  chgCampaigntoWhite: number;
  manual: number;
  auto: number;
  consistency: number;
  download: number;
  title: any;
  cancel: number;
  cc: string;
  vehSearch: string;
  postData = {} as CampaignNumberDTO;
  toggle:boolean = true;
  role: any;

  msgs: Message[] = [];

  //Variable to translate confirm msg.
  whiteCnfMsg:string;
  ManualCnfMsg:string;
  autoCnfMsg:string;
  cancelCnfMsg:string;
  whiteSuccessCnfMsg:string;
  manualSuccessCnfMsg:string;
  autoSuccessCnfMsg:string;
  cancelSuccessCnfMsg:string;
  labeltranslation= {} as C3label
  pages:String="C3";
  actionpage="action";
  actiontranslation= {} as Actionlabels;
  campaignDtls={
    "Local":"",
    "Associations in the process of being published": "",
    "Automatic Inventory": "",
    "Manual Inventory": "",
    "Modernization": "",
    "White": ""

  }



  constructor(
    public router: Router,
    private campaignNumberService: CampaignNumberService,
    private confirmationService: ConfirmationService,
   // private serviceURL:ServiceURL,
    private routingService: RoutingService,
    private translate: TranslateService,
    private headerService:HeaderService


  ) {
    //For translating confirm msg.


    // this.translate.stream('cancelCnfMsg').subscribe(value=>{
    // this.cancelCnfMsg=value;
    // });
    // this.translate.stream('whiteSuccessCnfMsg').subscribe(value=>{
    // this.whiteSuccessCnfMsg=value;
    // });
    // this.translate.stream('manualSuccessCnfMsg').subscribe(value=>{
    // this.manualSuccessCnfMsg=value;
    // });
    // this.translate.stream('autoSuccessCnfMsg').subscribe(value=>{
    // this.autoSuccessCnfMsg=value;
    // });
    // this.translate.stream('cancelSuccessCnfMsg').subscribe(value=>{
    // this.cancelSuccessCnfMsg=value;
    // });

    //For checking Access Role.
    this.routingService.getAccessRole().subscribe((value) => {
      console.log(value,"Program Role")
      this.role=value;
      if(this.role.includes('RETOUCHEUR')){
        this.cancel=0;
      }
  });
}

ngOnDestroy(){
  this.routingService.setProgAssociate(null);
  this.routingService.setidGamme(null);
}

  async ngOnInit() {

    await this.getCampaignLabel();
    await this.getActionLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getCampaignLabel();
         await this.getActionLabel();
         this.getPathName();
         
        }
      })

    this.storeCampaignCode();
    this.cols = [

      { field: 'date', header: 'Date' },
      { field: 'user', header: 'User' },

    ];
    this.getPathName();
    // Code for Breadcrum

    // console.log(campaignSearch);
    // this.items.forEach(element => {
    //   if (element.label == 'Campaign') {
    //     element.label = element.label + ' ' + campaignSearch;
    //   }
    // });
  }
  whiteCampaign(chgCampaigntoWhite) {
    console.log('calling' + chgCampaigntoWhite);
    const name = 'campaignWhite';

    this.confirmationService.confirm({
      message: this.whiteCnfMsg,
      accept: () => {
        this.postData.name = name;
        this.postData.codeChantier = this.campaignValue;

        this.campaignNumberService.updateCampaign(this.campaignValue, name).subscribe(
          (data: any) => {
            console.log(data.datalist);
            if(data.datalist.msg===true){
              this.msgs.push({severity:'success', summary:'Success', detail:this.whiteSuccessCnfMsg});
              setTimeout(() => {
               window.location.reload();
                }, 5000);
            }
          }
        );
      }
    });
  }

  manualInventory(_manual) {

    const name = 'manualInventory';

    this.confirmationService.confirm({
      message: this.ManualCnfMsg,
      accept: () => {
        this.postData.name = name;
        this.postData.codeChantier = this.campaignValue;

        this.campaignNumberService.updateCampaign(this.campaignValue, name).subscribe(
          (data: any) => {
            console.log(data.datalist);
            if(data.datalist.msg===true){
              this.msgs.push({severity:'success', summary:'Success', detail:this.manualSuccessCnfMsg});
              setTimeout(() => {
               window.location.reload();
                }, 5000);
            }
          }
        );
      }
    });
  }
  autoInventory(auto) {
    console.log('call' + auto);
    const name = 'automaticInventory';

    this.confirmationService.confirm({
      message: this.autoCnfMsg,
      accept: () => {
        this.postData.name = name;
        this.postData.codeChantier = this.campaignValue;

        this.campaignNumberService.updateCampaign(this.campaignValue, name).subscribe(
          (data: any) => {
            console.log(data.datalist);
            if(data.datalist.msg===true){
              this.msgs.push({severity:'success', summary:'Success', detail:this.autoSuccessCnfMsg});
              setTimeout(() => {
               window.location.reload();
                }, 5000);
            }
          }
        );
      }
    });
  }
  checkConsistency(consistency) {
    console.log('call' + consistency);
    this.router.navigate(['/consistency-check'])
  }

  downloadIDO(download) {
    let redirectTo : string;
    console.log('call' + download);
    this.campaignNumberService.downloadIDO(this.campaignValue).subscribe(
      (data: any) => {
        console.log("redirect url1234",data.body);
        redirectTo=data.filename
        if(redirectTo===null){
          console.log("Need to redirect to consistency check screen")
          this.router.navigate(['/consistency-check'])
        }
       else
        {
        this.downLoadFile(data);
        }
      }
    );

}
downLoadFile(data: any) {

  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveOrOpenBlob(data.image, data.filename);
  } else {
    const element = document.createElement('a');
    element.href = URL.createObjectURL(data.image);
    element.download = data.filename;
    document.body.appendChild(element);
    element.click();

  }
}
  getData() { }
  cancelCampaign(cancel) {
    this.postData.codeChantier = this.campaignValue;
    console.log('call' + cancel);
    this.confirmationService.confirm({
      message: this.cancelCnfMsg,
      accept: () => {
        this.campaignNumberService.cancelCampaign(this.campaignValue).subscribe(
          (data:any) => {
            console.log(data.datalist.msg);
            if(data.datalist.msg===true){
              this.msgs.push({severity:'success', summary:'Success', detail:this.cancelSuccessCnfMsg});
              setTimeout(() => {
               window.location.reload();
                }, 5000);
            }
          });
      }
    });
  }

  storeCampaignCode() {
    // Set the value of Vin number in variable
    this.campaignData = window.localStorage.getItem('campaignSearch');

    // If value is not null or undefined then call get data
    if (this.campaignData != null && this.campaignData != undefined) {
      window.localStorage.setItem('campaignData', this.campaignData);
      this.getRecordsFromDB();
    }

  }

  getRecordsFromDB() {
    const campaignNumber: string = window.localStorage.getItem('campaignData');

    if (campaignNumber != null && campaignNumber != undefined) {
      this.campaignValue = campaignNumber;
      console.log(this.campaignValue);
    } else {
      console.log('no data found');
    }
    this.campaignNumberService.getRecords(this.campaignValue).subscribe(

      (data: any) => {

        this.download = data.datalist.campaignInfoAreaDTO.downloadIdoCampaign;
        if(this.role.includes('RETOUCHEUR')){
          this.cancel=0;
          this.chgCampaigntoWhite=1;
          this.manual = 1;
          this.auto = 1;
          this.consistency = 0;
        }
        else{
        this.chgCampaigntoWhite = data.datalist.campaignInfoAreaDTO.chgCampaigntoWhite;
        this.manual = data.datalist.campaignInfoAreaDTO.manualBtnInventory;
        this.auto = data.datalist.campaignInfoAreaDTO.automaticBtnInventory;
        this.cancel = data.datalist.campaignInfoAreaDTO.cancelCampaign;
        this.consistency = data.datalist.campaignInfoAreaDTO.chkConsistency;
        }
        this.vehSearchRecords = data.datalist.campaignInfoAreaDTO;
        this.formData = data.datalist.campaignInfoAreaDTO;
        if( data.datalist.campaignInfoAreaDTO.chantierBlanc == 1 || data.datalist.campaignInfoAreaDTO.manualInventory == 1
          || data.datalist.campaignInfoAreaDTO.automaticInventory == 1){
            this.toggle=false;
          }

        // this.translate.stream(['White', 'Manual Inventory', 'Automatic Inventory', 'Associations in the process of being published',
        //   'Modernization']).subscribe(val => {
            let campType=[];
            this.concat = '';
            if (data.datalist.campaignInfoAreaDTO.natureChantier === 'L') {
              campType.push(this.campaignDtls['Local']);
            }
            if (data.datalist.campaignInfoAreaDTO.chantierBlanc === 1) {
              campType.push(this.campaignDtls['White']);
            }
            if (data.datalist.campaignInfoAreaDTO.manualInventory === 1) {
              campType.push(this.campaignDtls['Manual Inventory']);
            }
            if (data.datalist.campaignInfoAreaDTO.automaticInventory === 1) {
              campType.push(this.campaignDtls['Automatic Inventory']);
            }
            if (data.datalist.campaignInfoAreaDTO.associationsProcess === 1) {
              campType.push(this.campaignDtls['Associations in the process of being published']);
              if (data.datalist.campaignInfoAreaDTO.natureChantier !== 'L' && data.datalist.campaignInfoAreaDTO.chantierBlanc !== 1
                && data.datalist.campaignInfoAreaDTO.manualInventory !== 1 && data.datalist.campaignInfoAreaDTO.automaticInventory !== 1) {
              campType.push(this.campaignDtls['Modernization']);
              }
            } else if (data.datalist.campaignInfoAreaDTO.natureChantier !== 'L' && data.datalist.campaignInfoAreaDTO.chantierBlanc !== 1
              && data.datalist.campaignInfoAreaDTO.manualInventory !== 1 && data.datalist.campaignInfoAreaDTO.automaticInventory !== 1
              && data.datalist.campaignInfoAreaDTO.associationsProcess !== 1) {

              campType.push(this.campaignDtls['Modernization']);
            }
            this.concat=campType.join(', ');
            console.log(this.concat);
        });

      
  
  }

  async getCampaignLabel()
  {
  let lang= this.headerService.getlang();
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.cancelCnfMsg=this.labeltranslation.annulerChantierConfirm;;
     this.whiteCnfMsg=this.labeltranslation.passerEnChantierBlancConfirm
     this.ManualCnfMsg=this.labeltranslation.changeManuConfirm;
     this.autoCnfMsg=this.labeltranslation.changeAutoConfirm;
     this.manualSuccessCnfMsg=this.labeltranslation.manuSuccess;
     this.whiteSuccessCnfMsg=this.labeltranslation.passerChantier
     this.autoSuccessCnfMsg=this.labeltranslation.autoSuccess;
     this.cancelSuccessCnfMsg=this.labeltranslation.successCancel;
     this.campaignDtls['Associations in the process of being published']=this.labeltranslation.association;
     this.campaignDtls['Automatic Inventory']=this.labeltranslation.auto;
     this.campaignDtls['Manual Inventory']=this.labeltranslation.manual;
     this.campaignDtls['Modernization']=this.labeltranslation.modern;
     this.campaignDtls['White']=this.labeltranslation.white;
     this.campaignDtls['Local']=this.labeltranslation.local;
     console.log(this.labeltranslation)
    });
  }

  async getActionLabel()
  {
    let lang= this.headerService.getlang();
    await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
      (data: any) => {
       this.actiontranslation = data.datalist.record;
       console.log(this.actiontranslation)
      });
    }

getPathName()
{
  const campaignSearch = window.localStorage.getItem('campaignSearch');
    this.items = [
      {label: this.actiontranslation.rechercherChantiers,url: '../campaign-management'},
      {label:this.actiontranslation.detailChantier+campaignSearch},
    ];
}
}
