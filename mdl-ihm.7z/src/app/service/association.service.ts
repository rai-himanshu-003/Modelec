import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from './url.service';

@Injectable({
    providedIn: 'root',
})

export class AssociationService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    checkAssociation(code): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getAssociationChantier(), {
            params: {
                codeChantier: `${code}`
            }

        }).pipe(
            map(
                (res: any) => {
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );

    }
    deleteAssociation(code, id): Observable<any> {

        return this.httpClient.get<any>(this.urlService.deleteSelectAssociations(), {
            params: {
                codeChantier: `${code}`,
                recordStr: `${id}`
            }
        }).pipe(
            map(
                (res: any) => {
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    validate(code): Observable<any> {

        return this.httpClient.get<any>(this.urlService.validAssociation(), {
            params: {
                codeChantier: `${code}`
            }
        }).pipe(
            map(
                (res: any) => {
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }
    addAssociation(chantier, id, dossier): Observable<any> {

        return this.httpClient.get<any>(this.urlService.addAssociation(), {
            params: {
                codeChantier: `${chantier}`,
                idGamme: `${id}`,
                codeDossier:`${dossier}`
            }
        }).pipe(
            map(
                (res: any) => {
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    returnversion(codeChant): Observable<any> {

        return this.httpClient.get<any>(this.urlService.returnVersion(), {
            params: {
                codeChantier: `${codeChant}`
            }
        }).pipe(
            map(
                (res: any) => {
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        return throwError(errorMessage);


    }

}
