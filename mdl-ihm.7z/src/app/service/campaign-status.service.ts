import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { URLService } from '../service/url.service';
// import { Pagination } from '../vehicle-search/pagination';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable({
    providedIn: 'root'
})

export class CampaignStatusService {
    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    csvDateFormat(dateFromRecord: any) {
    
        var day = dateFromRecord.getDate() + "";
        var month = dateFromRecord.getMonth()  + "";
        var year = dateFromRecord.getFullYear() + "";
        var hour = dateFromRecord.getHours()  + "";
        var minutes = dateFromRecord.getMinutes() + "";
        var seconds = dateFromRecord.getSeconds() + "";

        day = this.checkZero(day);
        month = this.checkZero(month);
        year = this.checkZero(year);
        hour = this.checkZero(hour);
        minutes = this.checkZero(minutes);
        seconds = this.checkZero(seconds);
        
        return(day + "/" + month + "/" +  year + " " + hour + ":" + minutes + ":" + seconds +" ");
    }

    checkZero(data){
        if(data.length == 1){
            data = "0" + data;
        }
        return data;
    }

    exportToCSVRecords(nbRows: number, offsetStartPosition: number,
         totalRecords: boolean, sortResult: string): Observable<any> {
        return this.httpClient.get(this.urlService.exportToCSVtUrlVS(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                rowsPerPage: `${nbRows}`,
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                getTotalRecords: `${totalRecords}`,
                CampaignListDTO: `${sortResult}`,
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            })
        );
    }
}
