import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { URLService } from './url.service';
import { map, catchError } from 'rxjs/operators';
import { throwError, BehaviorSubject, Observable } from 'rxjs';
import { CopyProgramDTO } from '../copy-program/copy-programDTO';
import { iRangeDetails } from '../models/range-Details';

export class headertext {
  field;
  header;
}

@Injectable({
  providedIn: 'root'
})

export class ProgramDetailService {

  allData = new BehaviorSubject(null);
  lastSavedCaretPos: any;

  constructor(private http: HttpClient,
    private urlService: URLService) { }

  private handleError(err: HttpErrorResponse) {
    let errorMessage = '';

    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occured: ${err.error.message} `;
    } else {
      errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
  
  deleteProg(progNo): Observable<any> {
    console.log(progNo);
    return this.http.delete<any>(this.urlService.deleteProg(), {

      params: {
        programNo: `${progNo}`
      }
    }).pipe(
      map(
        (res: any) => {
          console.log(res);
          const data = {
            datalist: res
          };
          return data;

        }
      ),
      catchError(this.handleError)
    );
  }

  getProgInfo(progNo): Observable<any> {
    console.log(progNo);
    return this.http.get<any>(this.urlService.getProgInfo(), {
      params: {
        programNo: `${progNo}`
      }
    }).pipe(
      map(
        (res: any) => {
          console.log(res);
          const data = {
            datalist: res
          };
          return data;
        }
      ),
      catchError(this.handleError)
    );
  }

  getSeq(): Observable<any> {
    return this.http.get<any>(this.urlService.getSeq()).pipe(
      map((data: any) => data),
      catchError(this.handleError)
    );
  }

  getCopyProg(postData: CopyProgramDTO): Observable<CopyProgramDTO[]> {
    return this.http.post<CopyProgramDTO[]>(this.urlService.getCopyProg(), postData);
  }

  saveProgram(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.saveProgram(), postData);
  }

  updateLabel(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.updateLabel(), postData);
  }

  checkRules(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.checkRules(), postData);
  }

  saveProgramDraft(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.saveProgramDraft(), postData);
  }

  validateProgram(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.validateProgram(), postData);
  }

  returnValidateVersion(postData: iRangeDetails): Observable<iRangeDetails[]> {
    return this.http.post<iRangeDetails[]>(this.urlService.returnValidateVersion(), postData);
  }

  getTxt(delimiter, maxLength) {
    var ruleset = <HTMLInputElement>document.getElementById('regles');
    var caretPos = this.caret(ruleset);
    var content = ruleset.value;
    // we search the left position
    var begPos = this.searchLeft(content,caretPos,delimiter);
  
    // we search the right position
    var endPos = this.searchRight(content,caretPos,delimiter);
  
    // here comes the text
    var code = content.substring(begPos,endPos);
  
    // we take care of helper max length
    //var helperObj = document.getElementById(helperName);
    if (code.length > maxLength) {
      code = code.substring(0,maxLength);
    }
    //helperObj.value = code;
    return code;
  }

  caret(ruleset) {
    // for gecko like browsers (FF*)
    if (typeof ruleset.selectionStart != undefined) {
      return ruleset.selectionStart;
    }
  
    // other browsers not supported yet
    alert('current browser not supported yet');
  }

  searchLeft(content,pos,delimiter) {
    var currPos = pos;
    var reg = this.getRegexp(delimiter);
    var currC = 'x';
    while (1) {
      // we met start of text
      if (currPos <= 0) return currPos;
      currPos = currPos-1;
  
      // we met stop condition
      currC = content.charAt(currPos);
      if (!reg.test(currC)) return currPos+1;
    }
  }

  searchRight(content,pos,delimiter) {
    var currPos = pos;
    var reg = this.getRegexp(delimiter);
    var currC = 'x';
    var len = content.length;
    while (1) {
      // we met end of text
      if (currPos >= len) return currPos;
      currC = content.charAt(currPos);
  
      // we met stop condition
      if (!reg.test(currC)) return currPos;
      currPos = currPos+1;
    }
  }

  getRegexp(delimiter) {
    if (delimiter == "nonAlphanum") {
      return /^[A-Za-z0-9]$/;
    } else if (delimiter == "dblquote") {
      return /^[^\"\n\r]$/;
    } else {
      // shouldn't happen
      /^[^.]$/;
    }
  }

  saveCaretPos() {
    var ruleset = document.getElementById('regles');
    this.lastSavedCaretPos = this.caret(ruleset);
  }

  putTxt(txtValue,delimiter) {
    var ruleset = <HTMLInputElement>document.getElementById('regles');
    var content = ruleset.value;
  
    // Conversely to getTxt, here we cannot get current caret position of ruleset with IE because
    // it has lost his way since most of the times we just has left helper field
    // So we use lastSavedCaretPosition we got when ruleset lost focus
  
    // we search the left position
    var begPos = this.searchLeft(content,this.lastSavedCaretPos,delimiter);
  
    // we search the right position
    var endPos = this.searchRight(content,this.lastSavedCaretPos,delimiter);
  
    this.replace(ruleset,begPos,endPos-begPos,txtValue);
  
  }

  replace(ruleset,begPos,len,txt) {
    // compute new content
    var content = ruleset.value;
    var replacedContent = content.substr(0,begPos) + txt + content.substr(begPos+len);
    var txtLen = txt.length;
  
    // for gecko like browsers (FF*)
    if (ruleset.selectionStart) {
      // replace content
      ruleset.value = replacedContent;
  
      // caret position relocation
      ruleset.selectionStart = begPos + txtLen;
      ruleset.selectionEnd = begPos + txtLen;
      return;
    }
  
    // other browsers not supported yet
    alert('current browser not supported yet');
  }

}
