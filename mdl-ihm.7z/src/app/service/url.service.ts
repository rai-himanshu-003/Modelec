import { Injectable } from '@angular/core';
import { ServiceURL } from '../constant/ServiceURL';

@Injectable({
  providedIn: 'root'
})
export class URLService {

  constructor(
    private serviceURL: ServiceURL) {
    console.log(serviceURL.serviceHostName, "Service Invoked.")
  }

  public isAlive() {
    return this.serviceURL.serviceHostName + '/alive/isAlive';
  }

  public getIDO() {
    return this.serviceURL.serviceHostName + '/vehicle/getIDO';
  }
  public getIMP() {
    return this.serviceURL.serviceHostName + '/vehicle/getIMP';
  }
  public getTRA() {
    return this.serviceURL.serviceHostName + '/vehicle/getTRA';
  }
  public getSQP() {
    return this.serviceURL.serviceHostName + '/vehicle/getSQP';
  }

  public getCampaign() {
    return this.serviceURL.serviceHostName + '/campaign/getcampaign';
  }

  public deleteProg() {
    return this.serviceURL.serviceHostName + '/range/DeleteRange';
  }

  public getProgInfo() {
    return this.serviceURL.serviceHostName + '/range/RangeDetails';
  }

  public getCopyProg() {
    return this.serviceURL.serviceHostName + '/range/CopyProgram';
  }

  public getSeq() {
    return this.serviceURL.serviceHostName + '/range/getSeq';
  }

  public saveProgram() {
    return this.serviceURL.serviceHostName + '/range/saveProgram';
  }

  public updateLabel() {
    return this.serviceURL.serviceHostName + '/range/updateLabel';
  }

  public checkRules() {
    return this.serviceURL.serviceHostName + '/range/checkRules';
  }

  public saveProgramDraft() {
    return this.serviceURL.serviceHostName + '/range/saveProgramDraft';
  }
  
  public validateProgram() {
    return this.serviceURL.serviceHostName + '/range/validateProgram';
  }

  public returnValidateVersion() {
    return this.serviceURL.serviceHostName + '/range/returnValidateVersion';
  }

  public getAssociationChantier() {
    return this.serviceURL.serviceHostName + '/association/getAssociationChantierGamme';
  }

  public deleteSelectAssociations(){
    return this.serviceURL.serviceHostName + '/association/deleteSelectAssociations';
  }

  public validAssociation() {
    return this.serviceURL.serviceHostName + '/association/validAssociationModification';
  }

  public addAssociation() {
    return this.serviceURL.serviceHostName + '/association/addAssociation';
  }

  public getImpact() {
    return this.serviceURL.serviceHostName + '/impact/getImpact';
  }

  public getImpactDetails() {
    return this.serviceURL.serviceHostName + '/impact/getImpactDetail';
  }

  public returnVersion() {
    return this.serviceURL.serviceHostName + '/association/returnLinkValidVersion';
  }

  public centerProdList() {
    return this.serviceURL.serviceHostName + '/campaign/getcenterprodlist';
  }

  public uploadCampaign() {
    return this.serviceURL.serviceHostName + '/campaign/uploadcampaignfile';
  }
  
  public loadSQP() {
    return this.serviceURL.serviceHostName + '/sqp/sqpfeedbackupload';
  }

  public loadSQPResult() {
    return this.serviceURL.serviceHostName + '/sqp/sqpfeedbackresult';
  }

  public getCampaignDetailProgramArea() {
    return this.serviceURL.serviceHostName + '/campaign/getCampaignDetailProgramArea';
  }

  public downloadIDO() {
    return this.serviceURL.serviceHostName + '/campaign/exportIdoFile';
  }
  
  public getCancelCampaign() {
    return this.serviceURL.serviceHostName + '/campaign/cancelCampaign';
  }

  public getUpdateCampaignDetail() {
    return this.serviceURL.serviceHostName + '/campaign/updateCampaignDetail';
  }
  
  public detailCampaignUrl() {
    return this.serviceURL.serviceHostName + '/campaign/getCampaignDetail';
  }

  public getProgram() {
    return this.serviceURL.serviceHostName + '/range/rangeList';
  }

  public getFamily() {
    return this.serviceURL.serviceHostName + '/range/FamilyAssistant';
  }

  public exportToCSVRange() {
    return this.serviceURL.serviceHostName + '/range/exportToCSV';
  }

  public campaignUrl() {
    console.log(this.serviceURL.serviceHostName)
    return this.serviceURL.serviceHostName + '/campaign/campaignList';
    // return this.serviceURL.serviceHostName+ '/campaign/campaignList?rowsPerPage=10&offsetPositionToStartFrom=0&getTotalRecords=true&campaignListDTO'
    // tp://localhost:9090/mdlmicroservice/campaign/campaignList?rowsPerPage=10&offsetPositionToStartFrom=0&getTotalRecords=true&campaignListDTO
  }

  public campaignListUrl() {
    return this.serviceURL.serviceHostName + '/campaign/campaignList';
  }

  public exportToCSVtUrlVS() {
    return this.serviceURL.serviceHostName + '/campaign/exportToCSV';
  }

  // Consistency Check Data
  public getConsistencyData() {
    return this.serviceURL.serviceHostName + '/campaign/getCheckConsistency';
  }

  public getVehicleFamilyData() {
    return this.serviceURL.serviceHostName + '/campaign/getVehicle';
  }

  public validateConsistencyCampaign()
  {
    return this.serviceURL.serviceHostName  + '/campaign/validateCampaign'
  }

  // http://localhost:9090/mdlmicroservice/campaign/AttributeAssistant?familyCode=1PA7&attributeCode=&reference=&nature=
  public addAttributeinConsistency()
  {
    return this.serviceURL.serviceHostName  + '/campaign/AttributeAssistant'
  }

  //  http://localhost:9090/mdlmicroservice/campaign/AttributeAssistant?attributeCode=JK&nature=P,D 
  // left hand side data
  public getCodeLibClasse(){
    return this.serviceURL.serviceHostName  + '/campaign/getCodeLibClasse'
  }
  
  // on Approve Attribute from consistency check screen
  public getAttributeInConsistency() {
    return this.serviceURL.serviceHostName + '/campaign/addAttribute';
  }

  public saveAbandonsCampaign() {
    return this.serviceURL.serviceHostName + '/campaign/saveAnomales';
  }
  // Consistency Check API
public getTranslation()
{
  return this.serviceURL.serviceHostName + '/translation/getlabel';
}
  public getAttribute() {
    return this.serviceURL.serviceHostName + '/range/AttributeAssistant';
  }

  public getMnemonic() {
    return this.serviceURL.serviceHostName + '/range/MnemonicAssistant';
  }

  public vehicleListUrl() {
    return this.serviceURL.serviceHostName + '/vehicle/getvehiclelist';
  }

  public exportToCSVRecords() {
    return this.serviceURL.serviceHostName + '/vehicle/exportToCSV';
  }

  public getvehicledetails() {
    return this.serviceURL.serviceHostName + '/vehicle/getvehicledetails';
  }

  public getvehicleattributes() {
    return this.serviceURL.serviceHostName + '/vehicle/getvehicleattributes';
  }

  public getvehicleelectronique() {
    return this.serviceURL.serviceHostName + '/vehicle/getvehicleelectronique';
  }

  public generateidofile() {
    return this.serviceURL.serviceHostName + '/vehicle/generateidofile';
  }

  public updatevehicle() {
    return this.serviceURL.serviceHostName + '/vehicle/updatevehicle';
  }

  public cancelvehicle() {
    return this.serviceURL.serviceHostName + '/vehicle/cancelvehicle';
  }

  public manualInventory() {
    return this.serviceURL.serviceHostName + '/vehicle/manualInventory';
  }

  public updateCorvetMI() {
    return this.serviceURL.serviceHostName + '/vehicle/updateCorvetMI';
  }

  public updateattribute() {
    return this.serviceURL.serviceHostName + '/vehicle/updateattribute';
  }

  public getattributehistory() {
    return this.serviceURL.serviceHostName + '/vehicle/getattributehistory';
  }

  public manualInventoryExport() {
    return this.serviceURL.serviceHostName + '/vehicle/manualInventoryExport';
  }

  public vehicleAttributeAssistant() {
    return this.serviceURL.serviceHostName + '/vehicle/vehicledetailattributeassistant';
  }
  

  public getdeferredtasks() {
    return this.serviceURL.serviceHostName + '/asyncprocess/getdeferredtasks';
  }

  public gettaskdetail() {
    return this.serviceURL.serviceHostName + '/asyncprocess/gettaskdetail';
  }

  public exportAsyncProcess() {
    return this.serviceURL.serviceHostName + '/asyncprocess/exportToCSV';
  }


  public updateUserDataUrl() {
    return this.serviceURL.serviceHostName + '/userInfo/updateUserData';
  }

  public userDataUrl() {
    return this.serviceURL.serviceHostName + '/userInfo/getUserData';
  }
}
