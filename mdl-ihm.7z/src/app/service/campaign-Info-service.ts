import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError, Observable } from 'rxjs';
import { HttpErrorResponse, HttpClient} from '@angular/common/http';
import { URLService } from './url.service';
import { map, catchError } from 'rxjs/operators';
import { FilePostDTO } from '../campaign-information/filePostDTO';


export class headertext {
    field;
    header;
}


@Injectable({
    providedIn: 'root'
})

export class CampaignInfoService {

    allData = new BehaviorSubject(null);
    filepath: string = undefined;
    file: File = undefined;

    constructor(private http: HttpClient,
        private urlService: URLService) {}

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    getProdRecords(): Observable<any> {
        return this.http.get<any>(this.urlService.centerProdList(), {
        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    getRecords(): Observable<any> {
        return this.http.get<any>(this.urlService.getCampaign(), {
        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );

    }
    uploadRecord(postData): Observable<FilePostDTO[]> {
        let formdata = new FormData();
        formdata.append('file', postData.file);
        formdata.append('campaignUploadDTO', postData.campaignUploadDTO);
        return this.http.post<any>(this.urlService.uploadCampaign(), formdata);
    }
   
}
