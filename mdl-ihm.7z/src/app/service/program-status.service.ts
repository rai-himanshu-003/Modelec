import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { URLService } from '../service/url.service';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { FamilyList } from '../models/family-DTO';

@Injectable({
    providedIn: 'root'
})

export class ProgramStatusService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }
    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    getRecords(codeFamily) {
        return this.httpClient.get<FamilyList>(this.urlService.getFamily(), {
            params: {
                codeFamily: `${codeFamily}`
            }
        }).pipe(
            map(
                (res: FamilyList) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    getAttributRecords(familyCode, attributeCode): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getAttribute(), {
            params: {
                familyCode: `${familyCode}`,
                attributeCode: `${attributeCode}`
            }
        }).pipe(
            map(
                (res: any) => {
                    // console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            // catchError(this.handleError)
        );
    }

    exportToCSVRecords(nbRows: number, offsetStartPosition: number, totalRecords: boolean, sortResult: string): Observable<any> {
        return this.httpClient.get(this.urlService.exportToCSVRange(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                rowsPerPage: `${nbRows}`,
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                getTotalRecords: `${totalRecords}`,
                RangeListDTO: `${sortResult}`,
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                 // return res;
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            })
        );
    }

}
