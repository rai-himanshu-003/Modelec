import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { URLService } from './url.service';
import { map, catchError } from 'rxjs/operators';
import { throwError, BehaviorSubject, Observable } from 'rxjs';
import { CampaignListDTO } from '../models/campaign-list';

export class HeaderText {
  field;
  header;
}

@Injectable({
  providedIn: 'root'
})

export class DataService {
  //baseApiUrl = 'http://localhost:4200/campaign-management';
  allData = new BehaviorSubject(null);

  constructor(private http: HttpClient,
    private urlService: URLService,
    ) { }

  private handleError(err: HttpErrorResponse) {
    let errorMessage = '';

    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occured: ${err.error.message} `;
    } else {
      errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }


  getRecords(offSet, rows, totalRecords, sortResult): Observable<any> {
    console.log(sortResult);
    return this.http.get<any>(this.urlService.campaignUrl(), {

      params: {
        offsetPositionToStartFrom: `${offSet}`,
        rowsPerPage: `${rows}`,
        getTotalRecords: `${totalRecords}`,
        CampaignListDTO: `${sortResult}`
      }
    }).pipe(
      map(
        (res: any) => {
          console.log(res);
          console.log(res, "After date manip");
          const data = {
            datalist: res
            
          }; 
          return data;
        }
      ),
      catchError(this.handleError)
    );
  }
  


  getDataRecords(interfaceName: string): Observable<any[]> {
    return this.http.get<CampaignListDTO[]>(this.urlService.campaignListUrl(), {
      params: {
        interfaceId: interfaceName
      }
    }).pipe(
      map((data: CampaignListDTO[]) => {
        return data.map(element => {
          // console.log(element.maxEcomDate);
          // console.log(element.minEcomDate);

          return element;
        });
      }),
      catchError(this.handleError)
    );
  }

  upload(file): Observable<any> {
    //  Create form data
    const formData = new FormData();
    //  Store form name as "file" with file data
    formData.append('File', file, file.name);
    //  Make http post request over api
    //  with formData as req
    return this.http.post<any>(this.urlService.uploadCampaign(), formData);
  }

}
