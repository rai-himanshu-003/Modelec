import { Injectable } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';



@Injectable()
export class ExportToCSV {

    browserLang: string;
    langSelector: string;

    constructor(private translate: TranslateService) { }

    downloadFile(data, fieldList, headerList, filename) {
        console.log('data: ' + data)
        // let csvData = this.ConvertToCSV(data, ["priority","typeOfFilter","familyOfVehicle","productionCentre","country","minEcomDate","maxEcomDate","dateCreation"]);
        const csvData = this.ConvertToCSV(data, fieldList, headerList);
        // console.log(csvData)

        const blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob, `${filename}.csv`);
        }

        else {

            const dwldLink = document.createElement('a');
            const url = URL.createObjectURL(blob);
            // element.download = data.filename;

            const isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
            if (isSafariBrowser) {  // if Safari open in new window to save file with random filename.
                dwldLink.setAttribute('target', '_blank');
            }
            dwldLink.setAttribute('href', url);
            dwldLink.setAttribute('download', filename + '.csv');
            dwldLink.style.visibility = 'hidden';

            document.body.appendChild(dwldLink);
            dwldLink.click();

            document.body.removeChild(dwldLink);

        }

    }

    ConvertToCSV(objArray, fieldList, headerList) {

        // This Method will detect the browser lang
        this.browserLang = this.translate.getBrowserLang();

        if (this.browserLang === 'fr') {
            this.langSelector = ';';
        }
        else {
            this.langSelector = ',';
        }

        const array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
        let str = '';
        let row = `S.No  ${this.langSelector}`;

        console.log(this.browserLang);
        console.log(array);


        for (const index in headerList) {
            row += headerList[index].toUpperCase() + `${this.langSelector}`;
        }
        row = row.slice(0, -1);
        str += row + '\r\n';
        for (let i = 0; i < array.length; i++) {
            let line = (i + 1) + '';
            for (const index in fieldList) {
                const head = fieldList[index];

                line += `${this.langSelector}` + array[i][head];
            }

            str += line + '\r\n';
        }
        return str;
    }

    // This will Format date from records

    csvDateFormat(dateFromRecord: any) {

        let day = dateFromRecord.getDate() + '';
        let month = (dateFromRecord.getMonth() + 1) + '';
        let year = dateFromRecord.getFullYear() + '';
        let hour = dateFromRecord.getHours() + '';
        let minutes = dateFromRecord.getMinutes() + '';
        let seconds = dateFromRecord.getSeconds() + '';

        day = this.checkZero(day);
        month = this.checkZero(month);
        year = this.checkZero(year);
        hour = this.checkZero(hour);
        minutes = this.checkZero(minutes);
        seconds = this.checkZero(seconds);

        return (day + '/' + month + '/' + year + ' ' + hour + ':' + minutes + ':' + seconds + ' ');
    }

    // This will format date for file time stamp
    formatDateForExport() {
        const today = new Date();
        let day = today.getDate() + '';
        let month = (today.getMonth() + 1) + '';
        let year = today.getFullYear() + '';
        let hour = today.getHours() + '';
        let minutes = today.getMinutes() + '';
        let seconds = today.getSeconds() + '';

        day = this.checkZero(day);
        month = this.checkZero(month);
        year = this.checkZero(year);
        hour = this.checkZero(hour);
        minutes = this.checkZero(minutes);
        seconds = this.checkZero(seconds);

        // return(day + "/" + month + "/" + year + " " + hour + ":" + minutes + ":" + seconds);

        return (year + '.' + month + '.' + day + '.' + hour + '.' + minutes + '.' + seconds);
    }

    checkZero(data) {
        if (data.length == 1) {
            data = '0' + data;
        }
        return data;
    }
}