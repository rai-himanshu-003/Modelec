import { Injectable } from '@angular/core';
import { map } from 'rxjs/internal/operators/map';
import { URLService } from './url.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
// import { checkConsistencyRequestDto } from '../consistency-check/validateCampaignDTO';

@Injectable({
  providedIn: 'root'
})

export class ConsistencyCheckService {

  constructor(private httpClient: HttpClient,
    private urlService: URLService) { }

  // to load all data on check consistency page.
  // http://localhost:9090/mdlmicroservice/campaign/getCheckConsistency?codeChantier=L58 

  getConsistencyRecords(codeChantier: string): Observable<any> {
    return this.httpClient.get<any>(this.urlService.getConsistencyData(), {
      params: {
        codeChantier: `${codeChantier}`,
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }

  // add Attribute  BUtton right side data
  // http://localhost:9090/mdlmicroservice/campaign/AttributeAssistant?attributeCode=JK&nature=P,D 
  getCodeLibClasseRecord(attributeCode, nature): Observable<any> {
    return this.httpClient.get<any>(this.urlService.getCodeLibClasse(),{
      params: {
        attributeCode: `${attributeCode}`,
        nature: `${nature}`
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }

  // add Attribute Button to load left side data
  // http://localhost:9090/mdlmicroservice/campaign/AttributeAssistant?familyCode=1PA7&attributeCode=&reference=&nature=

  addAttributeButtonRecord(familyCode,attributeCode,reference,nature): Observable<any> {
    return this.httpClient.get<any>(this.urlService.addAttributeinConsistency(), {
      params: {
        familyCode: `${familyCode}`,
        attributeCode: `${attributeCode}`,
        reference: `${reference}`,
        nature: `${nature}`
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }


  // validateCampaign API
  // http://localhost:9090/mdlmicroservice/campaign/validateCampaign?codeChantier=L58&idoGeneratingAction=true&vehicleRefresh=true

  // validateConsistencyRecord(checkConsistencyRequestDto:checkConsistencyRequestDto): Observable<checkConsistencyRequestDto[]> {
  //   return this.httpClient.post<checkConsistencyRequestDto[]>(this.urlService.validateConsistencyCampaign(), checkConsistencyRequestDto);
  //   }

  validateConsistencyRecord(codeChantier, idoGeneratingAction, vehicleRefresh): Observable<any> {
    return this.httpClient.get<any>(this.urlService.validateConsistencyCampaign(), {
      params: {
        codeChantier: `${codeChantier}`,
        idoGeneratingAction: `${idoGeneratingAction}`,
        vehicleRefresh: `${vehicleRefresh}`
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }

  // @QueryParam("codeChantier") String codeChantier, @QueryParam("codeVehicle") String codeVehicle,
  //  @QueryParam("codeClasse") String codeClasse, @QueryParam("codeValeur") String codeValeur 
  // Approve Attribute API

  getAttributeRecords(codeChantier, codeVehicle, codeClasse, codeValeur, natureValue): Observable<any> {
    return this.httpClient.get<any>(this.urlService.getAttributeInConsistency(), {
      params: {
        codeChantier: `${codeChantier}`,
        codeVehicle: `${codeVehicle}`,
        codeClasse: `${codeClasse}`,
        codeValeur: `${codeValeur}`,
        natureValue: `${natureValue}`,
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }

  getVehicleFamilyDataRecord(codeVehicule): Observable<any> {
    return this.httpClient.get<any>(this.urlService.getVehicleFamilyData(), {
      params: {
        codeVehicule: `${codeVehicule}`
      }
    }).pipe(
      map(
        (res: any) => {
          console.log(res);

          return res;
        }
      )
    );
  }


  saveAbandonsCampaignRecords(vehicleChantierList) {
   return this.httpClient.post(this.urlService.saveAbandonsCampaign(), vehicleChantierList)
  }

}




