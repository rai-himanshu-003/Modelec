import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationEnd } from '@angular/router';

import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class RoutingService {

    private routerInfo: BehaviorSubject<boolean>;
    private readonly validatedNO: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
    private readonly validateAsynParameter: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
    private readonly createBTN: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
    private readonly getToken: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly accessRole: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly progAssociate: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly impactCamp: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly userID: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly idGamme: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly sqpResult: BehaviorSubject<any> = new BehaviorSubject<any>({});
    private readonly impactRules: BehaviorSubject<any> = new BehaviorSubject<any>({});
    private readonly impactDetailsRules: BehaviorSubject<any> = new BehaviorSubject<any>({});
  previousUrl: any;
  currentUrl: string;
  constructor(private route: Router) {
    this.routerInfo = new BehaviorSubject<boolean>(false);
    this.validatedNO = new BehaviorSubject<boolean>(false);
    this.createBTN = new BehaviorSubject<boolean>(false);
    this.validateAsynParameter = new BehaviorSubject<boolean>(false);
    this.getToken = new BehaviorSubject<string>('');
    this.accessRole = new BehaviorSubject<string>('');
    this.progAssociate = new BehaviorSubject<string>('');
    this.impactCamp = new BehaviorSubject<string>('');
    this.userID = new BehaviorSubject<string>('');
    this.sqpResult = new BehaviorSubject<any>({});
    this.idGamme = new BehaviorSubject<string>('');
    this.impactRules = new BehaviorSubject<any>({});
    this.impactDetailsRules = new BehaviorSubject<any>({});

    this.route.events.subscribe(event => {
      if (event instanceof NavigationEnd) {        
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;

        console.log("previous url === ",this.previousUrl);
        console.log("currentUrl url === ",this.currentUrl);
      };
    });
  }

  public getPreviousUrl(){
    return this.previousUrl;
  }

  getValue(): Observable<boolean> {
    return this.routerInfo.asObservable();
  }
  setValue(newValue): void {
    this.routerInfo.next(newValue);
  }

  getValidatedValue(): Observable<boolean> {
    return this.validatedNO.asObservable();
  }
  setValidatedValue(newValue): void {
    this.validatedNO.next(newValue);
  }

  getCreateBTN(): Observable<boolean> {
    return this.createBTN.asObservable();
  }
  setCreateBTN(newValue): void {
    this.createBTN.next(newValue);
  }
  // For Role Access
  getProgAssociate(): Observable<string> {
    return this.progAssociate.asObservable();
  }
  setProgAssociate(newValue): void {
    this.progAssociate.next(newValue);
  }

  //For Authorization Token
  getTokenValue(): Observable<string> {
    return this.getToken.asObservable();
  }
  setTokenValue(newValue): void {
    this.getToken.next(newValue);
  }
  // For Role Access
  getAccessRole(): Observable<string> {
    return this.accessRole.asObservable();
  }
  setAccessRole(newValue): void {
    this.accessRole.next(newValue);
  }
  // For userID
  getUserID(): Observable<string> {
    return this.userID.asObservable();
  }
  setUserID(newValue): void {
    this.userID.next(newValue);
  }
  //For impact to campaign
  getImpactCamp(): Observable<string> {
    return this.impactCamp.asObservable();
  }
  setImpactCamp(newValue): void {
    this.impactCamp.next(newValue);
  }
  //For sqpResult
  getsqpResult(): Observable<any> {
    return this.sqpResult.asObservable();
  }
  setsqpResult(newValue): void {
    this.sqpResult.next(newValue);
  }
  //For Impact idGamme
  getidGamme(): Observable<string> {
    return this.idGamme.asObservable();
  }
  setidGamme(newValue): void {
    this.idGamme.next(newValue);
  }
  getImpactRules(): Observable<any> {
    return this.impactRules.asObservable();
  }
  setImpactRules(newValue): void {
    this.impactRules.next(newValue);
  }
// to pass data from consistency-check to status-asynch screen
  getValidateAsynParameter(): Observable<any> {
    return this.validateAsynParameter.asObservable();
  }
  setValidateAsynParameter(newValue): void {
    this.validateAsynParameter.next(newValue);
  }
  //Rules for Imp details
  getImpactDetailsRules(): Observable<any> {
    return this.impactDetailsRules.asObservable();
  }
  setImpactDetailsRules(newValue): void {
    this.impactDetailsRules.next(newValue);
  }

  
}