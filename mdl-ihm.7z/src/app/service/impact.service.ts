import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from './url.service';

@Injectable({
    providedIn: 'root',
})

export class ImpactService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    getImpact(chantier, input, draftRuleset, gammeType): Observable<any> {
        // console.log(sortResult)
        let params;
        if(input == "VALIDATE_DRAFT_GAMME") {
            params = {
                inputValue: `${chantier}`,
                input: `${input}`,
                draftRuleset: `${draftRuleset}`,
                gammeType: `${gammeType}`
                
            }
        } else {
            params = {
                inputValue: `${chantier}`,
                input: `${input}`
            }
        }
        return this.httpClient.get<any>(this.urlService.getImpact(), {
            params: params
        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    console.log(data.datalist);
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }
}