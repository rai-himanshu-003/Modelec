import { Injectable } from '@angular/core';
import { BehaviorSubject} from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class GetSelectedCPService {
    
    private readonly selectedCP: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly selectedProg: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly selectedProgramNumber: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    private readonly selectedAssociationNumber: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    constructor() {}

    getSelectedCPNumber(): string {
        return  this.selectedCP.getValue();
    }

    setSelectedCPNumber(data: string) {
        this.selectedCP.next(data);
    }
    getselectedProgramNumber(): string {
        return  this.selectedProgramNumber.getValue();
    }

    setselectedProgramNumber(data: string) {
        this.selectedProgramNumber.next(data);
    }

    getSelectedProgNumber(): string {
        return  this.selectedProg.getValue();
    }

    setSelectedProgNumber(data: string) {
        this.selectedProg.next(data);
    }

    getSelectedAssociationNumber(): string {
        return  this.selectedAssociationNumber.getValue();
    }

    setSelectedAssociationNumber(data: string) {
        this.selectedAssociationNumber.next(data);
    }


}



