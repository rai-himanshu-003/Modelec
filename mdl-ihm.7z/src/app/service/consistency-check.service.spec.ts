import { TestBed } from '@angular/core/testing';

import { ConsistencyCheckService } from './consistency-check.service';

describe('ConsistencyCheckService', () => {
  let service: ConsistencyCheckService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsistencyCheckService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
