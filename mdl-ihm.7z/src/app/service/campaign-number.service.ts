import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse,  } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from './url.service';

@Injectable({
    providedIn: 'root',
})

export class CampaignNumberService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    getCheckBoxData(code, associate): Observable<any> {
        // console.log(sortResult)
        return this.httpClient.get<any>(this.urlService.getCampaignDetailProgramArea(), {
            params: {
                codeChantier: `${code}`,
                association: `${associate}`
            }

        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    console.log(data.datalist);
                    return data;
                }
            ),
            catchError(this.handleError)
        );

    }

    updateCampaign(code, name): Observable<any> {
        // console.log(sortResult)
        return this.httpClient.get<any>(this.urlService.getUpdateCampaignDetail(), {
            params: {
                codeChantier: `${code}`,
                name: `${name}`
            }

        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    console.log(data.datalist);
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    downloadIDO(code): Observable<any> {
        return this.httpClient.get(this.urlService.downloadIDO(), {
            
            observe: 'response',
            responseType: 'blob',
            params: {
                codeChantier: `${code}`
            }
        }).pipe(
            map((res) => {
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename'),
                };
                console.log(res.headers);
                return data;
            })
        );
    }

    cancelCampaign(code): Observable<any> {
        // console.log(sortResult)
        return this.httpClient.get<any>(this.urlService.getCancelCampaign(), {
            params: {
                codeChantier: `${code}`
            }

        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    console.log(data.datalist);
                    return data;
                }
            ),
            catchError(this.handleError)
        );

    }
    getRecords(code): Observable<any> {
        // console.log(sortResult)
        return this.httpClient.get<any>(this.urlService.detailCampaignUrl(), {
            params: {
                codeChantier: `${code}`
            }

        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    console.log(data.datalist);
                    return data;
                }
            ),
            catchError(this.handleError)
        );

    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }
}
