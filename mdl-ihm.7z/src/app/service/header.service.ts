import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { URLService } from './url.service';
import { map, catchError } from 'rxjs/operators';
import { throwError, Observable, BehaviorSubject} from 'rxjs';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_USER_LOCALE } from '../constant/auth-constant';

@Injectable({
  providedIn: 'root'
})

export class HeaderService {

  constructor(private http: HttpClient,
    private urlService: URLService
    ) { }
public notify= new BehaviorSubject<any>('');
notifyObservable= this.notify.asObservable();

public notifyOther(data:any)
{
  this.notify.next(data)
}

  private handleError(err: HttpErrorResponse) {
    let errorMessage = '';

    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occured: ${err.error.message} `;
    } else {
      errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
  getLabel(lang,pages):Observable<any>
  {
    return this.http.get<any>(this.urlService.getTranslation() ,
      {
       params: {
         lang: `${lang}`,
         page: `${pages}`
       } 
      }).pipe(
        map(
          (res: any) => {
            //console.log(res);
            const data = {
              datalist: res
              
            };
            
            return data;
          }
        ),
        catchError(this.handleError)
      );
    }
    getlang(){
      const userLocale : any = JSON.parse(atob(LocalStorage.readValue(LOCAL_STORAGE_USER_LOCALE)));
     let language = userLocale;
     console.log("get languagae from header service",language);
     
    //  if(language==undefined){
    //    language="en"
    //  }
    let currentlang;
    if(language=="en")
    {
    currentlang="en_GB"
    }
    else if(language=="fr")
    {
        currentlang="fr_FR"
    }
    else if(language=="de")
    {
        currentlang=="de_DE"
    }
    else if(language==" ")
    {
      currentlang=="en_GB"
    }
    return currentlang;
    }

    updateUserData(updatedUserDetails:any):Observable<any>{
      return this.http.post<any[]>(this.urlService.updateUserDataUrl(),updatedUserDetails);
    }

    getUserData(userId:string,type:string,lang:string):Observable<any>{
 
      return this.http.get(this.urlService.userDataUrl(),{
        params:{ 
          
          userId:`${userId}`,
          type:`${type}`,
          lang:`${lang}`,
        }
      }).pipe(
        // tap(data => console.log('All'+ JSON.stringify(data))),
        map((data)=>{
          console.log(data);
  
          return data;
  
        }),
        catchError(this.handleError)
      )
    }
}
