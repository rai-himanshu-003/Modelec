import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { URLService } from './url.service';

@Injectable({
  providedIn: 'root'
})
export class MenmonicAssistService {

  constructor(private httpClient: HttpClient, private urlService: URLService) { }

  getMnemonicRecords(familyCode: string, mnemonicCode: string): Observable<any> {
    return this.httpClient.get<any>(this.urlService.getMnemonic(), {
      params: {
        familyCode: `${familyCode}`,
        mnemonicCode: `${mnemonicCode}`
      }
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }

}