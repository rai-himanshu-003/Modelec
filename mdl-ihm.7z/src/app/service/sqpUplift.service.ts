import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { loadSQP } from '../sqp-uplift/loadSQP';
import { URLService } from './url.service';

@Injectable({
    providedIn: 'root',
})

export class sqpUpliftService {


    constructor(private http: HttpClient,
        private urlService:URLService){}

    loadSQPRecord(postSQP): Observable<loadSQP[]> {
        let formdata = new FormData();
        formdata.append('file', postSQP.file);
        formdata.append('userId', postSQP.userId);
        return this.http.post<any>(this.urlService.loadSQP(), formdata);
    }

    sqpfeedbackresult(postSQP): Observable<loadSQP[]> {
        let formdata = new FormData();
        formdata.append('file', postSQP.file);
        formdata.append('userId', postSQP.userId);
        return this.http.post<any>(this.urlService.loadSQPResult(), formdata);
    }
}