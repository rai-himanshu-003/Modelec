import { BehaviorSubject, throwError, Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { URLService } from './url.service';
import { RangeListDTO } from '../models/range-ListDTO';

export class headertext {
    field;
    header;
}

@Injectable({
    providedIn: 'root'
})

export class ProgramManagementService {

    allData = new BehaviorSubject(null);

    constructor(private http: HttpClient,
        private urlService: URLService) {
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
    }

    getRecords(offSet, rows, totalRecords, sortResult): Observable<any> {
        console.log(sortResult);
        return this.http.get<any>(this.urlService.getProgram(), {
            params: {
                offsetPositionToStartFrom: `${offSet}`,
                rowsPerPage: `${rows}`,
                getTotalRecords: `${totalRecords}`,
                RangeListDTO: `${sortResult}`
            }
        }).pipe(
            map(
                (res: any) => {
                    console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            catchError(this.handleError)
        );
    }

    getDataRecords(interfaceName: string): Observable<any[]> {
        return this.http.get<RangeListDTO[]>(this.urlService.getProgram(), {
            params: {
                interfaceId: interfaceName
            }
        }).pipe(
            map((data: RangeListDTO[]) => {
                return data.map(element => {
                    return element;
                });
            }),
            catchError(this.handleError)
        );
    }
}
