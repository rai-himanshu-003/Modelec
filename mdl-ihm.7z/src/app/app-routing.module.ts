import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IsAliveComponent } from './is-alive/is-alive.component';

const routes: Routes = [
    { path: 'isAlive', component: IsAliveComponent},
    { path: 'layout',  loadChildren: './layout/layout.module#LayoutModule' },
    { path: '', loadChildren: './layout/layout.module#LayoutModule' },
    { path: '**', redirectTo: 'layout' }
];

@NgModule({
      imports: [RouterModule.forRoot(routes)],
    // change for has mapping and refresh issue
    exports: [RouterModule]
})
export class AppRoutingModule { }


