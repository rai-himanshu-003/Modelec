export interface CopyProgramDTO {
    programNo: string;
    programLabel: string;
}
