import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProgramDetailService } from '../service/program-detail.service';
import { CopyProgramDTO } from './copy-programDTO';
import { MenuItem } from 'primeng/api';
import { RoutingService } from '../service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import {HeaderService} from '../service/header.service';
import { G5labels } from '../models/range-ListDTO';
import { Actionlabels } from '../models/breadcrumbsDTO';
@Component({
  selector: 'app-copy-program',
  templateUrl: './copy-program.component.html',
  styleUrls: ['./copy-program.component.scss']
})
export class CopyProgramComponent implements OnInit {
  fleet: boolean;
  vnv: boolean;
  validates: string;
  campaigns: string;
  property: string;
  by: string;
  process: string;
  validate: string;
  pLabel: string;
  publish: string;
  textValue: string;
  name: string;
  number: string;
  areaData: any[];
  programsData: any[];
  nameVal: string;
  released: string;
  created: string;
  progNumber: string;
  programNumber: string;
  formData: any;
  formVal: any;

  formDate: any;

  postData = {} as CopyProgramDTO;
  copyTranslate:string;

  updatedProgramLabel: string;
  items: MenuItem[];
  programName: any;
  pages="G5";
  labeltranslation= {} as  G5labels;
  actionpage="action";
  actiontranslation= {} as Actionlabels;
  


  constructor(
    private route: Router,
    private programDetailService: ProgramDetailService,
    private routingService:RoutingService,
    private translate: TranslateService,
    private headerService:HeaderService
  ) { 
    }

  async ngOnInit() {
  await this.getCopyProgLabels(); 
  await this.getActionLabel();
  this.programName=this.copyTranslate;
    this.storeProgNo();

    this.getPathName();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getCopyProgLabels();
          await this.getActionLabel();
          this.storeProgNo();
          this.getPathName();
        }
      })
  }

async getCopyProgLabels()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }
getPathName()
{
  const progSearch = window.localStorage.getItem('progSearch');
    this.items = [
      { label: this.actiontranslation.listeGammes, url: '../program-management' },
      { label: this.actiontranslation.detailGamme+progSearch, url: '../program-list/' + this.postData.programNo },
      { label:this.actiontranslation.copieGamme }
    ]; 
}

  copyRelease(updatedLabel) {
    this.postData.programLabel = updatedLabel;
    this.programDetailService.getCopyProg(this.postData).subscribe(
      (data: any) => {
      this.route.navigate(['/program-list', data.id]);
      window.localStorage.setItem('progSearch', data.id);

      }
    );

  }
  cancelCopy() {
    this.route.navigate(['/program-list', this.postData.programNo]);
  }
  storeProgNo() {

    // Set the value of progno number in variable
    this.programNumber = window.localStorage.getItem('progSearch');

    // If value is not null or undefined then call get data
    if (this.programNumber != null && this.programNumber != undefined) {
      window.localStorage.setItem('programNumber', this.programNumber);
      this.getRecordsFromDB();
    }

  }
  getRecordsFromDB() {
    const pNumber: string = window.localStorage.getItem('programNumber');
    if (pNumber != null && pNumber != undefined) {
      this.progNumber = pNumber;
    } 
    this.programDetailService.getProgInfo(this.progNumber).subscribe(
      (data: any) => {
        this.postData.programNo = (data.datalist.programNo);
        data.datalist.createdDate = new Date(data.datalist.createdDate as Date);
       
           this.copyTranslate=this.labeltranslation.copie;
           this.updatedProgramLabel = data.datalist.programLabel + this.copyTranslate;
      if(data.datalist.type=='VNVO'){
        data.datalist.type='VN/VO';
      }
        this.formData = data.datalist;
        this.formVal = JSON.parse(JSON.stringify(data.datalist));
      }
    );
  }

  redirectToAssociate(associated){
    this.routingService.setValue(true);
    if(associated>0){
     window.localStorage.setItem('associated', this.progNumber);
    this.route.navigate(['/campaign-management']);
    }
  }

  redirectToValidate(validate){
   
    if(validate>0){
      this.routingService.setValidatedValue(true);
      this.routingService.setValue(true);
      window.localStorage.setItem('associated', this.progNumber);
    this.route.navigate(['/campaign-management']);
    }
  }

}
