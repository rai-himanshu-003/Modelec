import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { CheckboxModule } from 'primeng/checkbox';
import { CampaignManagementRoutingModule } from './program-management-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { ProgramManagementComponent } from './program-management.component';
import { AccordionModule } from 'primeng/accordion';
import { MessageService } from 'primeng/api';
import { KeyFilterModule } from 'primeng/keyfilter';
import { PanelModule } from 'primeng/panel';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    CampaignManagementRoutingModule,
    KeyFilterModule,
    PanelModule
  ],
  declarations: [ProgramManagementComponent,
  ],
  providers: [MessageService, DatePipe]
})
export class ProgramManagementModule { }
