import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {  LazyLoadEvent } from 'primeng/api';
import { GetSelectedCPService } from '../service/getCP.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { G3labels, ProgramListLabel, RangeListDTO } from '../models/range-ListDTO';
import { ProgramManagementService } from '../service/program.data.service';
import { ProgramStatusService } from '../service/program-status.service';
import { RoutingService } from '../service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import { Table } from 'primeng/table';
import { HeaderService } from '../service/header.service';
import { SideBarLabel } from '../models/sidebar-list';

@Component({
  selector: 'app-program-management',
  templateUrl: './program-management.component.html',
  styleUrls: ['./program-management.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ProgramManagementComponent implements OnInit {
  formData: FormGroup;
  @ViewChild('dt', { static: false }) table: Table;
  @ViewChild('programForm', { static: false }) form: FormControl;
 
  progNumber: string;
  multiSortMeta: string;
  pSearchRecords: RangeListDTO = {} as RangeListDTO;
  isDataAvailable = false;
  toDate: string | Date;
  fromDate: string | Date;
  dbSort: string;
  // variable for columns
  
  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  totalNumberRecords: number;

  // lazy loading variable
  loading: boolean;

  collapsedVal: boolean = false;
  sortData: RangeListDTO = {} as RangeListDTO;
  sortResult: string|any;
  // creating variables for ngmodel
  programNumber: string;
  programName: string;
  userId: string;
  linkCampaign: string;
  includingFamily: string;
  
  associationNo: string;
  dbDetails: RangeListDTO = {} as RangeListDTO;
  index: number;
  lastIndex: number;
  createBTN: boolean = false;

  //Variables for tooltip
  linkedProgramTooltip:string;
  programNoTooltip:string;
  programNameTooltip:string;
  userIDTooltip:string;
  programDateTooltip:string;
  includingFamilyTooltip:string;

  //Variable for role Mgmt
  role: string;

  //Variables to clear filter
  filterProgramNo:string;
  filterProgramLabel:string;
  filterOutstandingEdit: string;
  filterNoOfValidCampaigns: string;
  filterUpdateDate: Date;
  filterUserModifier: string;
  filterNoOfCampaigns: string;
  changeLang: string;
  cols: { field: string; header: string; }[] = [];
  typeOfFiltersForFilter: { label: string; value: string; }[];
  pages="G1";
  labeltranslation= {} as ProgramListLabel;
  pages_1="D2";
  linelabeltranslation= {} as SideBarLabel;
  pages_2="G3";
  blabeltranslation= {} as G3labels;
  


  constructor(
    private getSelectedCPService: GetSelectedCPService,
    public router: Router,
    private programStatusService: ProgramStatusService,
    private datePipe: DatePipe,
    private programManagementService: ProgramManagementService,
    private routingService: RoutingService,
    private translate : TranslateService,
    private headerService: HeaderService
  ) {
    // Enabling/Disabling Create BTN
    this.routingService.getCreateBTN().subscribe((value) => {
      this.createBTN = value;
    });
    //For Role Check
    this.routingService.getAccessRole().subscribe((value) => {
      this.role=value;
      if(this.role.includes('POME') || this.role.includes('RETOUCHEUR')){
        this.createBTN=true
      }
      });
      //this.translate.stream(['YES', 'NO']).subscribe(val=>{
        // this.typeOfFiltersForFilter = [];
        // this.typeOfFiltersForFilter.push({label :this.blabeltranslation.yes, value: "yes"});
        // this.typeOfFiltersForFilter.push({label :this.blabeltranslation.no, value: "no"});
     // });
  }

  async ngOnInit() {
    await this.getProgramLabel();
    await this. getLabels();
    await this.getBooleanLabels();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
         await this.getProgramLabel();
         await this. getLabels();
         await this.getBooleanLabels();
         this.getColsData();
         this.getFilterValues();
         
        
        }
      })
      
    //For translating Tooltip
    // this.translate.stream('linkedProgramTooltip').subscribe((value)=>{
    //   this.linkedProgramTooltip=value;
    // });
    // this.translate.stream('programNoTooltip').subscribe((value)=>{
    //   this.programNoTooltip=value;
    // });
    // this.translate.stream('programNameTooltip').subscribe((value)=>{
    //   this.programNameTooltip=value;
    // });
    // this.translate.stream('userIDTooltip').subscribe((value)=>{
    //   this.userIDTooltip=value;
    // });
    // this.translate.stream('programDateTooltip').subscribe((value)=>{
    //   this.programDateTooltip=value;
    // });
    // this.translate.stream('includingFamilyTooltip').subscribe((value)=>{
    //   this.includingFamilyTooltip=value;
    // });

    this.getColsData();
    this.storeProgNo();
    this.getFilterValues();
    
}
getColsData(){
  this.cols = [
    { field: 'programNo', header: this.labeltranslation.colonneNumeroGamme },
    { field: 'programLabel', header: this.labeltranslation.libelleGamme },
    { field: 'updatedDate', header: this.labeltranslation.colonneDateDeDerniereMiseAJour },
    { field: 'userModifier', header: this.labeltranslation.colonneIdentifiantDuDernierModificateur },
    { field: 'noOfCampaigns', header: this.labeltranslation.colonneNombreDeChantiersAssocies },
    { field: 'noOfValidCampaigns', header: this.labeltranslation.colonneNombreDeChantiersAssociesDansLetatValide},
    { field: 'outstandingEdit', header: this.labeltranslation.colonneEncoursDEdit },
  ];

}

async getProgramLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
(data: any) => {
 this.labeltranslation = data.datalist.record;
 console.log(this.labeltranslation)

});  
}

async getLabels()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages_1).toPromise().then(
(data: any) => {
 this.linelabeltranslation = data.datalist.record;
 console.log(this.linelabeltranslation)

});  
}

async getBooleanLabels()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages_2).toPromise().then(
(data: any) => {
 this.blabeltranslation = data.datalist.record;
 console.log(this.blabeltranslation)

});  
}
getFilterValues(){
  this.typeOfFiltersForFilter = [];
  this.typeOfFiltersForFilter.push({label :this.blabeltranslation.yes, value: "yes"});
  this.typeOfFiltersForFilter.push({label :this.blabeltranslation.no, value: "no"});
}  
  

  ngOnDestroy(){
    this.routingService.setCreateBTN(false);
    localStorage.removeItem('AssociationNo');
    this.routingService.setProgAssociate(null);
    this.routingService.setidGamme(null);
    
  }

 
//Redirecting to ChangeProgram
  changeProg() {
    window.localStorage.setItem('isEdit', 'false');
    this.router.navigate(['/change-program']);
  }

  getData(programNumber, programName, userId, fromDate, toDate, includingFamily, linkCampaign) {

    this.dbDetails.programLabel = programName;
    this.dbDetails.programNo = programNumber;
    const dateVal = this.datePipe.transform(fromDate, 'yyyy-MM-dd');
    if (dateVal == null) {
      this.dbDetails.fromDate = null;
    } else {
      const newDate = dateVal + 'T00:00:00.000Z';
      this.dbDetails.fromDate = newDate;
    }
    const todateVal = this.datePipe.transform(toDate, 'yyyy-MM-dd');
    if (todateVal == null) {
      this.dbDetails.toDate = null;
    } else {
      const tonewDate = todateVal + 'T00:00:00.000Z';
      this.dbDetails.toDate = tonewDate;
     }
    this.dbDetails.userModifier = userId;
    this.dbDetails.includingFamily = includingFamily;
    this.dbDetails.linkToCampaign = linkCampaign;
    this.filterProgramNo=null;
    this.filterProgramLabel=null;
    this.filterNoOfValidCampaigns=null;
    this.filterUpdateDate=null;
    this.filterUserModifier=null;
    this.filterNoOfCampaigns=null;
    this.filterOutstandingEdit=null;
    this.sortResult=this.dbDetails;
    this.getRecordsFromDB(this.dbDetails);

    Object.assign(this.sortData, {

      programNo: null,
      programLabel: null,
      updatedDate: null,
      userModifier: null,
      noOfCampaigns: null,
      noOfValidCampaigns: null,
      outstandingEdit: null,

    });
    this.sortResult = this.sortData;

  }

  //Fetching Records from DB for mapping into Table.
  getRecordsFromDB(dbDetails) {
    const totalRecords = true;
    this.programManagementService.getRecords(this.first, this.rows, totalRecords,
       JSON.stringify(dbDetails)).subscribe(
      (data) => {
        if (data.datalist.responseList) {
          this.collapsedVal = true;
          this.isDataAvailable = true;
          if (this.isDataAvailable == true) {
            this.index = this.lastIndex--;
          }
        }
        const res = data.datalist.responseList;
        this.pSearchRecords = res;
        this.totalNumberRecords = data.datalist.totalRecords;
      });
      this.resetSort();
  }

  //Resetting sort Icon
  resetSort() {
    this.table.sortOrder = 0;
    this.table.sortField = '';
    this.table.reset();
   }
  
   //For Sorting and Pagination
  getSortRecord() {
    const totalRecords = true;
    this.programManagementService.getRecords(this.first, this.rows, totalRecords, 
      JSON.stringify(this.sortResult)).subscribe(
      (data) => {
        const res = data.datalist.responseList;
        this.pSearchRecords = res;
        this.totalNumberRecords = data.datalist.totalRecords;
      });
  }

  // This method will work for pagination
  paginate(event) {
    this.first = event.first;

    this.page = event.page;

    this.rows = event.rows;
   
    this.getSortRecord();
  }


  // This method will give lazy loading and sorting method
  loadVehSearchLazy(event: LazyLoadEvent) {
    this.loading = false;

    // this method will sort the data
    if (event.multiSortMeta) {
      if (this.dbDetails != null) {
        this.sortData.programNo = this.dbDetails.programNo;
        this.sortData.programLabel = this.dbDetails.programLabel;
        this.sortData.updatedDate = this.dbDetails.updatedDate;
        this.sortData.userModifier = this.dbDetails.userModifier;
        this.sortData.includingFamily = this.dbDetails.includingFamily;
        this.sortData.linkToCampaign = this.dbDetails.linkToCampaign;
        this.sortData.outstandingEdit = this.dbDetails.outstandingEdit;
      }
      // set the default valu as null for sorting & filtering
      Object.assign(this.sortData, {
        
        programNoOrder: null,
        programLabelOrder: null,
        updatedDateOrder: null,
        userModifierOrder: null,
        noOfCampaignsOrder: null,
        noOfValidCampaignsOrder: null,
        outstandingEditOrder: null,

      });
      if (event.multiSortMeta[0].field == 'programNo' && event.multiSortMeta[0].order == 1) {
        this.sortData.programNoOrder = 'asc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'programNo' && event.multiSortMeta[0].order == -1) {
        this.sortData.programNoOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'programLabel' && event.multiSortMeta[0].order == 1) {
        this.sortData.programLabelOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'programLabel' && event.multiSortMeta[0].order == -1) {
        this.sortData.programLabelOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'updatedDate' && event.multiSortMeta[0].order == 1) {
        this.sortData.updatedDateOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'updatedDate' && event.multiSortMeta[0].order == -1) {
        this.sortData.updatedDateOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'userModifier' && event.multiSortMeta[0].order == 1) {
        this.sortData.userModifierOrder = 'asc ';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'userModifier' && event.multiSortMeta[0].order == -1) {
        this.sortData.userModifierOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfCampaigns' && event.multiSortMeta[0].order == 1) {
        this.sortData.noOfCampaignsOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfCampaigns' && event.multiSortMeta[0].order == -1) {
        this.sortData.noOfCampaignsOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfValidCampaigns' && event.multiSortMeta[0].order == 1) {
        this.sortData.noOfValidCampaignsOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfValidCampaigns' && event.multiSortMeta[0].order == -1) {
        this.sortData.noOfValidCampaignsOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'outstandingEdit' && event.multiSortMeta[0].order == 1) {
        this.sortData.outstandingEditOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'outstandingEdit' && event.multiSortMeta[0].order == -1) {
        this.sortData.outstandingEditOrder = 'desc';
        this.sortResult = this.sortData;
      }
      this.getSortRecord();

    }
  }

  // This method will filter date
  filterDate(event) {
    event = null;
    this.sortData.updatedDate = event;
    this.sortResult = this.sortData;
    this.getRecordsFromDB(this.sortResult);
  }

  // This method will filter data on key down event
  onKeydown(event, field: string) {
    if (field == 'programNo') {
      if(event===""){
        this.sortData.programNo=null
      }else{
        this.sortData.programNo = event;
        }
      this.sortResult = this.sortData;
    } else if (field == 'programLabel') {
      if(event===""){
        this.sortData.programLabel=null}
        else{
        this.sortData.programLabel = event;
        }
      this.sortResult = this.sortData;
    } else if (field == 'userModifier') {
      if(event===""){
        this.sortData.userModifier=null}
        else{
        this.sortData.userModifier = event;
        }
      this.sortResult = this.sortData;
    } else if (field == 'updatedDate') {
      const dateVal = this.datePipe.transform(event, 'yyyy-MM-dd');
      const newDate = dateVal + 'T00:00:00.000Z';
      this.sortData.updatedDate = newDate;
      this.sortResult = this.sortData;
    } else if (field == 'noOfCampaigns') {
      if(event===""){
        this.sortData.noOfCampaigns=null}
        else{
        this.sortData.noOfCampaigns = event;
        }
      this.sortResult = this.sortData;
    } else if (field == 'noOfValidCampaigns') {
      if(event===""){
        this.sortData.noOfValidCampaigns=null}
        else{
        this.sortData.noOfValidCampaigns = event;
        }
      this.sortResult = this.sortData;
    } else if (field == 'outstandingEdit') {
      if (event == 'yes') {
        this.sortData.outstandingEdit = true;
      } else if (event == 'no') {
        this.sortData.outstandingEdit = false;
      } else {
        this.sortData.outstandingEdit = event;
      }
      this.sortResult = this.sortData;
    }
    this.first = 0;
    this.getRecordsFromDB(this.sortResult);


  }

  // This method will Fetch the data  for export to csv
  exportToCSV() {
    let result:string;
    result = JSON.stringify(this.sortResult);
    const totalRecords = true;
    this.programStatusService.exportToCSVRecords(this.rows, this.first, totalRecords, result)
    .subscribe(response => {
        this.downLoadFile(response, 'text/csv');
      },
      (error) => console.log(error)
    );
  }

  // This method will download the csv file
  downLoadFile(data, _type: string) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();
    }
  }

  //For redirecting to Detail page
  goToPage(_event, pNumber) {
    this.progNumber = pNumber;
    this.getSelectedCPService.setSelectedProgNumber(this.progNumber);
    const progSearch = window.localStorage.getItem('progSearch');
    if (progSearch != null && progSearch != undefined) {
      window.localStorage.removeItem('progSearch');
      window.localStorage.setItem('progSearch', this.progNumber);

    } else {
      window.localStorage.setItem('progSearch', this.progNumber);
    }
    if (this.associationNo && this.progNumber) {
      this.router.navigate(['/associations', this.progNumber]);
      localStorage.removeItem('AssociationNo');
    } else if (this.progNumber) {
      this.router.navigate(['/program-list', pNumber]);
    }
  }

  storeProgNo() {
    this.associationNo = window.localStorage.getItem("AssociationNo");
    }
}


