import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';

import { Observable } from 'rxjs';
import LocalStorage from '../util/local-storage';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor() {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

   // console.log('I am in interceptor');
    request = request.clone({
      withCredentials: true,
      setHeaders: {
        Authorization: `${LocalStorage.readToken()}`
      }
    });

    return next.handle(request);
  }
}
