import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LazyLoadEvent, SelectItem, SortMeta } from 'primeng/api';
import { IDeferredTask } from '../models/deferred-task';
import { RoutingService } from '../service/routing.service';
import { StatusAsyncService } from './status-async.service';
import {HeaderService} from '../service/header.service';
import { X2labels, X3labels } from '../models/asynchronousDTO';
import { SideBarLabel } from '../models/sidebar-list';

export class ILogTask {
  idTask: string;
  taskType: string;
  debutExec: string;
  taskState: string;
  finExec: string;
  parameters: string;
  dateCreation: string;
  userCreation: string;
  logTask: string;
  duration: number;
}

export class ITaskType {
  TaskChantierIDOProduce: string;
  TaskUpdateVehiculesOfChantier: string;
}
export class IStatus {
  PLANIFIE: string;
  ENCOURS: string;
  SUCCES: string;
  ECHEC: string;
}

@Component({
  selector: 'app-status-async',
  templateUrl: './status-async.component.html',
  styleUrls: ['./status-async.component.scss']
})
export class StatusAsyncComponent implements OnInit {
  multiSortMeta: SortMeta;
  offsetPositionToStartFrom: number = 0;
  rowsPerPage: number = 10;
  totalNumberRecords: string;
  page: number = 0;
  treatmentTypes: { label: string; value: string; }[];
  processingStatus: SelectItem[];
  deferredTaskDTO: IDeferredTask = {} as IDeferredTask;
  getTotalRecords: boolean = true;
  taskType = {} as ITaskType;
  status = {} as IStatus;
  taskState: string[] = [];
  showProcssList = false;
  statusTypes: { label: string; value: string; }[];
  collapseProcessSearch = false;
  taskId: number;
  displayProcessDetail = false;
  asyncProcessDetails: ILogTask = {} as ILogTask;


  //variable for Process search ngmodel

  selectedIdTask: number;
  selectedTaskType: string;
  selectedDebutExec: string;
  selectedTaskState: string;
  selectedUserCreation: string;
  selectedParameters: string;
  selectedDuration: number;

  selectedDateCreation: string | Date;
  selectedToDateCreation: string | Date;
  selectedFromDateCreation: string | Date;
  selectedFinExec: string | Date; 
  selectedFromDebutExec: string | Date;
  selectedToDebutExec: string | Date;
  filterIdTask: string;
  filterTaskState: string;
  filterDateCreation: string;
  filterDebutExec: string;
  filterDuration: string;
  filterUserCreation: string;
  filterTaskType: string;
  filterParameters: string;
  validateConsistencyNumber: any;
  campaignSearch: string;
  cols: { field: string; header: string; sortable: boolean; }[];
  statusSearchRecords: IDeferredTask = {} as IDeferredTask;
  detailIdTask: string;
  detailTaskType: string;
  detailUserCreation: string;
  detailDateCreation: string;
  detailDebutExec: string;
  detailDuration: number;
  detailTaskState: string;
  detailParameters: string;
  detailLogTask: string;
  pages="X2";
  detailpage="X3"
labeltranslation= {} as  X2labels;
detaillabeltranslation={} as X3labels;
sidepage="D2"
tabletranslation={} as SideBarLabel;

  
  


  constructor(
    private translate: TranslateService,
    private datePipe: DatePipe,
    private statusAsyncService: StatusAsyncService,
    private routingService: RoutingService,
    private headerService: HeaderService
  ) { }

 async ngOnInit() {
    
  await this.getAsyncStatusLabel();
  await this.getAsyncDetailLabel();
  await this.getTableLabels();
  this.getColumnHeader();
  this.getTreatmentType();
    
    this.taskType = {
      TaskChantierIDOProduce: 'IDOs edition for a campaign',
      TaskUpdateVehiculesOfChantier: 'Update of the vehicles from a campaign'
    };

    this.status = {
      PLANIFIE: 'Waiting',
      ENCOURS: 'In progress',
      SUCCES: 'Success',
      ECHEC: 'Failure'
    };

    this.getProcessingStatus();

    this.campaignSearch = window.localStorage.getItem('campaignSearch');
    this.routingService.getValidateAsynParameter().subscribe(val => {
      this.validateConsistencyNumber = val;
      console.log("this.validateConsistencyNumber", this.validateConsistencyNumber)
    })
    if(this.validateConsistencyNumber == true){
      this.selectedParameters = this.campaignSearch;
     this.searchProcess(null, this.selectedParameters, null, null, null, null, null)
    }

   
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getAsyncStatusLabel();
          await this.getTableLabels();
          this.getColumnHeader();
          this.getProcessingStatus();
          this.getAsyncDetailLabel();
          this.getTreatmentType();
        }
      })

  }
  async getAsyncStatusLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     console.log(this.labeltranslation)
    });  
  }

  async getAsyncDetailLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.detailpage).toPromise().then(
    (data: any) => {
     this.detaillabeltranslation = data.datalist.record;
    });  
  }
  async getTableLabels()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.sidepage).toPromise().then(
    (data: any) => {
     this.tabletranslation = data.datalist.record;
     console.log(this.tabletranslation)
    });  
  }


getColumnHeader()
{
  this.cols = [
    { field: 'idTask', header:this.labeltranslation.colonneNumeroDeBatch, sortable: true },
    { field: 'taskState', header: this.labeltranslation.status, sortable: true },
    { field: 'dateCreation', header: this.labeltranslation.requestdate, sortable: true },
    { field: 'debutExec', header: this.labeltranslation.colonneDateDeLancement, sortable: true },
    { field: 'duration', header: this.labeltranslation.colonneDuree, sortable: true },
    { field: 'userCreation', header: this.labeltranslation.colonneIdentifiantDuDemandeur, sortable: true },
    { field: 'taskType', header:this.labeltranslation.colonneTypeTraitement, sortable: true },
    { field: 'parameters', header: this.labeltranslation.colonneParametres, sortable: true }
  ];
}

getProcessingStatus()
{
 
    this.processingStatus = [];
    this.processingStatus.push({ label: this.labeltranslation.attente, value: 'PLANIFIE' });
    this.processingStatus.push({ label: this.labeltranslation.enCours, value: 'ENCOURS' });
    this.processingStatus.push({ label: this.labeltranslation.succes, value: 'SUCCES' });
    this.processingStatus.push({ label: this.labeltranslation.echec, value: 'ECHEC' });



    this.statusTypes = [
      { label: this.labeltranslation.choose, value: null },
      { label: this.labeltranslation.attente, value: 'PLANIFIE' },
      { label: this.labeltranslation.enCours, value: 'ENCOURS' },
      { label:  this.labeltranslation.succes, value: 'SUCCES' },
      { label:  this.labeltranslation.echec, value: 'ECHEC' }
    ];

}
getTreatmentType()

{
  this.treatmentTypes = [
  { label: this.labeltranslation.choose, value: null },
  { label: this.labeltranslation.idoedition, value: 'com.inetpsa.mdl.business.chantier.TaskChantierIDOProduce' },
  { label: this.labeltranslation.updatevehicle, value: 'com.inetpsa.mdl.iface.corvet.TaskUpdateVehiculesOfChantier' }
];

}
  getdeferredtasks() {
    this.statusAsyncService.getdeferredtasks(this.offsetPositionToStartFrom, this.rowsPerPage, JSON.stringify(this.deferredTaskDTO),
      this.getTotalRecords).subscribe(
        (data) => {
          const res = data.responseList;
          this.showProcssList = true;
          this.collapseProcessSearch = true;
          
          for(let i=0;i<res.length;i++){
            if(res[i].taskType.includes("TaskChantierIDOProduce")){
              console.log("Hello");
              res[i].taskType="IDOs edition for a campaign";
            }
            else if(res[i].taskType.includes("askUpdateVehiculesOfChantier")){
              res[i].taskType="Update of the vehicles from a campaign";
            }
          }
          
          this.statusSearchRecords = res;
          console.log( this.statusSearchRecords);
          
          this.totalNumberRecords = data.totalRecords;
        });
  }

  sortData(event: LazyLoadEvent) {
    this.deferredTaskDTO.taskStateOrder = null;
    this.deferredTaskDTO.userCreationOrder = null;
    this.deferredTaskDTO.taskTypeOrder = null;
    this.deferredTaskDTO.parametersOrder = null;
    this.deferredTaskDTO.idtaskOrder = null;
    this.deferredTaskDTO.dateCreationOrder = null;
    this.deferredTaskDTO.debutExecOrder = null;
    this.deferredTaskDTO.durationOrder = null;

    if (event.multiSortMeta) {

      if (event.multiSortMeta[0].field === 'taskState' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.taskStateOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'taskState' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.taskStateOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'userCreation' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.userCreationOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'userCreation' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.userCreationOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'taskType' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.taskTypeOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'taskType' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.taskTypeOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'parameters' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.parametersOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'parameters' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.parametersOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'idTask' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.idtaskOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'idTask' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.idtaskOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'dateCreation' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.dateCreationOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'dateCreation' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.dateCreationOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'debutExec' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.debutExecOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'debutExec' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.debutExecOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'duration' && event.multiSortMeta[0].order === 1) {
        this.deferredTaskDTO.durationOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'duration' && event.multiSortMeta[0].order === -1) {
        this.deferredTaskDTO.durationOrder = 'desc';
      }

      this.getdeferredtasks();
    }
  }

  filterData(event, field: string) {
    if (field === 'idTask') {
      this.deferredTaskDTO.idTask = event;
    } else if (field === 'taskState') {
      this.deferredTaskDTO.taskState = event;
    } else if (field === 'dateCreation') {
      const dateVal = this.datePipe.transform(event, 'yyyy-MM-dd');
      const newDate = dateVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.dateCreation = newDate;
    } else if (field === 'debutExec') {
      const dateVal = this.datePipe.transform(event, 'yyyy-MM-dd');
      const newDate = dateVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.debutExec = newDate;
    } else if (field === 'duration') {
      this.deferredTaskDTO.duration = +event;
    } else if (field === 'userCreation') {
      this.deferredTaskDTO.userCreation = event;
    } else if (field === 'taskType') {
      this.deferredTaskDTO.taskType = event;
    } else if (field === 'parameters') {
      this.deferredTaskDTO.parameters = event;
    }
    this.offsetPositionToStartFrom = 0;
    this.getdeferredtasks();
  }

  filterDate(event, field: string) {
    event = null;
    if (field === 'dateCreation') {
      this.deferredTaskDTO.dateCreation = event;
    } else if (field === 'debutExec') {
      this.deferredTaskDTO.debutExec = event;
    }
    this.getdeferredtasks();
  }

  paginate(event) {
    this.offsetPositionToStartFrom = event.first;
    this.rowsPerPage = event.rows;
    this.page = event.page;
    this.getdeferredtasks();
  }

  exportToCSV() {
    this.statusAsyncService.exportAsyncProcess(this.offsetPositionToStartFrom, this.rowsPerPage, JSON.stringify(this.deferredTaskDTO),
      this.getTotalRecords).subscribe(
        response => this.downLoadFile(response),
        (error) => console.log(error)
      );
  }

  downLoadFile(data) {
    let filename = data.filename.replace("DeferredTask", "ProcessList")
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = filename;
      element.click();
    }
  }

  showProcessDetail(taskId) {
    this.taskId = taskId;
    this.displayProcessDetail = true;
    this.statusAsyncService.gettaskdetail(this.taskId).subscribe(
      (data: ILogTask) => {
        this.asyncProcessDetails = data;
        this.detailIdTask = this.asyncProcessDetails.idTask;
        this.detailTaskType = this.status[this.asyncProcessDetails.taskType];
        this.detailUserCreation = this.asyncProcessDetails.userCreation;
        this.detailDateCreation = this.asyncProcessDetails.dateCreation;
        console.log(this.detailDateCreation , "this.detailDateCreation ");
        
        this.detailDebutExec = this.asyncProcessDetails.debutExec;
        this.detailDuration = this.asyncProcessDetails.duration;
        this.detailTaskState = this.taskType[this.asyncProcessDetails.taskState];
        this.detailParameters = this.asyncProcessDetails.parameters;
        this.detailLogTask = this.asyncProcessDetails.logTask;
      });
  }

  searchProcess(TaskType, Parameters, UserCreation, FromDateCreation,ToDateCreation, FromDebutExec, ToDebutExec){

    const dateVal = this.datePipe.transform(FromDateCreation, 'yyyy-MM-dd');
    if (dateVal == null) {
      this.deferredTaskDTO.fromDateCreation = null;
    } else {
      const newDate = dateVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.fromDateCreation = newDate;
    }
    const todateVal = this.datePipe.transform(ToDateCreation, 'yyyy-MM-dd');
    if (todateVal == null) {
      this.deferredTaskDTO.toDateCreation = null;
    } else {
      const tonewDate = todateVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.toDateCreation = tonewDate;
    }

    const fromDebutVal = this.datePipe.transform(FromDebutExec, 'yyyy-MM-dd');
    if (fromDebutVal == null) {
      this.deferredTaskDTO.fromDebutExec = null;
    } else {
      const newDate = fromDebutVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.fromDebutExec = newDate;
    }
    const toDebutVal = this.datePipe.transform(ToDebutExec, 'yyyy-MM-dd');
    if (toDebutVal == null) {
      this.deferredTaskDTO.toDebutExec = null;
    } else {
      const tonewDate = toDebutVal + 'T00:00:00.000Z';
      this.deferredTaskDTO.toDebutExec = tonewDate;
     }

    this.deferredTaskDTO.taskType = TaskType;
    this.deferredTaskDTO.parameters = Parameters;
    this.deferredTaskDTO.userCreation = UserCreation;
    this.deferredTaskDTO.taskState = this.taskState.join(',');
    this.deferredTaskDTO.idTask = null;
    this.deferredTaskDTO.dateCreation = null;

    this.filterIdTask = null;
    this.filterTaskState = null;
    this.filterDateCreation = null;
    this.filterDebutExec = null;
    this.filterDuration = null;
    this.filterUserCreation = null;
    this.filterTaskType = null;
    this.filterParameters = null;

    this.getdeferredtasks();
  }
}

