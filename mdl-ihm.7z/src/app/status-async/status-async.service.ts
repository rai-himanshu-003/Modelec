import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from '../service/url.service';


@Injectable({
    providedIn: 'root',
})

export class StatusAsyncService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    getdeferredtasks(offsetPositionToStartFrom, rowsPerPage, deferredTaskDTO, getTotalRecords): Observable<any> {

        return this.httpClient.get<any>(this.urlService.getdeferredtasks(), {

            params: {
                offsetPositionToStartFrom: `${offsetPositionToStartFrom}`,
                rowsPerPage: `${rowsPerPage}`,
                deferredTaskDTO: `${deferredTaskDTO}`,
                getTotalRecords: `${getTotalRecords}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    gettaskdetail(taskId): Observable<any> {

        return this.httpClient.get<any>(this.urlService.gettaskdetail(), {

            params: {
                taskId: `${taskId}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }



    exportAsyncProcess(offsetPositionToStartFrom, rowsPerPage, deferredTaskDTO, getTotalRecords): Observable<any> {

        return this.httpClient.get(this.urlService.exportAsyncProcess(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                offsetPositionToStartFrom: `${offsetPositionToStartFrom}`,
                rowsPerPage: `${rowsPerPage}`,
                deferredTaskDTO: `${deferredTaskDTO}`,
                getTotalRecords: `${getTotalRecords}`
            }
        }).pipe(
            map((res: any) => {
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            }),
            // tap(data => console.log('All'+ JSON.stringify(data))),

            catchError(this.handleError)
        );
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is:${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }
}
