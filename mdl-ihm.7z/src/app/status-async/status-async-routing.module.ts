import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StatusAsyncComponent } from './status-async.component';

const routes: Routes = [
  {
    path: '',
    component: StatusAsyncComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StatusManagementRoutingModule { }
