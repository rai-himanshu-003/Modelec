import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusAsyncComponent } from './status-async.component';

describe('StatusAsyncComponent', () => {
  let component: StatusAsyncComponent;
  let fixture: ComponentFixture<StatusAsyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatusAsyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusAsyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
