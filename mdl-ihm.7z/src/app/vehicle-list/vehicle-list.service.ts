import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { URLService } from '../service/url.service';
import { ResponseDto } from '../models/vehicleDetailResponseDto';

@Injectable({
    providedIn: 'root',
})

export class VehicleListService {

    constructor(private httpClient: HttpClient, private urlService: URLService) { }

    getRecords(offsetPositionToStartFrom, rowsPerPage, vehicleListDTO, getTotalRecords): Observable<any> {

        return this.httpClient.get<any>(this.urlService.vehicleListUrl(), {
            params: {
                offsetPositionToStartFrom: `${offsetPositionToStartFrom}`,
                rowsPerPage: `${rowsPerPage}`,
                vehicleListDTO: `${vehicleListDTO}`,
                getTotalRecords: `${getTotalRecords}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getCampaignDetails(codeChantier): Observable<any> {
        return this.httpClient.get<any>(this.urlService.detailCampaignUrl(), {
            params: {
                codeChantier: `${codeChantier}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getVehicleDetails(vehicleDetailDTO): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getvehicledetails(), {
            params: {
                vehicleDetailDTO: `${vehicleDetailDTO}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getvehicleattributes(vehicleCode): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getvehicleattributes(), {

            params: {
                vehicleCode: `${vehicleCode}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getvehicleelectronique(vehicleCode): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getvehicleelectronique(), {

            params: {
                vehicleCode: `${vehicleCode}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    generateidofile(codeChantier, codeVehicle): Observable<any> {
        return this.httpClient.get(this.urlService.generateidofile(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`
            }
        }).pipe(
            map((res: any) => {
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            }),
            // tap(data => console.log('All'+ JSON.stringify(data))),

            catchError(this.handleError)
        );
    }

    updateVehicle(vehicleCode): Observable<any> {
        return this.httpClient.get<any>(this.urlService.updatevehicle(), {

            params: {
                vehicleCode: `${vehicleCode}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    cancelVehicle(codeChantier, codeVehicle): Observable<any> {
        return this.httpClient.get<any>(this.urlService.cancelvehicle(), {

            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }


    getIDO(codeChantier, codeVehicle, idoIndice, vehicleHistory, id): Observable<any> {

        return this.httpClient.get<ResponseDto>(this.urlService.getIDO(), {

            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`,
                idoIndice: `${idoIndice}`,
                vehicleHistory: `${vehicleHistory}`,
                id:`${id}`

            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getTRA(codeChantier, codeVehicle, idoIndice, vehicleHistory, id): Observable<any> {

        return this.httpClient.get<any>(this.urlService.getTRA(), {

            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`,
                idoIndice: `${idoIndice}`,
                vehicleHistory: `${vehicleHistory}`,
                id:`${id}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getIMP(codeChantier, codeVehicle, idoIndice, vehicleHistory, id): Observable<any> {

        return this.httpClient.get<any>(this.urlService.getIMP(), {

            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`,
                idoIndice: `${idoIndice}`,
                vehicleHistory: `${vehicleHistory}`,
                id:`${id}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    getSQP(codeChantier, codeVehicle, idoIndice, vehicleHistory, id): Observable<any> {

        return this.httpClient.get<any>(this.urlService.getSQP(), {

            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`,
                idoIndice: `${idoIndice}`,
                vehicleHistory: `${vehicleHistory}`,
                id:`${id}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    exportToCSVRecords(offsetPositionToStartFrom, rowsPerPage, vehicleListDTO, getTotalRecords): Observable<any> {

        return this.httpClient.get(this.urlService.exportToCSVRecords(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                offsetPositionToStartFrom: `${offsetPositionToStartFrom}`,
                rowsPerPage: `${rowsPerPage}`,
                vehicleListDTO: `${vehicleListDTO}`,
                getTotalRecords: `${getTotalRecords}`
            }
        }).pipe(
            map((res: any) => {
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            }),
            // tap(data => console.log('All'+ JSON.stringify(data))),

            catchError(this.handleError)
        );
    }

    getAttributeRecords(familyCode, attributeCode): Observable<any> {
        return this.httpClient.get<any>(this.urlService.vehicleAttributeAssistant(), {
            params: {
                familyCode: `${familyCode}`,
                attributeCode: `${attributeCode}`
            }
        }).pipe(
            map(
                (res: any) => {
                    // console.log(res);
                    const data = {
                        datalist: res
                    };
                    return data;
                }
            ),
            // catchError(this.handleError)
        );
    }

    getManualInventory(codeChantier, codeVehicle): Observable<any> {
        return this.httpClient.get<any>(this.urlService.manualInventory(), {
            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`
            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    updateCorvetMI(postData): Observable<any> {
        return this.httpClient.post<any>(this.urlService.updateCorvetMI(), postData).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }
    
    updateattribute(postData): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this.httpClient.post<any>(this.urlService.updateattribute(), postData, { headers: headers }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
        // return this.httpClient.get<any>(this.urlService.updateattribute(), {
        //     params: {
        //         attributeAssistantDto: `${postData}`
        //     }
        // }).pipe(
        //     map((data: any) => data),
        //     // tap(data => console.log('All'+ JSON.stringify(data))),
        //     catchError(this.handleError)
        // );
    }

    getAttributeHistory(codeVehicle, attr): Observable<any> {
        return this.httpClient.get<any>(this.urlService.getattributehistory(), {
            params: {
                codeVehicle: `${codeVehicle}`,
                codeClass: `${attr.codeClass}`,
                codeValue: `${attr.codeValue}`,
                natureValue: `${attr.natureValue}`,
                codeChantierValue:  `${attr.codeChantierValue}`

            }
        }).pipe(
            map((data: any) => data),
            // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    exportManualInventory(codeChantier, codeVehicle): Observable<any> {

        return this.httpClient.get(this.urlService.manualInventoryExport(), {
            observe: 'response',
            responseType: 'blob',
            params: {
                codeChantier: `${codeChantier}`,
                codeVehicle: `${codeVehicle}`
            }
        }).pipe(
            map((res: any) => {
                const data = {
                    image: new Blob([res.body], { type: res.headers.get('Content-Type') }),
                    filename: res.headers.get('filename')
                };
                return data;
            }),
            // tap(data => console.log('All'+ JSON.stringify(data))),

            catchError(this.handleError)
        );
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';

        if (err.error instanceof ErrorEvent) {
            errorMessage = `An error occured: ${err.error.message} `;
        } else {
            errorMessage = `Server returned code:${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }
}
