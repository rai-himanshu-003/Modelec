import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LazyLoadEvent, MenuItem, SortMeta } from 'primeng/api';
import { IVehicleList, V1labels } from '../models/vehicle-list';
import { VehicleListService } from './vehicle-list.service';
import { TranslateService } from '@ngx-translate/core';
import { SelectItem } from 'primeng/api';
import { RoutingService } from '../service/routing.service';
import {HeaderService} from '../service/header.service';
import { SideBarLabel } from '../models/sidebar-list';
import { Actionlabels } from '../models/breadcrumbsDTO';

@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.scss']
})
export class VehicleListComponent implements OnInit {

  vehSearchRecords: [];
  totalNumberRecords: number;
  loading: boolean;
  multiSortMeta: SortMeta;
  vehicleListDTO: IVehicleList = {} as IVehicleList;
  statusArray: any[] = [];
  offsetPositionToStartFrom = 0;
  rowsPerPage = 10;
  getTotalRecords = true;
  page = 0;
  campaignDetails: any = {};
  suiVehicleState: SelectItem[] = [];
  statusList: SelectItem[];
  items: MenuItem[];
  selectedVehicleState: string[];
  selectedStatus: string[];
  concat: string;
  role: string;
  checkRole:boolean;
  redirectTo:boolean;
  cols: { field: string; header: string; }[];
  vehicleStatus: { CN: string; CR: string; CM: string; HD: string; };
  pages="V1";
  labeltranslation= {} as  V1labels;
  sidepage="D2";
  tabletranslation= {} as SideBarLabel;
  actionpage="action";
  actiontranslation= {} as Actionlabels;

  constructor(
    private vehicleListService: VehicleListService,
    private route: ActivatedRoute,
    private translate: TranslateService,
    private routingService: RoutingService,
    private headerService:HeaderService
  ) { }

 async ngOnInit() {
  await this.getVehicleLabel();
  await this.getTableLabel();
  await this.getActionLabel();
    this.routingService.getAccessRole().subscribe(role=>{
      this.role=role;
    })
    this.vehicleListDTO.codeChantier = window.localStorage.getItem('campaignSearch');
    this.vehicleListDTO.numeroChantier = +window.localStorage.getItem('campaignSearch');

    this.getColumnHeader();

    this.vehicleStatus = {
      CN: 'To be done',
      CR: 'To be redone',
      CM: 'Modernized',
      HD: 'Off file'
    };

      
    this.getVehicleStatus();

   
    this.headerService.notifyObservable.subscribe( async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
           await this.getVehicleLabel();
           await this.getTableLabel();
           await this.getActionLabel();
           this.getColumnHeader();
           this.getVehicleStatus();
           this.getCampaignDetails();
        
        }
      })
  
    this.getCampaignDetails();

    const value = this.route.snapshot.paramMap.get('value');
    const key = this.route.snapshot.paramMap.get('key');
    if (key !== null && value !== null) {
      if (key === 'status') {
        this.statusArray.push(value);
        this.vehicleListDTO.suiVehicleState = value;
        this.selectedVehicleState = this.vehicleListDTO.suiVehicleState.split(',');
      } else {
        this.vehicleListDTO[key] = value;
        if (key !== 'codeVehicule' && key !== 'codeDossier') {
          this.selectedStatus = [key];
        }
      }
    }
    //  else {
    //   this.vehicleListDTO.suiVehicleState = 'CN,CR';
    //   this.selectedVehicleState = this.vehicleListDTO.suiVehicleState.split(',');
    // }

    this.getData();
  }


  async getVehicleLabel()
  {
  let lang= this.headerService.getlang(); 
   await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
      this.labeltranslation = data.datalist.record;
     console.log(this.labeltranslation)
    });  
  }
  
  async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }
getColumnHeader()
{
  this.cols = [
    { field: 'codeVehicule', header: this.labeltranslation.colonneVin},
    { field: 'status', header: this.labeltranslation.etatVehicule},
    { field: 'lcdv24', header: this.labeltranslation.colonneLcdv24 },
    { field: 'flag', header: this.labeltranslation.colonneFlags }
  ];
}


getVehicleStatus()
{
  this.suiVehicleState = [];
      this.suiVehicleState.push({ label: this.labeltranslation.etatVehiculeAFaire, value: 'CN' });
      this.suiVehicleState.push({ label: this.labeltranslation.etatVehiculeARefaire, value: 'CR' });
      this.suiVehicleState.push({ label: this.labeltranslation.etatVehiculeModernise, value: 'CM' });
      this.suiVehicleState.push({ label: this.labeltranslation.etatVehiculeHorsDossier, value: 'HD' });

      this.statusList = [];
      this.statusList.push({ label: this.labeltranslation.flagImpacte, value: 'impact' });
      this.statusList.push({ label: this.labeltranslation.flagAReprendre, value: 'resume' });
      this.statusList.push({ label: this.labeltranslation.flagARafraichir, value: 'refresh' });
      this.statusList.push({ label: this.labeltranslation.flagAnnule, value: 'canceled' });
      this.statusList.push({ label: this.labeltranslation.flagIncomplet, value: 'incomplete' });

      this.items = [
        { label: this.actiontranslation.listeGammes, url: '../campaign-management' },
        {
          label: this.actiontranslation.detailChantier + this.vehicleListDTO.codeChantier,
          url: '../campaign-number/' + this.vehicleListDTO.codeChantier
        },
        { label:this.actiontranslation.listeVehicules }
      ];
}
async getTableLabel()
{
let lang= this.headerService.getlang(); 
 await this.headerService.getLabel(lang, this.sidepage).toPromise().then(
  (data: any) => {
    this.tabletranslation = data.datalist.record;
   console.log(this.tabletranslation);
  });  
}


  changeVehicleStatus(event) {
    this.vehicleListDTO.suiVehicleState = event.value.join(',');
    // this.vehicleListDTO.status = event.value;
  }

  changeState(event) {
    this.vehicleListDTO.impact = this.vehicleListDTO.resume = this.vehicleListDTO.refresh = this.vehicleListDTO.canceled = false;
    this.vehicleListDTO.incomplete = false;
    event.value.forEach(element => {
      this.vehicleListDTO[element] = true;
    });
  }

  getCampaignDetails() {
    
    this.vehicleListService.getCampaignDetails(this.vehicleListDTO.codeChantier).subscribe(data => {

        if (data) {
          this.campaignDetails = data.campaignInfoAreaDTO;
          let campType = []
          this.concat = '';
          if (data.campaignInfoAreaDTO.natureChantier === 'L') {
            campType.push(this.labeltranslation.local);
          }
          if (data.campaignInfoAreaDTO.chantierBlanc === 1) {
            campType.push(this.labeltranslation.white);
          }
          if (data.campaignInfoAreaDTO.manualInventory === 1) {
            campType.push(this.labeltranslation.manual);
          }
          if (data.campaignInfoAreaDTO.automaticInventory === 1) {
            campType.push(this.labeltranslation.auto);
          }
          if (data.campaignInfoAreaDTO.associationsProcess === 1) {
            campType.push(this.labeltranslation.association);
            if (data.campaignInfoAreaDTO.natureChantier !== 'L' && data.campaignInfoAreaDTO.chantierBlanc !== 1
              && data.campaignInfoAreaDTO.manualInventory !== 1 && data.campaignInfoAreaDTO.automaticInventory !== 1) {
            campType.push(this.labeltranslation.modern);
            }
          } else if (data.campaignInfoAreaDTO.natureChantier !== 'L' && data.campaignInfoAreaDTO.chantierBlanc !== 1
            && data.campaignInfoAreaDTO.manualInventory !== 1 && data.campaignInfoAreaDTO.automaticInventory !== 1
            && data.campaignInfoAreaDTO.associationsProcess !== 1) {
              
            campType.push(this.labeltranslation.modern);
          }
  
          this.concat = campType.join(', ');
        }
      });
    
  }

  getData() {
    this.vehicleListDTO.status = this.statusArray.join(',');
    this.vehicleListDTO.codeVehicule = this.vehicleListDTO.codeVehicule ? this.vehicleListDTO.codeVehicule : null;

    //this.loading = true;
    this.vehicleListService.getRecords(this.offsetPositionToStartFrom, this.rowsPerPage, JSON.stringify(this.vehicleListDTO),
      this.getTotalRecords).subscribe(
        (data: any) => {
          //this.loading = false;
          const res = data.responseList;
          this.vehSearchRecords = res;
          this.totalNumberRecords = data.totalRecords;
          this.statusArray = this.vehicleListDTO.status ? this.vehicleListDTO.status.split(',') : [];
        });
  }

  setStatus(event) {
    if (event.target.checked) {
      this.statusArray.push(event.target.defaultValue);
    } else {
      const index = this.statusArray.indexOf(event.target.defaultValue, 0);
      if (index > -1) {
        this.statusArray.splice(index, 1);
      }
    }
  }

  loadVehSearchLazy(event: LazyLoadEvent) {
    this.vehicleListDTO.vinOrder = null;
    this.vehicleListDTO.statusOrder = null;
    this.vehicleListDTO.lcdv24Order = null;
    this.loading = false;
    if (event.multiSortMeta) {

      if (event.multiSortMeta[0].field === 'codeVehicule' && event.multiSortMeta[0].order === 1) {
        this.vehicleListDTO.vinOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'codeVehicule' && event.multiSortMeta[0].order === -1) {
        this.vehicleListDTO.vinOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'status' && event.multiSortMeta[0].order === 1) {
        this.vehicleListDTO.statusOrder = 'asc';
      } else if (event.multiSortMeta[0].field === 'status' && event.multiSortMeta[0].order === -1) {
        this.vehicleListDTO.statusOrder = 'desc';
      } else if (event.multiSortMeta[0].field === 'lcdv24' && event.multiSortMeta[0].order === 1) {
        this.vehicleListDTO.lcdv24Order = 'asc';
      } else if (event.multiSortMeta[0].field === 'lcdv24' && event.multiSortMeta[0].order === -1) {
        this.vehicleListDTO.lcdv24Order = 'desc';
      }
      console.log(this.vehicleListDTO);
      this.getData();
    }
  }


  onKeydown(event, field: string) {
    console.log(JSON.stringify(event));
    if (field === 'codeVehicule') {
      this.vehicleListDTO.codeVehicule = event.target.value ? event.target.value : null;
    } else if (field === 'status') {
      const status = Object.keys(this.vehicleStatus).find(key => this.vehicleStatus[key] === event.target.value);
      this.vehicleListDTO.suiVehicleState = status;
      // if (status) {
      //   this.statusArray.push(status);
      // } else {
      //   this.statusArray = [];
      // }
    } else if (field === 'lcdv24') {
      this.vehicleListDTO.lcdv24 = event.target.value ? event.target.value : null;
    }
    this.offsetPositionToStartFrom = 0;
    this.getData();
  }

  paginate(event) {
    this.offsetPositionToStartFrom = event.first;
    this.rowsPerPage = event.rows;
    this.page = event.page;
    this.getData();
  }

  exportToCSV() {
    this.vehicleListService.exportToCSVRecords(this.offsetPositionToStartFrom, this.rowsPerPage, JSON.stringify(this.vehicleListDTO),
      this.getTotalRecords).subscribe(
        response => this.downLoadFile(response),
        (error: any) => console.log(error)
      );
  }

  downLoadFile(data: any) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      element.click();
    }
  }
}
