import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ProgramDetailService } from '../service/program-detail.service';
import { MenuItem, ConfirmationService, MessageService } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { RoutingService } from '../service/routing.service';
import { Message } from 'primeng/api';
import {HeaderService} from '../service/header.service';
import { G3labels } from '../models/range-ListDTO';
import { Actionlabels } from '../models/breadcrumbsDTO';
@Component({
  selector: 'app-program-list',
  templateUrl: './program-list.component.html',
  styleUrls: ['./program-list.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None
})
export class ProgramListComponent implements OnInit {

 
  formData: any;
  property: string;
  by: string;
  process: string;
  validate: string;
  pLabel: string;
  publish: string;
  textValue: string;
  created: string;
  isDataAvailable = true;
  deleteBtn: number;
  validated: string;
  checkAssociate: boolean;
  checkAssociateRouter: boolean;
  checkValidate: boolean;
  checkValidatedRouter: boolean;
  progNo: string;
  home: string;
  definitionValable: string;
  programNumber: string;
  progNumber: string;
  items: MenuItem[];
  associatedCampaign: string;
  programNo: string;
  associatedProg: string;
  chkDeleteBtn: boolean = true;
  role: string;
  editBtn: boolean;
  copyBtn: boolean;
  msgs: Message[] = [];
  pages="G3";
  labeltranslation= {} as  G3labels;
  actionpage="action";
  actiontranslation= {} as Actionlabels;
  
  
  //For translating CNF MSG
  alertSuccess:string;
  alertUnsuccess:string;
  deleteCNFMsg: string;
  idGamme: string;
  progSearch: string;
  constructor(
    private router: Router,
    private programDetailService: ProgramDetailService,
    private confirmationService: ConfirmationService,
    private translate: TranslateService,
    private routingService: RoutingService,
    private headerService: HeaderService

  ) {
    // For checking Access Role
    this.routingService.getAccessRole().subscribe((value) => {
      this.role = value;
    });

    
   }

  async ngOnInit() {
    await this.getProgramInfoLabel();
    await this.getActionLabel();
    this.progSearch = window.localStorage.getItem('progSearch');
    this.routingService.getidGamme().subscribe((value)=>{
      this.idGamme=value;
      if(this.idGamme){
      this.getRecordsFromDB();
      }
    });
    this.routingService.getProgAssociate().subscribe((progNo) => {
      this.associatedProg = progNo;
      if(this.associatedProg) {
        this.progSearch=this.associatedProg;
        this.getRecordsFromDB();
      }
    });
    if(this.idGamme){
      this.progSearch=this.idGamme;
    }
    this.getPathName();
    this.storeProgNo();
    // For Translating
    this.deleteConfirm();

     this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
         await this.getProgramInfoLabel();
         await this.getActionLabel();
         this.getPathName();
         this.deleteConfirm();

        }
      })
  }
  deleteConfirm() {// For Translating
      this.alertSuccess=this.labeltranslation.deleteSuccess;
      this.alertUnsuccess=this.labeltranslation.deletfail;    
  }
async getProgramInfoLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   this.deleteCNFMsg=this.labeltranslation.confirmDelete;
   console.log(this.labeltranslation)
  });  
}
async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }
 getPathName()
 {
 
    this.items = [   
      {label: this.actiontranslation.listeGammes,url: '../program-management'},
      {label: this.actiontranslation.detailGamme+this.progSearch},

    ];

 }
  changeProg() {
    window.localStorage.setItem('isEdit', 'true');
    window.localStorage.setItem('fromAssociation',this.associatedProg);
    this.router.navigate(['/change-program']);
  }

  copyProgram() {
    this.router.navigate(['/copy-program', this.progNumber]);
  }


  redirectToAssociate(associated) {
    this.routingService.setValue(true);
    if (associated > 0) {
      window.localStorage.setItem('associated', this.programNo);
      this.router.navigate(['/campaign-management']);
    }
  }

  redirectToValidate(validate) {
    if (validate > 0) {
      this.routingService.setValidatedValue(true);
      this.routingService.setValue(true);
      window.localStorage.setItem('associated', this.programNo);
      this.router.navigate(['/campaign-management']);
    }
  }

  deleteProg() {
    this.msgs = [];
    this.confirmationService.confirm({
      message:this.deleteCNFMsg,
      accept: () => {
        this.programDetailService.deleteProg(this.progNumber).subscribe(
          (data: any) => {
            this.formData = data.datalist;
              if(data.datalist.msg===true){
                this.msgs.push({severity:'success', summary:'', detail:this.alertSuccess});
                setTimeout(() => {
                 this.router.navigate(['/program-management']);
                  }, 5000);
              }
              else{
                this.msgs.push({severity:'error', summary:'Error', detail:this.alertUnsuccess});
              }
          }
        );
      }
    });
  }

  storeProgNo() {
    // Set the value of Vin number in variable
    this.programNumber = window.localStorage.getItem('progSearch');
    // If value is not null or undefined then call get data
    if (this.programNumber != null && this.programNumber != undefined) {
      window.localStorage.setItem('programNumber', this.programNumber);
      this.getRecordsFromDB();
    }
  }
  getRecordsFromDB() {
    const pNumber: string = window.localStorage.getItem('programNumber');
    if (this.associatedProg != null && this.associatedProg != undefined && this.associatedProg != "") {
      this.progNumber = this.associatedProg;
    }
    else if (pNumber != null && pNumber != undefined) {
      this.progNumber = this.programNumber;
    }
    if(this.idGamme !=null && this.idGamme !=undefined && this.idGamme != ''){
      this.progNumber=this.idGamme;
    }
    this.programDetailService.getProgInfo(this.progNumber).subscribe(
      (data: any) => {
        data.datalist.createdDate = new Date(data.datalist.createdDate as Date);
        if(data.datalist.type=='VNVO'){
          data.datalist.type='VN/VO';
        }
        this.formData = data.datalist;
        this.programNo = data.datalist.programNo;
        if (data.datalist.noOfCampaigns == 0) {
          this.checkAssociate = true
        }
        else {
          this.checkAssociateRouter = true;
        }
        if (data.datalist.noOfValidCampaigns == 0) {
          this.checkValidate = true
        }
        else {
          this.checkValidatedRouter = true;
        }
        this.deleteBtn = this.formData.noOfCampaigns;
        if (this.role.includes('POME') || this.role.includes('RETOUCHEUR') ) {
          this.chkDeleteBtn = true;
          this.editBtn = true;
          this.copyBtn = true;
        }
        else if(this.deleteBtn === 0){
          this.chkDeleteBtn = false;
        }
      }
    );
  }
}
