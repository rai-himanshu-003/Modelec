import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';

import { ProgramListRoutingModule } from './program-list-routing.module';
import {InputTextareaModule} from 'primeng/inputtextarea';
import { TranslateModule } from '@ngx-translate/core';

import {AccordionModule} from 'primeng/accordion';
import { ProgramListComponent } from './program-list.component';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {  ConfirmationService } from 'primeng/api';

import {PanelModule} from 'primeng/panel';


@NgModule({
  imports: [
    CommonModule,
    BreadcrumbModule,
    InputTextareaModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    ProgramListRoutingModule,
    PanelModule
  ],
  declarations: [ProgramListComponent],
  providers: [ConfirmationService]
})
export class ProgramListModule {}


