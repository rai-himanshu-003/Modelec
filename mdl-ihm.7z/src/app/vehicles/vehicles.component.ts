import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { C3label } from '../models/campaign-list';
import { CampaignNumberService } from '../service/campaign-number.service';
import { HeaderService } from '../service/header.service';

@Component({
  selector: 'app-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.css']
})
export class VehiclesComponent implements OnInit {
  cols: any[];
  Records: any[];
  vehRecords: any[] = [];
  vinNumber: string;
  campaignData: string;
  campaignValue: string;
  pages:string="C3"
  labeltranslation= {} as C3label

constructor(
  private campaignNumberService: CampaignNumberService,
  private headerService:HeaderService,
  public router: Router,
  private translate: TranslateService
) { }

  ngOnInit() {
  
      this.getCampaignLabel();
          this.headerService.notifyObservable.subscribe(res=>
            {
              if(res.refresh)
              {
                this.translate.currentLang=res.lang;
                this.getCampaignLabel();
              }
            })
    this.storeCampaignCode();
    // this.cols = [
    //   { field: 'Nb', header: 'Nb remain to be done' },
    //   { field: 'modernized', header: 'Nb modernized' },
    //   { field: 'file', header: 'Nb off file' },
    //   { field: 'cancelled', header: 'Nb cancelled' },
    //   { field: 'redone', header: 'Nb to be redone' },
    //   { field: 'toRefresh', header: 'Nb to refresh' },
    //   { field: 'resume', header: 'Nb to be resumed' },
    //   { field: 'IDO', header: 'Incomplete IDO number' },
    // ];
  }

  redirectTo(key, value) {
    if (!value) {
      this.router.navigate(['/vehicle-list']);
    } else {
      this.router.navigate(['/vehicle-list', key, value]);
    }
  }

  storeCampaignCode() {
    this.campaignData = window.localStorage.getItem('campaignSearch');
    if (this.campaignData !== null && this.campaignData !== undefined) {
      window.localStorage.setItem('campaignData', this.campaignData);
      this.getRecordsFromDB();
    }
  }

  getRecordsFromDB() {

    const campaignNumber: string = window.localStorage.getItem('campaignData');

    if (campaignNumber !== null && campaignNumber !== undefined) {
      this.campaignValue = campaignNumber;
      console.log(this.campaignValue);
    } else {
      console.log('no Vin found');
    }
    this.campaignNumberService.getRecords(this.campaignValue).subscribe(
      (data: any) => {
        this.vehRecords = (data.datalist.vehicleAreaDTO);
        this.vehRecords = Array.of(this.vehRecords);
      }
    );
  }

  getCampaignLabel()
{
let lang= this.headerService.getlang(); 
this.headerService.getLabel(lang, this.pages).subscribe(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
}
