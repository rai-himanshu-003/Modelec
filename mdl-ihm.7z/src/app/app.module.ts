// import angular specific Modules
import { CommonModule, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, Injector, APP_INITIALIZER } from '@angular/core';
import { FormsModule } from '@angular/forms';
// import angular custom Modules
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { TokenInterceptor } from './interceptor/token-interceptor';
// import external Modules
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { AuthGuard } from './shared';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateService } from '@ngx-translate/core';
// import { NonceQueryParamInterceptor } from './shared/services/refresh.service';
import { LayoutModule } from './layout/layout.module';
import { AppConfig } from './app.config';
import { environment } from './environments/environment';
import { OAuthModule } from 'angular-oauth2-oidc';
import {IsAliveComponent} from './is-alive/is-alive.component';
import { BnNgIdleService } from 'bn-ng-idle';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
// AoT requires an exported function for factories
export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};

export function initializeApp(appConfig: AppConfig) {
  console.log(environment.configFile)
  return () => appConfig.load(environment.configFile);
}

let apiURL = function getUrl(appConfig: AppConfig){
  console.log(apiURL)
  console.log("API"+appConfig.getAppConfig());
  return appConfig.getAppConfig();
}

export let InjectorInstance: Injector;

@NgModule({
  declarations: [ AppComponent, IsAliveComponent],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    LayoutModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ConfirmDialogModule,
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: createTranslateLoader,
          deps: [HttpClient]
      }
  }),

  OAuthModule.forRoot({
    resourceServer: {
        // allowedUrls: ['http://vehicle-copy.staging-vehicle-copy.psa-cloud.com/vdt'],
        //allowedUrls: ['http://localhost:9090/mdlmicroservice'],
allowedUrls: [`${apiURL}`],
        sendAccessToken: true
    }
  })
   // NgbModule.forRoot()
  ],
  providers: [
    AppConfig,
    TranslateService,
    BnNgIdleService,
    ConfirmationService ,
    { provide: APP_INITIALIZER,useFactory: initializeApp,deps: [AppConfig], multi: true}, 
    {provide:HTTP_INTERCEPTORS, useClass:TokenInterceptor, multi:true},
     {provide:LocationStrategy, useClass: PathLocationStrategy}
  ],

  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private injector: Injector) {
      InjectorInstance = this.injector;
      console.log(InjectorInstance);
  }
}
