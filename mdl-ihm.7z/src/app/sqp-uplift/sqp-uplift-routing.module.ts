import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SqpUpliftFeedbackComponent } from './sqp-uplift-feedback/sqp-uplift-feedback.component';
import { SqpUpliftComponent } from './sqp-uplift.component';

const routes: Routes = [
  {
    path: '',
    component: SqpUpliftComponent
  },
  {
    path: 'feedback',
    component: SqpUpliftFeedbackComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SQPManagementRoutingModule { }
