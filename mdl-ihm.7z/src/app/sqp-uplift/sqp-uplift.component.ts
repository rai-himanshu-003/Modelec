import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { sqpUpliftService } from '../service/sqpUplift.service';
import { loadSQP, S1LabelsDTO } from './loadSQP';
import { RoutingService } from '../service/routing.service';
import { Message } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { HeaderService } from '../service/header.service';
@Component({
  selector: 'app-sqp-uplift',
  templateUrl: './sqp-uplift.component.html',
  styleUrls: ['./sqp-uplift.component.scss']
})
export class SqpUpliftComponent implements OnInit {

  postSQP = {} as loadSQP;
  sqpOperator:string;
  invalidZIPmsgs: Message[] = [];
  notAZip:string;
  invalidFile:string;
  
  msgs: Message[] = [];
  emptyFile: any;
  prodCenterMsg:string="";
  fileFormateMsg:string="";
  pages="S1";
  labeltranslation= {} as S1LabelsDTO;

  constructor(
    private sqpUpliftservice:sqpUpliftService,
    private headerService: HeaderService,
    public router: Router,
    public routingService : RoutingService,
    public translate : TranslateService
    ) { 
      this.routingService.getUserID().subscribe((value)=>{
        this.sqpOperator=value;
        this.postSQP.userId = this.sqpOperator;
      })
    }

  async ngOnInit() {
    await this.getSQPLabel();
   // this.translate.stream('notAZip').subscribe((value)=>{
      this.notAZip = this.labeltranslation.notzip;
    
    //this.translate.stream('invalidFile').subscribe((value)=>{
      this.invalidFile = this.labeltranslation.invalidFileType;
    //});
    //this.translate.stream('emptyFile').subscribe(value=>{
      this.emptyFile= this.labeltranslation.errorfilePathNotSelected;
   // });
  
   this.headerService.notifyObservable.subscribe(async res=>
     {
       if(res.refresh)
       {
         this.translate.currentLang=res.lang;
        await this.getSQPLabel();
        if(this.prodCenterMsg!=""){
          this.prodCenterMsg=this.labeltranslation.errorfilePathNotSelected;
          this.pushErrorMsgFile();}
          if(this.fileFormateMsg!=""){
            this.fileFormateMsg=this.labeltranslation.notzip;
            this.pushFileFormateMsg();}
       }
     })
     
   }
   async getSQPLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
(data: any) => {
 this.labeltranslation = data.datalist.record;
 console.log(this.labeltranslation)

});  
}
  
pushErrorMsgFile(){
  this.msgs.push({severity:'error', summary:'Error', detail:this.prodCenterMsg});
}

pushFileFormateMsg(){
  this.msgs.push({severity:'error', summary:'Error', detail:this.fileFormateMsg});
}


   onUpload(event){
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
        this.postSQP.file=file;
      }
  }
  loadSQP(){
   // debugger
    if(!this.postSQP.file){
     //this.msgs = [];
      //this.msgs.push({severity:'error', summary:'Error', detail:this.emptyFile});
      this.prodCenterMsg=this.labeltranslation.errorfilePathNotSelected;
      this.pushErrorMsgFile();
    }
    else{this.prodCenterMsg=""}

    if(!this.postSQP.file){
       this.fileFormateMsg=this.labeltranslation.notzip;
       this.pushFileFormateMsg();
    }
    this.sqpUpliftservice.loadSQPRecord(this.postSQP).subscribe(
      (data:any)=>{
        if(data.msg == true){
        this.sqpUpliftservice.sqpfeedbackresult(this.postSQP).subscribe(
          (value:any)=>{
            this.routingService.setsqpResult(value);
          }
        );
        this.router.navigate(['/sqp-uplift/feedback'])
        }
        else if(data.msg == false){
          if(data.message.includes('Not a zip')){
          let val = data.message.indexOf('Not'[0]);
          let valData = data.message.substring(0,[val]);
          this.invalidZIPmsgs.push({severity:'error', summary:'Error', detail:valData +" "+this.notAZip});
        }
       else if(data.message.includes('Invalid File')){
          let val = data.message.indexOf('Invalid'[0]);
          let valData = data.message.substring(0,[val]);
          this.invalidZIPmsgs.push({severity:'error', summary:'Error', detail:valData +" "+this.invalidFile});
        }
      }
      }
    ); 
  }
}
