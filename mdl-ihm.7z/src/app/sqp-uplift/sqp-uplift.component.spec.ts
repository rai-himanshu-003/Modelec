import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SqpUpliftComponent } from './sqp-uplift.component';

describe('SqpUpliftComponent', () => {
  let component: SqpUpliftComponent;
  let fixture: ComponentFixture<SqpUpliftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SqpUpliftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SqpUpliftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
