import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { loadSQP, S2LabelsDTO } from '../loadSQP';
import { RoutingService } from 'src/app/service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import { HeaderService } from 'src/app/service/header.service';

@Component({
  selector: 'app-sqp-uplift-feedback',
  templateUrl: './sqp-uplift-feedback.component.html',
  styleUrls: ['./sqp-uplift-feedback.component.scss']
})
export class SqpUpliftFeedbackComponent implements OnInit {

  items: MenuItem[];
  errorsData: any[];
  warningsData: any[];
  postSQP = {} as loadSQP;
  synthesisColumns: { field: string; header: string; }[];
  errorsColumns: { field: string; header: string; }[];
  warningsColumns: { field: string; header: string; }[];
  synthesisData: { nbRefused: number; nbOK: number; nbKO: number; nbUnchanged: number; nbChanged: number; }[];
  pages="S2";
  labeltranslation= {} as S2LabelsDTO;

  constructor(
    
    public routingService : RoutingService,
    private translate: TranslateService,
    private headerService : HeaderService
  ) { }

  async ngOnInit() {
    await this.getSQPResultLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
         await this.getSQPResultLabel();
         this.getSyntheticCols();
         this.getWarningCols();
        
        }
      })
    this.routingService.getsqpResult().subscribe((data)=>{
      let synthesis = {
        'nbRefused': data.nbRefused,
        'nbOK': data.nbOK,
        'nbKO': data.nbKO,
        'nbUnchanged': data.nbUnchanged,
        'nbChanged': data.nbChanged
      }
      

      this.synthesisData = [synthesis];
      this.errorsData = data.collectionError ? data.collectionError : [];
      this.warningsData = data.collectionResult ? data.collectionResult : [];
      this.errorsData.forEach(x=> {
        x.msg = this.getErrorMsg(x);
      });
      this.warningsData.forEach(x=> {
        x.reasonMsg = this.getErrorMsg(x.error);        
      });

    });
    
    this.items = [
      { label: 'Modernization feedback', url: '../sqp-uplift' },
      { label: 'Modernization feedback result' },
    ];

    

    this.errorsColumns = [
      { field: 'msg', header: 'Error' }
    ];

    
  this.getSyntheticCols();
  this.getWarningCols();
  }

  getSyntheticCols()
    {
      this.synthesisColumns = [
        { field: 'nbRefused', header: this.labeltranslation.nbRejet },
        { field: 'nbOK', header: this.labeltranslation.nbOk },
        { field: 'nbKO', header: this.labeltranslation.nbKo },
        { field: 'nbUnchanged', header: this.labeltranslation.nbInchanges},
        { field: 'nbChanged', header: this.labeltranslation.nbModifies }
      ];
    }

    getWarningCols(){
      this.warningsColumns = [
        { field: 'codeChantier', header: this.labeltranslation.colonneNumeroChantier },
        { field: 'codeVehicule', header: this.labeltranslation.colonneVin },
        { field: 'etatSuivi', header: this.labeltranslation.colonneEtat },
        { field: 'rejected', header: this.labeltranslation.colonneRejet },
        { field: 'reasonMsg', header: this.labeltranslation.colonneMotif },
        { field: 'previousState', header: this.labeltranslation.colonneEtatPrecedent }
      ];
    }

    async getSQPResultLabel()
    {
    let lang= this.headerService.getlang(); 
    await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     console.log(this.labeltranslation)
    
    });  
    } 

  getErrorMsg(data) {
    switch (data.key) {
      case 'error.sqp.testforbidden': 
      let displayData = this.labeltranslation.testingido;
      return displayData;
      //return data.args[0] + ' : A testing IDO shall not be used to update a vehicle';

      case 'error.sqp.invalidcontent': 
      return data.args[0] + ' : The structure of the file name is incorrect';

      case 'error.sqp.nosuchchantier': 
      return data.args[0] + ' : Campaign ' + data.args[1] +' unknown';

      case 'error.sqp.nosuchvehiculeinchantier': 
      return data.args[0] + ' : Vehicle '+data.args[2]+' unknown for the campaign '+data.args[1];

      case 'error.sqp.visdoesnotmatch': 
      return data.args[0] + ' : The VIS '+data.args[1]
      +' indicated inside the SQP file is different from the one given in the filename structure '+data.args[2];

      case 'error.tra.visdoesnotmatch': 
      return data.args[0] + ' : The VIS '+data.args[1]
      +' indicated inside the TRA file is different from the one given in the filename structure '+data.args[2];

      case 'error.sqp.oneokbutlastko': 
      return 'Different files of the same ZIP give contradictory SQP statuses for the vehicle '+ data.args[0] +' of the campaign '+ data.args[1] +' (index '+ data.args[2] +')';

      case 'error.sqp.waitnewido': 
      return 'A new release of the vehicle IDO '+data.args[1]+' for the campaign '+data.args[0]+' is being calculated';

      case 'error.sqp.idoIndiceIsNull': 
      return 'The release index of the vehicle IDO '+data.args[1]+' in the campaign '+data.args[0]+' is null instead of '+data.args[2];

      case 'error.sqp.idoIndiceGlobalIsNull': 
      return 'The release global index of the vehicle IDO '+data.args[1]+' in the campaign '+data.args[0]+' is null instead of '+data.args[2];

      case 'error.sqp.indiceillegal': 
      return 'The SQP revision index '+data.args[3]+' of the vehicle '+data.args[1]+' in the campaign '+data.args[0]+' is inconsistent with the one '+data.args[2]+' from the campaign';

      case 'error.sqp.indicetoolow': 
      return 'The SQP revision index '+data.args[3]+' of the vehicle '+data.args[1]+' in the campaign '+data.args[0]+' is inconsistent with the one '+data.args[2]+' from the campaign';

      case 'error.sqp.failedduetotraca': 
      return 'The traceability file for the vehicle '+data.args[1]+' of the campaign '+data.args[0]+' index '+data.args[2]+' is invalid';

      case 'error.sqp.failedduetounabletoparseCORVETresponse': 
      return 'Unable to parse the response from Corvet';

      case 'error.sqp.failedduetoCORVET': 
      return 'Corvet Unavailable';

      case 'Error 202:  modernization already taken into account by Corvet': 
      return 'Error 202:  modernization already taken into account by Corvet';

      default:
        return data.key;
    }
  }

}
