import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SqpUpliftFeedbackComponent } from './sqp-uplift-feedback.component';

describe('SqpUpliftFeedbackComponent', () => {
  let component: SqpUpliftFeedbackComponent;
  let fixture: ComponentFixture<SqpUpliftFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SqpUpliftFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SqpUpliftFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
