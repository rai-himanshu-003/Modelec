
export class loadSQP{
    file:string|File|any;
    userId:string|any;
}

export class S1LabelsDTO{
    chargerSQPhelp: string;
    chargerSQPlabel: string;
    errorfilePathNotSelected: string;
    fichier: string;
    invalidFileType : string;
    loadFail : string;
    loadSucess : string;
    operateur : string;
    trace :string;
    notzip : string;
}

export class S2LabelsDTO{
    colonneErreur : string;
    colonneEtat : string;
    colonneEtatPrecedent : string;
    colonneMotif :string;
    colonneNumeroChantier : string;
    colonneRejet: string;
    colonneVin: string;
    nbInchanges: string;
    nbKo: string;
    nbModifies: string;
    nbOk: string;
    nbRejet: string;
    zoneAlertes: string;
    zoneErreursSyntaxiques: string;
    zoneSynthese: string;
    testingido : string

}