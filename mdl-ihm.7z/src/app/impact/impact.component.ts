import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { SortMeta, MenuItem } from 'primeng/api';
import { ImpactService } from '../service/impact.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RoutingService } from '../service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import {HeaderService} from '../service/header.service';
import { G7labels } from '../models/impactScreenDTO';
import { Actionlabels } from '../models/breadcrumbsDTO';
@Component({
  selector: 'app-impact',
  templateUrl: './impact.component.html',
  styleUrls: ['./impact.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ImpactComponent implements OnInit, OnDestroy {

   
   multiSortMeta: SortMeta;
   typeOfFiltersForFilter: any[] = [];
   items : MenuItem[];
 
  originCollapsed:boolean=false;
  issueCollapsed:boolean=false;
  issuesCol:any[];
  errorCol:any[];
  issuesRecords:any[];
  errorRecords:any[];
  conflictsCol:any[];
  conflictsRecords:any[];
  impactCols:any[];
  csvSeparator: string = ";"
  impactRecords:any[];
  campaignSearch: string;
  formdata:any;
  formVal: any;
  recallvehicle: string;
  vehState: any[] = [];
  input: string;
  impactVal: string;
  originMsg: string;
  etatChange:any;
  draftRuleset: any;
  gammeType: string;

  mnemonic: string;
  idGammeA: string;
  idGammeB: string;
  valueA: string;
  valueB: string;

  checkRoute : any;

  hasIssues:boolean=true;
  hasError:boolean=true;
  pages="G7";
  labeltranslation= {} as  G7labels;
  actionpage="action";
  actiontranslation= {} as Actionlabels;

  impactDetailsData: any;
  constructor(
    private impactService : ImpactService,
    public router: Router,
    private route: ActivatedRoute,
    public routingService : RoutingService,
    private translate: TranslateService,
    private headerService:HeaderService
  ) {
  }

      ngOnInit() {
     this.getImpactScreenLabel();
    this.getActionLabel();
    this.etatChange=null;
    
     this.campaignSearch = window.localStorage.getItem('campaignSearch');
    
    this.routingService.getImpactRules().subscribe(data=> {
      this.draftRuleset = data.draftRuleset;
      this.gammeType = data.gammeType;
    })
   
    this.draftRuleset=window.localStorage.getItem("draftRuleset");
    this.gammeType=window.localStorage.getItem("gammeType");
    console.log(this.draftRuleset,"this.draftRuleset");
    

    this.impactVal = this.route.snapshot.paramMap.get('impactVal');
    this.input= this.route.snapshot.paramMap.get('input');
    this.checkRoute = window.localStorage.setItem('route', this.input);
    console.log(window.localStorage.getItem('route'));
    

    this.getImpactRecords();

    this.headerService.notifyObservable.subscribe( res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
           this.getImpactScreenLabel();
           this.getActionLabel();  
           this.getColumnHeader(); 
           this.getPathName();    
        }
      })
  }
   async getImpactScreenLabel()
  {
  let lang= this.headerService.getlang(); 
   await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;  
     console.log(this.labeltranslation)
    });  
  }

  getActionLabel()
{
  let lang= this.headerService.getlang(); 
   this.headerService.getLabel(lang, this.actionpage).subscribe(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     this.getColumnHeader();
     this.getPathName();
     console.log(this.actiontranslation)
    });  
  }

getColumnHeader()
{
  this.typeOfFiltersForFilter = [];
  this.typeOfFiltersForFilter = [
    { label: 'YES', value: 'YES' },
    { label: 'ALL', value: null }
  ];
this.vehState =[
  { label: 'ALL', value: null },
  { label: 'CN', value: 'CN' },
  { label: 'CM', value: 'CM' }
]

this.issuesCol = [
  { field: 'codeVehicule', header: this.labeltranslation.colonneAnomalieVin},
  { field: 'error', header: this.labeltranslation.colonneCriticite},
  { field: 'message.key', header: this.labeltranslation.colonneDescriptifAnomalie }
];

this.errorCol = [
  { field: 'key', header: this.labeltranslation.colonneDescriptifAnomalie }
];

this.conflictsCol = [
  { field: 'codeVehicule', header: this.labeltranslation.colonneConflitVin },
  { field: 'mnemonic', header: this.labeltranslation.colonneMnemoniqueEnConflit},
  { field: 'idGammeA', header: this.labeltranslation.colonneNumeroDeLaGammeA},
  { field: 'valueA', header: this.labeltranslation.colonneValeurFixeeParLaGammeA },
  { field: 'idGammeB', header: this.labeltranslation.colonneNumeroDeLaGammeB},
  { field: 'valueB', header: this.labeltranslation.colonneValeurFixeeParLaGammeB }
];
this.impactCols = [
  { field: 'codeVehicule', header: this.labeltranslation.colonneConflitVin },
  { field: 'sitenumber', header: this.labeltranslation.colonneNumeroChantier },
  { field: 'idoIndex', header: this.labeltranslation.colonneNumeroRevisionIDO },
  { field: 'etatSuivi', header: this.labeltranslation.colonneEtatVehicule },
  { field: 'recallvehicle', header: this.labeltranslation.colonneVehiculeARappeler}
];
}

getPathName()
{
  if(this.input == "VALIDATE_ALL_DRAFT_LINKS") {
    
      this.items = [
        { label: this.actiontranslation.rechercherChantiers,url: '../campaign-management'},
        { label: this.actiontranslation.detailChantier+ this.impactVal, url: '../campaign-number/' + this.campaignSearch},
        { label: this.actiontranslation.associationChantierGamme+ this.impactVal, url: '../associations/' + this.campaignSearch},
        { label: this.actiontranslation.impact }
      ];
      //this.originMsg = val["Change in the Link Campaign"] + ' ' + this.impactVal+"/ "+val["Program"];
    
    this.originMsg=this.labeltranslation.modificationDAssociationChantierGamme;
  } else if(this.input == "VALIDATE_DRAFT_GAMME") {

      this.items = [
        { label: this.actiontranslation.listeGammes, url: '../program-management' },
        { label: this.actiontranslation.detailGamme+ this.impactVal, url: '../program-list/' + this.impactVal },
        { label: this.actiontranslation.editionGamme+ this.impactVal, routerLink: ['/change-program'] },
        { label: this.actiontranslation.impact }
      ];
  
    this.originMsg = this.labeltranslation.modificationDeReglesDUneGamme;
  } else if(this.input == "VEHICULE_UPDATE") {
      this.items = [
        { label: this.actiontranslation.rechercherChantiers, url: '../campaign-management' },
        {
          label: this.actiontranslation.detailChantier + this.campaignSearch,
          url: '../campaign-number/' + this.campaignSearch
        },
        { label: this.actiontranslation.listeVehicules, url: '../vehicle-list' },
        { label: this.actiontranslation.detailVehicule + this.impactVal, url: '../vehicle-detail/' + this.impactVal },
        { label: this.actiontranslation.impact }
      ];
    this.originMsg = this.labeltranslation.miseAJourVehicule;
  }
}

  getImpactRecords(){
    //let input = 'VALIDATE_ALL_DRAFT_LINKS';
    this.impactService.getImpact(this.impactVal, this.input, this.draftRuleset, this.gammeType).subscribe((data:any)=>{
      console.log(data.datalist.nature)
      this.formdata=data.datalist;
      for(let i=0;i<data.datalist.problemsList.length;i++){
        for(const key in data.datalist.problemsList[i]){
          if(key === 'error' && data.datalist.problemsList[i][key] === true){
            data.datalist.problemsList[i][key]  = "Error";
          }
          else if(key === 'error' && data.datalist.problemsList[i][key] === false){
            data.datalist.problemsList[i][key]  = "Warning";
          } 
        }
      }
     this.conflictsRecords = data.datalist.conflictList;
     this.issuesRecords = data.datalist.problemsList;
     this.errorRecords = data.datalist.errors.messages;
     console.log("this.errorRecords", this.errorRecords);
     if(this.issuesRecords.length == 0){
       this.hasIssues=false;
     }
     if(this.errorRecords.length == 0){
       this.hasError=false;
     }
     
     if (this.issuesRecords) {
      this.issuesRecords.forEach(e => {
        if (e.message.key.includes("error.gamme.runner.missinghard" || "error.gamme.runner.noautovalue"
          || "error.chantier.process.missingattributes" || "error.gamme.runner.noValueForLcdvAttribute" ||
          'error.gamme.runner.noLcdvAttributeFoundForCentralAttribute' || "error.gamme.runner.conflict"
          || "error.gamme.runner.missingkey")) {
          this.conflictsRecords.forEach(v => {
            if (v.codeVehicule == e.codeVehicule) {
              this.mnemonic = v.mnemonic;
              this.idGammeA = v.idGammeA;
              this.idGammeB = v.idGammeB;
              this.valueA = v.valueA;
              this.valueB = v.valueB;
            }
          })
        }
      })
    }
      console.log(data.datalist.problemsList,"proglist")
      
      console.log(data.datalist.conflictList,"conflist")
      this.impactRecords = data.datalist.impactList;
      for(let i = 0; i<data.datalist.impactList.length;i++){
        for(const key in data.datalist.impactList[i]){
          if(key==='etatSuivi'){
          if(data.datalist.impactList[i][key] === 'CM'){
            this.impactRecords[i].recallvehicle= 'YES';
          }
          }
        }
      }
      console.log(data.datalist.impactList,"implist")
    });
  }

  //For exporting CSV
  exportCSV(filteredValue) {
    var _this = this;
    var data = filteredValue || this.impactRecords || [];
    var csv = 'sep=;\r\n';
    //headers
    for (var i = 0; i < this.impactCols.length; i++) {
        var column = this.impactCols[i];
        if (column.exportable !== false && column.field) {
            csv += '"' + (column.header || column.field) + '"';
            if (i < (this.impactCols.length - 1)) {
                csv += this.csvSeparator;
            }
        }
    }
    //body
    data.forEach(function (record) {
        csv += '\n';
        for (var i_1 = 0; i_1 < _this.impactCols.length; i_1++) {
            var column = _this.impactCols[i_1];
            if (column.exportable !== false && column.field) {
                 var cellData = record[column.field];
                 if (cellData != null) {
                    cellData = String(cellData).replace(/"/g, '""');
                 }
                 else {
                    cellData = '';
                 }
                 csv += '"' + cellData + '"';
                if (i_1 < (_this.impactCols.length - 1)) {
                    csv += _this.csvSeparator;
                }
            }
        }
    });
    var blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });
    if (window.navigator.msSaveOrOpenBlob) {
        navigator.msSaveOrOpenBlob(blob, 'download.csv');
    }
    else {
        var link = document.createElement("a");
        link.style.display = 'none';
        document.body.appendChild(link);
        if (link.download !== undefined) {
            link.setAttribute('href', URL.createObjectURL(blob));
            link.setAttribute('download', 'download.csv');
            link.click();
        }
        else {
            csv = 'data:text/csv;charset=utf-8,' + csv;
            window.open(encodeURI(csv));
        }
        document.body.removeChild(link);
    }
}

  //Redirect to VehicleDetail with current codeVehicule
  redirectToVeh(vehicleCode){
    this.router.navigate(['/vehicle-detail',vehicleCode])
    console.log(vehicleCode);
  }

  //Redirect to ProgramDetail with current id_gamme
  redirectToProg(id_gamme){
    console.log(id_gamme);
    this.routingService.setidGamme(id_gamme);
    this.router.navigate(['/program-list',id_gamme]);
  }


  //Redirect to ImpactDetail with current codeVehicule and codeChantier
  redirectToImpDetails(codeVehicule){
    window.localStorage.setItem('codeVehicule', codeVehicule);
    this.router.navigate(['/impact-details',codeVehicule]);
  }

  //Redirect to CampaignDetail with current numeroChantier
  redirectToCamp(numeroChantier){
    this.routingService.setImpactCamp(numeroChantier);
    this.router.navigate(['/campaign-management']);
    console.log(numeroChantier)
  }

  // This method will download the csv file
  downLoadFile(data: any) {

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();

    }
  }

  ngOnDestroy() {
    this.routingService.setImpactRules(null);
  }
}
