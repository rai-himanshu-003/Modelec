import { AuthConfig } from 'angular-oauth2-oidc';

// import of config for DEV

export const authCodeFlowConfig: AuthConfig = {

  // For LocalONLY

   issuer: 'https://idfed-preprod.mpsa.com:443',
   redirectUri: window.location.origin,
  //redirectUri : 'https://modelec.psa-cloud.com/index.html',
  clientId: 'RUSUYXQXMCWUZKPFDQKVKFJCWVDWPCDO',
  dummyClientSecret: 'Guuy2piGnPqzetHP1E6quFvNIHpFqcRvjsrgyaxnlenKoti1JRpAfCXtaOVGZ5MQ',
  scope: 'openid',
  logoutUrl: 'https://idfed-preprod.mpsa.com:443/idp/startSLO.ping',
  //tokenEndpoint: "https://idfed-preprod.mpsa.com:443/as/token.oauth2",

  // Common parameters for all env
  responseType: 'code',
  showDebugInformation: true,
  timeoutFactor: 0.90,

};


