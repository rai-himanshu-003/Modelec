import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import {MultiSelectModule} from 'primeng/multiselect';
import { CampaignInformationRoutingModule } from './campaign-information-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { MessageService } from 'primeng/api';
import {AccordionModule} from 'primeng/accordion';
// import { CampaignInformationComponent } from './campaign-information.component';
import {PanelModule} from 'primeng/panel';
import {DropdownModule} from 'primeng/dropdown';
import {FileUploadModule} from 'primeng/fileupload';
import {DialogModule} from 'primeng/dialog';

@NgModule({
  imports: [
    PanelModule,
    DialogModule,
    DropdownModule,
    FileUploadModule,
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    MultiSelectModule,
    CampaignInformationRoutingModule
  ],
  declarations: [],
  providers: [MessageService, DatePipe]
})
export class CampaignInformationModule {}
