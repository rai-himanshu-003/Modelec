export class FilePostDTO {
    file: string|File|any;
    campaignUploadDTO: string|any;

}
