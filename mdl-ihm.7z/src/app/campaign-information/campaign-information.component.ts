import { Component, OnInit, ViewChild } from '@angular/core';
import { CampaignInfoService } from '../service/campaign-Info-service';
import { ListDto } from '../models/list-model';
import { Table } from 'primeng/table';
import { FilePostDTO } from './filePostDTO';
import { campaignUploadDTO } from '../models/campaignUploadDTO';
import { FormControl } from '@angular/forms';
import { Message, MessageService } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { CampLocalprogramLabel } from '../models/campaign-list';
import{HeaderService} from '../service/header.service';

@Component({
  selector: 'app-campaign-information',
  templateUrl: './campaign-information.component.html',
  styleUrls: ['./campaign-information.component.scss'],
  providers: [MessageService]
})
export class CampaignInformationComponent implements OnInit {
  uploadedFiles: any[] = [];

  @ViewChild('vehDetailsForm', { static: false }) forms: FormControl;

  @ViewChild('dt', { static: false }) table: Table;

  // ormvalue:FormData;
  formvalue: FormData = new FormData();
  loading: boolean;
  numeroChantier: string;
  libCp: string;
  sortData = {} as campaignUploadDTO;
  postDAta = {} as FilePostDTO;

  dataLoad: any;

  form: any;
  filename: any = [];
  validateRecord: any;
  shortLink = '';

  load = false; //  Flag variable
  file: File = null; //  Variable to store file

  value: string | any;

  vehSearchRecords: any;
  formData: any;
  prodCenterList: any[] = [];
  fileName: any;
  display: boolean = false;
  displayBasic: boolean;
  msgs: Message[] = [];
  duplicateVINmsgs: Message[] = [];
  notAlphanumericmsgs: Message[] = [];
  vinCharactermsgs: Message[] = [];
  notExceedmsgs: Message[] = [];
  duplicateVIN: string;
  notAlphanumeric: any;
  vinCharacter: any;
  notExceed: any;
  prodCenterMsg:string="";
  pages="C4";
  labeltranslation= {} as  CampLocalprogramLabel;
  filePathMsg:string="";



  constructor(
    private campaignInfoService: CampaignInfoService,
    private translate: TranslateService,
    private headerService:HeaderService) {
     }
  async ngOnInit() {
   
   setTimeout(() => {
    this.getCreateprogramLabel();
    this.getRecordsFromDB();
    this.getProdRecordsFromDB();
    
   }, 500);
   
   
  
   
      
      this.headerService.notifyObservable.subscribe(async res=>
        {
          if(res.refresh)
          {
            this.translate.currentLang=res.lang;
            await this.getCreateprogramLabel();
            this.duplicateVIN=this.labeltranslation.errorsDuplicates;
            this.vinCharacter=this.labeltranslation.errorLength	;
            this.notExceed=this.labeltranslation.errorsFileExceed	;
            if(this.prodCenterMsg!=""){
            this.prodCenterMsg=this.labeltranslation.errorCodeCpRequired
            this.pushProdCentreMsg();}
            if(this.filePathMsg!=""){
              this.filePathMsg=this.labeltranslation.errorFilePathNotSelected;
              this.pushFilePathErrorMsg();
            }
          }
        })


  }

  async getCreateprogramLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.duplicateVIN=this.labeltranslation.errorsDuplicates;
     this.vinCharacter=this.labeltranslation.errorLength	;
     this.notExceed=this.labeltranslation.errorsFileExceed	;
     this.notAlphanumeric=this.labeltranslation.noAlphanumeric;
     console.log("vin caharacter",this.vinCharacter);
      console.log("duplicate vin",this.duplicateVIN);
      console.log("not exceed",this.notExceed); 
     console.log(this.labeltranslation)
    });
  }

  onChange(event: any): void {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
        this.value = file;
        console.log(this.value);
        this.postDAta.file = this.value;
    }
  }

  pushProdCentreMsg(){
    this.msgs.push({severity:'error', summary:'Error', detail:this.prodCenterMsg});
  }

  pushFilePathErrorMsg(){
    this.msgs.push({severity:'error', summary:'Error', detail:this.filePathMsg});
  }

  loadVin(numeroChantier, libDossier, codeChantier, libCp) {
    debugger
    // Create object to send details
    if(!libCp || !this.postDAta.file) {
      this.msgs = [];
      if(!libCp) {
       this.prodCenterMsg=this.labeltranslation.errorCodeCpRequired;
       this.pushProdCentreMsg();
      } 
      else{this.prodCenterMsg=""}

      if(!this.postDAta.file) {
        this.filePathMsg=this.labeltranslation.errorFilePathNotSelected;
        this.pushFilePathErrorMsg();
      }
      else{this.filePathMsg="";}
    } else {
      this.msgs=[];
      this.prodCenterMsg="";
      this.filePathMsg=""
      const dbDetails = {
        numeroChantier,
        codeChantier,
        libDossier,
        codeCP: libCp,
      };
      this.postDAta.campaignUploadDTO = JSON.stringify(dbDetails);
      if (dbDetails.codeCP == null && dbDetails.codeCP == undefined && dbDetails.codeCP == "") {
        this.display = true;
      }
      this.getloadVin(dbDetails);
      console.log(dbDetails);
    }
    
  }

  getloadVin(_dbDetails) {
    this.campaignInfoService.uploadRecord(this.postDAta).subscribe(
      (data: any) => {
        let val=data.message
        if(val == null || val == 'Success'){
          this.msgs.push({severity:'success', summary:'Success', detail:'Campaign created successfully'});
          setTimeout(() => {
          window.location.reload();
          }, 2000);
        }
        else if(val == 'VINs must only appear once in the file'){
            this.duplicateVINmsgs.push({severity:'error', summary:'Error', detail:this.duplicateVIN});
            }
        else if(val.includes('is not alphanumeric')){
          var ind1=val.substring(0, [17])
            this.notAlphanumeric = ind1 + " " + this.notAlphanumeric; 
            this.notAlphanumericmsgs.push({severity:'error', summary:'Error', detail:this.notAlphanumeric});
           
        }
        else if(val == 'VINs must be exactly 17 characters long'){ 
            this.vinCharactermsgs.push({severity:'error', summary:'Error', detail:this.vinCharacter});
          }
        else if(val == 'The file must not exceed 1000 rows'){
            this.notExceedmsgs.push({severity:'error', summary:'Error', detail:this.notExceed});
          }
      });
  }

  getRecordsFromDB() {
    this.campaignInfoService.getRecords().subscribe(
      (data: any) => {
        const res = data.datalist;
        console.log(res);
        this.formData = res;
      });
  }

  getProdRecordsFromDB() {
    this.campaignInfoService.getProdRecords().subscribe(
      (data: any) => {
        const res = data.datalist;
        console.log(res);

        this.prodCenterList = res.map(element => {
          const tempObj = {} as ListDto;
          tempObj.label = element.codeCp + " " + element.libCp;
          tempObj.value = element.codeCp;
          return tempObj;
        });
        console.log("prodCenterList ==", this.prodCenterList);
      });
  }
}
