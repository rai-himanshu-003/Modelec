export class DeleteAssociate {
    actionBrouillon: string|any;
    codeDossier: string|any;
    etat: string|any;
    idGamme: string|any;
    libDossier: string|any;
    libGamme: string|any;
    userBrouillon: string|any;
}
