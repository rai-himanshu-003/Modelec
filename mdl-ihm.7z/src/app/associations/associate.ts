export class AssociateDTO {
    idGamme: string|any;
    codeDossier: string|any;
}
