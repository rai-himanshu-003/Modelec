import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AssociationService } from '../service/association.service';
import { AssociateDTO } from './associate';
import { DeleteAssociate } from './deleteAssociate';
import { Router } from '@angular/router';
import { GetSelectedCPService } from '../service/getCP.service';
import { ListDto } from '../models/list-model';
import { RoutingService } from '../service/routing.service';
import { TranslateService } from '@ngx-translate/core';
import {HeaderService} from '../service/header.service';
import { G6labels } from '../models/campaign-list';
import { Actionlabels } from '../models/breadcrumbsDTO';

@Component({
  selector: 'app-associations',
  templateUrl: './associations.component.html',
  styleUrls: ['./associations.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AssociationsComponent implements OnInit {
  delCols: any[];
  campaignSearch: string;
  items: MenuItem[];
  campaignNumber: string;
  campaignStatus: string;
  delSearchRecords: any[];
  folderManag: any[] = [];
  libCp: string;
  campaignData: string;
  prodCenterList: string;
  associate = {} as AssociateDTO;
  deleteassociate = {} as DeleteAssociate[];
  codeChantier: string;
  programNumber: string;
  recordStr = '';
  singlestr = '';
  codeDossier: string;
  allCheck = false;
  arrElem = [];
  singleArr = [];
  onClickArr = [];
  singleSelectDel: string;
  associationModule: number = 1;
  campTranslate: string;
  val:string="";
  myStr: string;
  checkAllInThisCamp: boolean = false;
  pages="G6";
  labeltranslation= {} as  G6labels;
  actionpage="action";
  actiontranslation= {} as Actionlabels;



  constructor(private associationService: AssociationService,
    public router: Router,
    private getSelectedCPService: GetSelectedCPService,
    private routingService: RoutingService,
    private translate: TranslateService,
    private headerService:HeaderService) { }

  async ngOnInit() {
    await this.getAssociationLabel();
    await this.getActionLabel();
    this.routingService.setValue(true);
    this.getRecords();
    this.storeProgNo();

    this.delCols = [
      { field: 'element', header: 'Element' },
      { field: 'name', header: 'Name of the element' },
      { field: 'number', header: 'Program number' },
      { field: 'programName', header: 'Name of the program' },
      { field: 'state', header: 'State' },
      { field: 'action', header: 'Action' },
      { field: 'author', header: 'Author' },
    ];
    
    this.getPathName();
    

    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getAssociationLabel();
          await this.getActionLabel();
          this.getPathName();
          this.getRecords();
      
        }
      })
  }

async getAssociationLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }
getPathName()
{
  this.items = [
    { label: this.actiontranslation.rechercherChantiers, url: '../campaign-management' },
    { label: this.actiontranslation.detailChantier, url: '../campaign-number/' + this.campaignSearch },
    { label: this.actiontranslation.associationChantierGamme },
  ];
  this.campaignSearch = window.localStorage.getItem('campaignSearch');

    this.items.forEach(element => {
      if (element.label == 'Campaign') {
        element.label = element.label + ' ' + this.campaignSearch;
      }
    });
}

  //Selecting all checkbox value
  allClick(event) {

    if (event.target.checked == true) {
      this.delSearchRecords.forEach(element => {
        element.status = true;
      });
      const idGammeArr = [], codeDossierArr = [];
      for (let i = 0; i < this.deleteassociate.length; i++) {
        for (const key in this.deleteassociate[i]) {
          if (key === 'idGamme') {
            idGammeArr.push(this.deleteassociate[i][key]);
          }
          if (key === 'codeDossier') {
            codeDossierArr.push(this.deleteassociate[i][key]);
          }
        }
        if (codeDossierArr[i] == null || codeDossierArr[i] == "Campaign" || codeDossierArr[i] == "Chantier") {
          codeDossierArr[i] = "TRUE";
        }
        this.arrElem[i] = idGammeArr[i] + '/' + codeDossierArr[i] + ',';
        this.recordStr += this.arrElem[i].toString();
      }
      this.recordStr = this.recordStr.slice(0, -1);
    }
    else {
      this.delSearchRecords.forEach(element => {
        element.status = false;
      });
      this.recordStr = '';

    }
  }
  //Selecting single value
  onClick(_event, rowData) {
      if (_event) {
        rowData.status = !rowData.status;
      } else {
        rowData.status = undefined;
      }
      let index = this.onClickArr.findIndex(e => {
        return e[0] == rowData.idGamme;
      })
      if (index >= 0) {
       this.onClickArr.splice(index, 1);
      }
      if (_event.target.checked==true) {
        let idGamme = rowData.idGamme;
        let codeDossier = rowData.codeDossier;
        if (rowData.codeDossier == null || rowData.codeDossier == "Campaign" || rowData.codeDossier == "Chantier") {
          codeDossier = "TRUE";
             }
        let data =[idGamme,codeDossier];
        this.onClickArr.push(data);
      }
  }

  //Fetching recoreds from DB
  getRecords() {
    this.campaignData = window.localStorage.getItem('campaignSearch');
    this.associationService.checkAssociation(this.campaignData).subscribe(
      (data: any) => {
        const res = data.datalist.folderAreaDTO;
        for (let i = 0; i < data.datalist.associationChantierGammeDTO.length; i++) {
          for (const key in data.datalist.associationChantierGammeDTO[i]) {
            if (key === 'codeDossier' && data.datalist.associationChantierGammeDTO[i][key] === null) {            
                this.campTranslate = this.labeltranslation.codeDossier;
                data.datalist.associationChantierGammeDTO[i][key] = this.campTranslate;
            
            }
          }
        }
        this.campaignNumber = data.datalist.campaignNumber;
        this.campaignStatus = data.datalist.campaignStatus;
        this.codeChantier = data.datalist.campaignNumber;
        this.delSearchRecords = data.datalist.associationChantierGammeDTO;
        this.delSearchRecords.forEach(element => {
          element.checked = false;
        });
        this.deleteassociate = data.datalist.associationChantierGammeDTO;
        this.folderManag = res.map(element => {
          const tempObj = {} as ListDto;
          tempObj.label = element.codeDossier + "-" + element.libDossier;
          tempObj.value = element.codeDossier;
          return tempObj;
        });
        this.folderManag.unshift({ label: this.campTranslate, value: 'TRUE' });
          this.campTranslate = this.labeltranslation.codeDossier;
          this.folderManag[0].label = this.campTranslate;
      });
  }

  //Redirecting to program list screen
  goToProg(progNo) {
    this.routingService.setProgAssociate(progNo);
    this.router.navigate(['/program-list', progNo])
  }

  //Deleting the selected value
  deleteAssociate() {
    this.campaignData = window.localStorage.getItem('campaignSearch');
    if (this.recordStr == "" || this.recordStr == null || this.recordStr == undefined) {
      let myStr='';
      for (let i=0;i<this.onClickArr.length;i++){
          for(let j=0; j<this.onClickArr[i].length;j++){
            if(j %2 ==0){
            myStr+= this.onClickArr[i][j] + '/';
          }
          else {
            myStr+= this.onClickArr[i][j] + ',';
          }
        }  
      }
      this.singleSelectDel=myStr.substring(0, myStr.length - 1);
      this.recordStr = this.singleSelectDel;
    }
    this.associationService.deleteAssociation(this.campaignData, this.recordStr).subscribe(
      (data: any) => {
        if (data.datalist.msg == true) {
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }

      });
  }
  storeProgNo() {

    // Set the value of Vin number in variable
    this.programNumber = window.localStorage.getItem('progSearch');

    // If value is not null or undefined then call get data
    if (this.programNumber != null && this.programNumber != undefined) {
      window.localStorage.setItem('programNumber', this.programNumber);

    }

  }

  //Redirecting to programManagement page for progNo
  showBasicDialog() {

    this.getSelectedCPService.setSelectedAssociationNumber(this.codeChantier);

    const AssociationNo = window.localStorage.getItem('AssociationNo');

    if (AssociationNo != null && AssociationNo != undefined) {
      window.localStorage.removeItem('AssociationNo');
      window.localStorage.setItem('AssociationNo', this.codeChantier);

    } else {
      window.localStorage.setItem('AssociationNo', this.codeChantier);
    }
    this.routingService.setCreateBTN(true);
    this.router.navigate(['/program-management']);
  }

  //Button to Add the Link
  addLink(codeDossier, programNumber) {
    let code_Dossier = codeDossier;
    if (codeDossier === "" || codeDossier === undefined || codeDossier === null) {
      code_Dossier = "TRUE";
    }
    this.associationService.addAssociation(this.campaignData, programNumber, code_Dossier).subscribe(
      (data: any) => {
        if(data.datalist.msg==true){
        setTimeout(() => {
          window.location.reload();
          localStorage.removeItem('progSearch');
        }, 1000);
      }
      });
  }

  //Redirecting to Impact screen
  accessImpact() {
    this.router.navigate(['/impact', this.campaignData, 'VALIDATE_ALL_DRAFT_LINKS']);
  }

  //Validating Association Modification
  validate() {
    this.associationService.validate(this.campaignData).subscribe(
      (_data: any) => {
        setTimeout(() => {
          this.router.navigate(['/impact', this.campaignData, 'VALIDATE_ALL_DRAFT_LINKS']);
        }, 2000);
      });
  }

  //Validating Association Version
  version(_event) {
    this.associationService.returnversion(this.campaignSearch).subscribe(
      (data: any) => {
        if (data.datalist.msg == true) {
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }
      });
  }
}
