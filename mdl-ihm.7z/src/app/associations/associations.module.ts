import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';

import {MultiSelectModule} from 'primeng/multiselect';


import { TranslateModule } from '@ngx-translate/core';
import { MessageService } from 'primeng/api';
import {AccordionModule} from 'primeng/accordion';
import {PanelModule} from 'primeng/panel';
import {DropdownModule} from 'primeng/dropdown';
import {FileUploadModule} from 'primeng/fileupload';

import { AssociationsComponent } from './associations.component';
import { AssociationsRoutingModule } from './associations-routing.module';
import {BreadcrumbModule} from 'primeng/breadcrumb';





@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    BreadcrumbModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    MultiSelectModule,
    PanelModule,
    DropdownModule,
    FileUploadModule,
    AssociationsRoutingModule  ],
  declarations: [AssociationsComponent
    ],
  providers: [MessageService, DatePipe]
})
export class AssociationsModule {}
