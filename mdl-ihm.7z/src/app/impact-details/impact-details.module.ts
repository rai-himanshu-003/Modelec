import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import {PanelModule} from 'primeng/panel';
import {MultiSelectModule} from 'primeng/multiselect';

import { TranslateModule } from '@ngx-translate/core';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import { ImpactDetailsComponent } from './impact-details.component';
import { ImpactDetailsRoutingModule } from './impact-details-routing.module';

@NgModule({
  imports: [
    CommonModule,
    BreadcrumbModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    ImpactDetailsRoutingModule,
    PanelModule,
    MultiSelectModule
  ],
  declarations: [ImpactDetailsComponent],
  providers: [DatePipe]
})
export class ImpactDetailsModule {}
