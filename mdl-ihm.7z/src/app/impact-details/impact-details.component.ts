import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SortMeta, MenuItem } from 'primeng/api';
import { ImpactService } from '../service/impact.service';
import { ActivatedRoute } from '@angular/router';
import { RoutingService } from '../service/routing.service';
import { HeaderService } from '../service/header.service';
import { TranslateService } from '@ngx-translate/core';
import { G8Label } from '../models/campaign-list';
@Component({
  selector: 'app-impact-details',
  templateUrl: './impact-details.component.html',
  styleUrls: ['./impact-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ImpactDetailsComponent implements OnInit {

  loading: boolean;
  
   multiSortMeta: SortMeta;
   typeOfFiltersForFilter: any[] = [];
   
  originCollapsed:boolean=false;
  issueCollapsed:boolean=false;
  issuesCol:any[];
  issuesRecords:any[];
  conflictsCol:any[];
  conflictsRecords:any[];
  impactCols:any[];
  csvSeparator: string = ";"
  impactRecords:any[];
  impactRecordsAfter:any[];
  impactRecordsBefore:any[];
  campaignSearch: string;
  items : MenuItem[];
  codeVeh: string;
  formData: any = {};
  impactAfterCols: any[];
  siteNumber:string;
  codeVehicle:string;
  vehicleStatus:string;
  lcdv24:string;
  impactDetailsData: any;
  campaignData: string;
  routerInput: string;
  programNumber: string;
  draftRuleset: any;
  gammeType: any;
  pages:string="G8";
  labeltranslation= {} as G8Label
  constructor(
    public impactService : ImpactService,
    public route : ActivatedRoute,
    public routerService : RoutingService,
    private headerService:HeaderService,
    private translate: TranslateService
  ) { }

  async ngOnInit() {

    await this.getImpactLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getImpactLabel();
          
        }
      })
      
    this.codeVeh = this.route.snapshot.paramMap.get('codeVeh');
    this.routerInput = window.localStorage.getItem('route');
    this.campaignData = window.localStorage.getItem('campaignSearch');
    this.programNumber = window.localStorage.getItem('progSearch');

    this.routerService.getImpactDetailsRules().subscribe(data=> {
      this.draftRuleset = data.draftRuleset;
      this.gammeType = data.gammeType;
    })
    this.draftRuleset=window.localStorage.getItem("draftRuleset");
    this.gammeType=window.localStorage.getItem("gammeType");
    
    if(this.routerInput == "VALIDATE_ALL_DRAFT_LINKS"){
    this.items = [
      {label:'Impact Screen',url: '../impact/'  + this.campaignData +"/"+ this.routerInput},
      {label:'Impact details'},
    ];
  }
  else if(this.routerInput == "VEHICULE_UPDATE"){
    this.items = [
      {label:'Impact Screen',url: '../impact/'  + this.codeVeh +"/"+ this.routerInput},
      {label:'Impact details'},
    ];
  }
  else if(this.routerInput == "VALIDATE_DRAFT_GAMME"){
    this.items = [
      {label:'Impact Screen',url: '../impact/'  + this.programNumber +"/"+ this.routerInput},
      {label:'Impact details'},
    ];
  }
    this.getImpactDetailsRecords();
  }
setColumnHeader(){
  this.impactCols = [
    { field: 'idGamme', header:this.labeltranslation.colonneNumeroDeGamme },
    { field: 'codeMnemonique', header:this.labeltranslation.colonneMnemonique },
    { field: 'libMnemonique', header:this.labeltranslation.colonneLibelleMnemonique },
    { field: 'valeur', header: this.labeltranslation.colonneValeur },
    { field: 'codeProduit', header:this.labeltranslation.product},
    { field: 'indice', header: 'Indice' }
  ];
}
  //Fetching the record for the particular Vin
  getImpactDetailsRecords(){
    let input = window.localStorage.getItem('route');
    if(input == 'VEHICULE_UPDATE')
    {
      this.campaignData = window.localStorage.getItem('codeVehicule');
    }else if(input == 'VALIDATE_DRAFT_GAMME'){
      this.campaignData = window.localStorage.getItem('progSearch');
    }
    this.impactService.getImpact(this.campaignData, input, this.draftRuleset, this.gammeType).subscribe((data:any)=>{
      this.formData=data.datalist;
      let vehiclesData = data.datalist.vehicles;
      this.impactRecords = data.datalist.impacte;
      for(let i=0; i<this.impactRecords.length;i++){
        for(let key in this.impactRecords[i]){
          if(key == "suivi" && this.impactRecords[i][key].id.codeVehicule == this.codeVeh){
            this.impactDetailsData = this.impactRecords[i];
            
          }
        }
      }
      for(let j=0; j<vehiclesData.length; j++){
        for(let key in vehiclesData[j]){
          if(key == "codeVehicule" && vehiclesData[j][key] == this.codeVeh){
              this.lcdv24 = vehiclesData[j].lcdv24;
          }
        }
      }
      this.impactRecordsAfter = this.impactDetailsData.cookedAfter;
      this.impactRecordsBefore = this.impactDetailsData.cookedBefore;
      this.siteNumber = this.impactDetailsData.chantier.sitenumber;
      this.codeVehicle = this.impactDetailsData.suivi.id.codeVehicule
      this.vehicleStatus = this.impactDetailsData.suivi.etatSuivi;
    });
  }

    //For exporting CSV
    exportCSVBefore(filteredValue) {
      var _this = this;
      var data = filteredValue || this.impactRecordsBefore || [];
      var csv = 'sep=;\r\n';
      //headers
      for (var i = 0; i < this.impactCols.length; i++) {
          var column = this.impactCols[i];
          if (column.exportable !== false && column.field) {
              csv += '"' + (column.header || column.field) + '"';
              if (i < (this.impactCols.length - 1)) {
                  csv += this.csvSeparator;
              }
          }
      }
      //body
      data.forEach(function (record) {
          csv += '\n';
          for (var i_1 = 0; i_1 < _this.impactCols.length; i_1++) {
              var column = _this.impactCols[i_1];
              if (column.exportable !== false && column.field) {
                   var cellData = record[column.field];
                   if (cellData != null) {
                      cellData = String(cellData).replace(/"/g, '""');
                   }
                   else {
                      cellData = '';
                   }
                   csv += '"' + cellData + '"';
                  if (i_1 < (_this.impactCols.length - 1)) {
                      csv += _this.csvSeparator;
                  }
              }
          }
      });
      var blob = new Blob([csv], {
          type: 'text/csv;charset=utf-8;'
      });
      if (window.navigator.msSaveOrOpenBlob) {
          navigator.msSaveOrOpenBlob(blob, 'download.csv');
      }
      else {
          var link = document.createElement("a");
          link.style.display = 'none';
          document.body.appendChild(link);
          if (link.download !== undefined) {
              link.setAttribute('href', URL.createObjectURL(blob));
              link.setAttribute('download', 'download.csv');
              link.click();
          }
          else {
              csv = 'data:text/csv;charset=utf-8,' + csv;
              window.open(encodeURI(csv));
          }
          document.body.removeChild(link);
      }
  }

  exportCSVAfter(filteredValue) {
    var _this = this;
    var data = filteredValue || this.impactRecordsAfter || [];
    var csv = 'sep=;\r\n';
    //headers
    for (var i = 0; i < this.impactCols.length; i++) {
        var column = this.impactCols[i];
        if (column.exportable !== false && column.field) {
            csv += '"' + (column.header || column.field) + '"';
            if (i < (this.impactCols.length - 1)) {
                csv += this.csvSeparator;
            }
        }
    }
    //body
    data.forEach(function (record) {
        csv += '\n';
        for (var i_1 = 0; i_1 < _this.impactCols.length; i_1++) {
            var column = _this.impactCols[i_1];
            if (column.exportable !== false && column.field) {
                 var cellData = record[column.field];
                 if (cellData != null) {
                    cellData = String(cellData).replace(/"/g, '""');
                 }
                 else {
                    cellData = '';
                 }
                 csv += '"' + cellData + '"';
                if (i_1 < (_this.impactCols.length - 1)) {
                    csv += _this.csvSeparator;
                }
            }
        }
    });
    var blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });
    if (window.navigator.msSaveOrOpenBlob) {
        navigator.msSaveOrOpenBlob(blob, 'download.csv');
    }
    else {
        var link = document.createElement("a");
        link.style.display = 'none';
        document.body.appendChild(link);
        if (link.download !== undefined) {
            link.setAttribute('href', URL.createObjectURL(blob));
            link.setAttribute('download', 'download.csv');
            link.click();
        }
        else {
            csv = 'data:text/csv;charset=utf-8,' + csv;
            window.open(encodeURI(csv));
        }
        document.body.removeChild(link);
    }
}
async getImpactLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   this.setColumnHeader();
   console.log(this.labeltranslation)
  });  
}
}
