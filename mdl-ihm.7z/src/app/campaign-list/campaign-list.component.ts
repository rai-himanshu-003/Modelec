import { Component, OnInit, Input, EventEmitter, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataService } from '../service/data.service';
import { GetSelectedCPService } from '../service/getCP.service';
import { CampaignStatusService } from '../service/campaign-status.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { LazyLoadEvent, SortMeta } from 'primeng/api';
import { CampaignListDTO, CampaignListLabel } from '../models/campaign-list';
import { CampaignComponent } from '../campaign-management/campaign.component';
import { Dropdown } from 'primeng/dropdown';
import { Table } from 'primeng/table';
import { TranslateService } from '@ngx-translate/core';
import {HeaderService} from '../service/header.service'
import { SideBarLabel } from '../models/sidebar-list';
@Component({
  selector: 'app-campaign-list',
  templateUrl: './campaign-list.component.html',
  styleUrls: ['./campaign-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CampaignListComponent implements OnInit {
  @ViewChild('dt', { static: false }) table: Table;
  @ViewChild("myDropDown", {static: false}) myDropDown: Dropdown
  
  isDataAvailable = false;
  isAvailable = true;
  collapse = false;
  toDate: Date;
  fromDate: Date;
  selectedVal: any;
  dbSort: string;
  // variable for columns
  cols=[]
  colsForFilter: any[];

  // pagination variables
  first = 0;
  page: number;
  rows = 10;
  size: number;
  totalNumberRecords: number;
  data: any;

  // lazy loading variable
  loading: boolean;

  // Date filter variables
  extshowDateContainer = false;
  extfdate: Date;
  exttdate: Date;

  selectedDate: string;
  datepipe: DatePipe;
  // Sort Variables
  sortData = {} as CampaignListDTO; // need to be checked
  sortResult: string|any;
  multiSortMeta: SortMeta;

  // State filter
  listOfFlowForFilter: any[] = [];
  currentStatesForFilter: any[] = [];

  campaignValue: string;
 l1:string;
  collapsedVal: boolean = false;
//label translation 
pages="C1";
labeltranslation: CampaignListLabel={} as CampaignListLabel;
sidepage="D2";
tabletranslation= {} as SideBarLabel;
campListlabel : CampaignListLabel[]=[];
  // Back button variable
  isBack: string;
  typeOfFiltersForFilter: any[] = [];
  retrivedata: Array<object> = [];

  index: number = null;
  lastIndex = -1;

  // Filter variable 
  filterCampaignNo:string;
  filterCampaignNature:any;

dbDetails1 = {} as CampaignListDTO;
  campListRecords:CampaignListDTO[] = [];
  statusDropDown: any[]=[];
  campaignNatureDropDown: any[]=[];
  qwe: any[];
  selectedStates: any[];
  campaignNature: any;
  campaignStatusOptionOne: any[];
  campaignStatusOptionTwo: any[];
  filterReset: boolean;

  //testing export
  response = {} as CampaignListDTO;

  //Variables to clear filter
  // filterCampaignNo:any;
  filterCp:any;
  filterUserCreation:any;
  // filterCampaignNature:any;
  filterStatus:any;
  filterToRefresh:any;
  filterResume:any;
  filterCreatedDate:any;
  filterTotalNoOfVehicles:any;
  filterNoOfVehiclesToBeMade:any;
  camlistheaders:[] = [];
    
  
  


  @Input( ) set dbDetails(data) {
    if(data){
      console.log(data,"data present");
      this.dbDetails1=data;
      this.sortResult=data;
      console.log(this.sortResult,"data present");
      this.campListRecords=data.responseList;
      this.totalNumberRecords = data.totalRecords;
      
    }
  }
  @Input( ) set campListData(data) {
    if(data){
      this.campListRecords=null;
      console.log(data.responseList,"data present");
     // this.sortResult=null;
      
      this.campListRecords=data.responseList;
      this.response = data.responseList;
      this.totalNumberRecords = data.totalRecords;

      this.filterCampaignNo=null;
      this.filterCp=null;
      this.filterUserCreation=null;
      this.filterCampaignNature=null;
      this.filterStatus=null;
      this.filterToRefresh=null;
      this.filterResume=null;
      this.filterCreatedDate=null;
      this.filterTotalNoOfVehicles=null;
      this.filterNoOfVehiclesToBeMade=null;

      //reset filter value to get records
  
       Object.assign(this.sortData, {
       cp: null,
       campaignNo: null,
       userCreation: null,
       campaignNature: null,
       status: null,
       toRefresh: null,
       resume: null,
       createdDate: null,
       totalNoOfVehicles: null,
       noOfVehiclesToBeMade: null,
     });
    this.resetSort();
    }
  }
  @Input( ) set natureDropDown(data) {
    if(data){
      console.log(data,"data present");
      this.campaignNatureDropDown=data;
      
    }
  }
  @Output() campaignUpdate=new EventEmitter();

  constructor(
    private dataService: DataService,
    private getSelectedCPService: GetSelectedCPService,
    public router: Router,
    private campaignStatusService: CampaignStatusService,
    private datePipe: DatePipe,
    private campaign_mgm:CampaignComponent,
    private translate: TranslateService,
    private headerService: HeaderService
  ) {
    this.campaignNatureDropDown = [
      { label: 'L   ', value: 'L' },
      { label: 'C   ', value: 'C' }
    ];
          
   }

  async ngOnInit() {

    console.log("In Campaign list page");
    await this.getCampaignLabel(); 
    await this.getTableLabel();
    this.getTypeFilter();
    this.getTableHeader();
    this.getState();
     
      this.headerService.notifyObservable.subscribe(async res=>
        {
          if(res.refresh)
          {
            this.translate.currentLang=res.lang;
            await this.getCampaignLabel();
            await this.getTableLabel();
            this.getTableHeader();
            this.getState();
            this.getTypeFilter();
          }
        })
    }
async getCampaignLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;  
     });  
}
async getTableLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.sidepage).toPromise().then(
    (data: any) => {
     this.tabletranslation = data.datalist.record;  
     });  
}

getTypeFilter()
{
  this.typeOfFiltersForFilter = [];
  this.typeOfFiltersForFilter.push({label :this.labeltranslation.yes, value: "yes"});
  this.typeOfFiltersForFilter.push({label :this.labeltranslation.no, value: "no"});


}
getState()
{
  this.statusDropDown=[];
      this.statusDropDown.push({ label: this.labeltranslation.alim, value: 'ALIM' });
      this.statusDropDown.push({ label: this.labeltranslation.initialise, value: 'INITIALISE' });
      this.statusDropDown.push({ label: this.labeltranslation.valide, value: 'VALIDE' });
      this.statusDropDown.push({ label: this.labeltranslation.invalide, value: 'INVALIDE' });
      this.statusDropDown.push({ label: this.labeltranslation.engage, value: 'ENGAGE' });
      this.statusDropDown.push({ label: this.labeltranslation.clos, value: 'CLOS' });

}

getTableHeader()
{
  this.cols = [
    { field: 'campaignNo', header: this.labeltranslation.codeChantier },
    { field: 'cp', header: this.labeltranslation.centreProd },
    { field: 'userCreation', header: this.labeltranslation.userCreation },
    { field: 'campaignNature', header: this.labeltranslation.natureChantier },
    { field: 'status', header: this.labeltranslation.etatChantier },
    { field: 'toRefresh', header: this.labeltranslation.rafraichir },
    { field: 'resume', header: this.labeltranslation.reprendre },
    { field: 'createdDate', header: this.labeltranslation.dateCreation },
    { field: 'totalNoOfVehicles', header: this.labeltranslation.nbVehiculesTotal },
    { field: 'noOfVehiclesToBeMade', header: this.labeltranslation.nbVehiculesAFaire },
  ];
  
}
    resetSort() {
      this.table.sortOrder = 0;
      this.table.sortField = '';
      this.table.reset();
     }

   getSortRecord() {
    const totalRecords = true;
    console.log(this.sortResult);
    this.dataService.getRecords(this.first, this.rows, totalRecords, JSON.stringify(this.sortResult)).subscribe(
      (data: any) => {
        const res = data.datalist.responseList;
        console.log(JSON.stringify(res));
        this.campListRecords = res;
        this.totalNumberRecords = data.datalist.totalRecords;
      });
  }
  // This method will work for pagination
  paginate(event: any) {
    this.first = event.first;

    this.page = event.page;

    this.rows = event.rows;

    this.getSortRecord();
  }


  // paginate(event: any) {
  //   this.campaign_mgm.paginate(event);
  // }
   // This method will give lazy loading and sorting method
   loadVehSearchLazy(event: LazyLoadEvent) {
    this.loading = false;

    // this method will sort the data
    if (event.multiSortMeta) {
      if (this.dbDetails1 != null) {
        this.sortData.cp = this.dbDetails1.cp;
        this.sortData.campaignNo = this.dbDetails1.campaignNo;
        this.sortData.userCreation = this.dbDetails1.userCreation;
        this.sortData.campaignNature = this.dbDetails1.campaignNature;
        this.sortData.status = this.dbDetails1.status;
        this.sortData.toRefresh = this.dbDetails1.toRefresh;
        this.sortData.resume = this.dbDetails1.resume;
        this.sortData.white = this.dbDetails1.white;
        this.sortData.linkToProgram = this.dbDetails1.linkToProgram;
        this.sortData.fromDate = this.dbDetails1.fromDate;
        this.sortData.toDate = this.dbDetails1.toDate;
        this.sortData.vin = this.dbDetails1.vin;
      }
      // set the default valu as null for sorting & filtering
      Object.assign(this.sortData, {
        cpOrder: null,
        campaignNoOrder: null,
        campaignNatureOrder: null,
        statusOrder: null,
        fromDateOrder: null,
        totalNoOfVehiclesOrder: null,
        noOfVehiclesToBeMadeOrder: null,
        userCreationOrder: null,
        toRefreshOrder:null,
        resumeOrder:null

      });

      if (event.multiSortMeta[0].field == 'cp' && event.multiSortMeta[0].order == 1) {
        this.sortData.cp = this.dbDetails1.cp;
        this.sortData.cpOrder = 'asc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'cp' && event.multiSortMeta[0].order == -1) {
        //  this.sortData.cp=this.dbDetails1.cp
        this.sortData.cpOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'campaignNo' && event.multiSortMeta[0].order == 1) {
        //  this.sortData.campaignNo=this.dbDetails1.campaignNo;
        this.sortData.campaignNoOrder = 'asc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'campaignNo' && event.multiSortMeta[0].order == -1) {
        //  this.sortData.campaignNo=this.dbDetails1.campaignNo;
        this.sortData.campaignNoOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == 1) {
        // this.sortData.userCreation=this.dbDetails1.userCreation;
        this.sortData.userCreationOrder = 'asc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == -1) {
        // this.sortData.userCreation=this.dbDetails1.userCreation;
        this.sortData.userCreationOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'campaignNature' && event.multiSortMeta[0].order == 1) {
        //  this.sortData.campaignNature=this.dbDetails1.campaignNature;
        console.log(this.sortData.campaignNature);
        this.sortData.campaignNatureOrder = 'asc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'campaignNature' && event.multiSortMeta[0].order == -1) {
        //  this.sortData.campaignNature=this.dbDetails1.campaignNature;
        console.log(this.sortData.campaignNature);
        this.sortData.campaignNatureOrder = 'desc';
        this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'status' && event.multiSortMeta[0].order == 1) {
        // this.sortData.status=this.dbDetails1.status;
        this.sortData.statusOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'status' && event.multiSortMeta[0].order == -1) {
        //  this.sortData.status=this.dbDetails1.status;
        this.sortData.statusOrder = 'desc';
        this.sortResult = this.sortData;

      }else if (event.multiSortMeta[0].field == 'toRefresh' && event.multiSortMeta[0].order == 1) {
          // this.sortData.status=this.dbDetails1.status;
          this.sortData.toRefreshOrder = 'asc';
          this.sortResult = this.sortData;
        } else if (event.multiSortMeta[0].field == 'toRefresh' && event.multiSortMeta[0].order == -1) {
          //  this.sortData.status=this.dbDetails1.status;
          this.sortData.toRefreshOrder = 'desc';
          this.sortResult = this.sortData;

        }else if (event.multiSortMeta[0].field == 'resume' && event.multiSortMeta[0].order == 1) {
          // this.sortData.status=this.dbDetails1.status;
          this.sortData.resumeOrder = 'asc';
          this.sortResult = this.sortData;
        } else if (event.multiSortMeta[0].field == 'resume' && event.multiSortMeta[0].order == -1) {
          //  this.sortData.status=this.dbDetails1.status;
          this.sortData.resumeOrder = 'desc';
          this.sortResult = this.sortData;

      } else if (event.multiSortMeta[0].field == 'createdDate' && event.multiSortMeta[0].order == 1) {

        this.sortData.fromDateOrder = 'asc';
        this.sortResult = this.sortData;
        console.log(this.sortResult);
      } else if (event.multiSortMeta[0].field == 'createdDate' && event.multiSortMeta[0].order == -1) {
        this.sortData.fromDateOrder = 'desc';
        this.sortResult = this.sortData;
        console.log(this.sortResult);
      } else if (event.multiSortMeta[0].field == 'totalNoOfVehicles' && event.multiSortMeta[0].order == 1) {
        this.sortData.totalNoOfVehiclesOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'totalNoOfVehicles' && event.multiSortMeta[0].order == -1) {
        this.sortData.totalNoOfVehiclesOrder = 'desc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfVehiclesToBeMade' && event.multiSortMeta[0].order == 1) {
        this.sortData.noOfVehiclesToBeMadeOrder = 'asc';
        this.sortResult = this.sortData;
      } else if (event.multiSortMeta[0].field == 'noOfVehiclesToBeMade' && event.multiSortMeta[0].order == -1) {
        this.sortData.noOfVehiclesToBeMadeOrder = 'desc';
        this.sortResult = this.sortData;
      }
      console.log(this.sortData);
      this.getSortRecord();
      //this.campaign_mgm.getRecordsFromDB(this.sortData);
    }
  }

  filterDate(event) {
    console.log('hiii');
    event = null;
    this.sortData.createdDate = event;
    this.sortResult = this.sortData;
    this.campaign_mgm.getRecordsFromDB(this.sortResult);
  }

  // This method will filter data on key down event
  onKeydown(event, field: string) {

    if(this.sortResult != null){
      this.sortData=this.sortResult;
    }

    console.log(this.sortResult,"this.sortResult1");
    console.log('satyam' + JSON.stringify(event));
    if (field == 'cp') {
      if(event.target.value===""){
        this.sortData.cp = null;
      }
      else{
      this.sortData.cp = event.target.value;
      }
      this.sortResult = this.sortData;
    } else if (field == 'campaignNo') {
      if(event.target.value===""){
        this.sortData.campaignNo = null;
      }
      else{
      this.sortData.campaignNo = event.target.value;
      }
      this.sortResult = this.sortData;
    } else if (field == 'userCreation') {
      if (event.target.value == '' || event.target.value == undefined || event.target.value == null) {
        this.sortData.userCreation = null;
      } else {
        this.sortData.userCreation = event.target.value;
      }
      this.sortResult = this.sortData;
    } else if (field == 'campaignNature') {
      if (event == '' || event== undefined || event == null) {
        this.sortData.campaignNature = null;
      } else {
        this.sortData.campaignNature = event;
      }
      this.sortResult = this.sortData;
    } else if (field == 'status') {
      if(event===""){
        this.sortData.status = null;
      }
      else{
      this.sortData.status = event;
      }
      this.sortResult = this.sortData;
    } else if (field == 'toRefresh') {
      console.log(event);
      if (event == 'yes') {
        this.sortData.toRefresh = true;
      } else if (event == 'no') {
        this.sortData.toRefresh = false;
      } else {
        this.sortData.toRefresh = event;
      }
      this.sortResult = this.sortData;
    } else if (field == 'resume') {
      if (event == 'yes') {
        this.sortData.resume = true;
      } else if (event == 'no') {
        this.sortData.resume = false;
      } else {
        this.sortData.resume = event;
      }
      this.sortResult = this.sortData;
    } else if (field == 'createdDate') {
      const dateVal = this.datePipe.transform(event, 'yyyy-MM-dd');
      const newDate = dateVal + 'T00:00:00.000Z';
      this.sortData.createdDate = newDate;
      this.sortResult = this.sortData;
    } else if (field == 'totalNoOfVehicles') {
      if(event.target.value===""){
        this.sortData.totalNoOfVehicles = null;
      }
      else{
      this.sortData.totalNoOfVehicles = event.target.value;
      }
      this.sortResult = this.sortData;
    } else if (field == 'noOfVehiclesToBeMade') {
      if(event.target.value===""){
        this.sortData.noOfVehiclesToBeMade = null;
      }
      else{
      this.sortData.noOfVehiclesToBeMade = event.target.value;
      }
      this.sortResult = this.sortData;
    }
    this.first = 0;
    //this.campaign_mgm.getRecordsFromDB(this.sortResult);
    console.log(this.sortResult,"this.sortResult");
    
    this.getSortRecord();

  }

  // this method will redirect page to Vehicle details page

  goToPage(campaignData) {
    console.log(campaignData);
    this.campaignValue = campaignData.campaignNature + campaignData.campaignNo;
    console.log(this.campaignValue);
    // this.getSelectedCPService.setSelectedCPNature(this.campaignNature);
    this.getSelectedCPService.setSelectedCPNumber(this.campaignValue);

    const campaignSearch = window.localStorage.getItem('campaignSearch');
    // let campaignNatureSearch=window.localStorage.getItem("campaignNatureSearch");
    if (campaignSearch != null && campaignSearch != undefined) {
      window.localStorage.removeItem('campaignSearch');
      window.localStorage.setItem('campaignSearch', this.campaignValue);

      // window.localStorage.removeItem("campaignNatureSearch");
      // window.localStorage.setItem("campaignNatureSearch",this.campaignNature);


    } else {
      window.localStorage.setItem('campaignSearch', this.campaignValue);
    }


    if (this.campaignValue) {
      this.router.navigate(['/campaign-number', this.campaignValue]);
      console.log(this.campaignValue);
    }

    // Store records for filter
    this.storeFilteredData();

  }

  storeFilteredData() {

    console.log(this.sortResult);

    window.localStorage.setItem('filteredData', this.sortResult);
    window.localStorage.setItem('first', this.first.toString());
    window.localStorage.setItem('rows', this.rows.toString());

    const filteredData = window.localStorage.getItem('filteredData');
    const first: string | number = window.localStorage.getItem('first');
    const rows: string | number = window.localStorage.getItem('rows');

    // if(filteredData != null || filteredData != undefined){
    //   window.localStorage.setItem("filteredData",this.sortResult);
    // }

    console.log(filteredData);
    console.log(first);
    console.log(rows);
  }
  // This method will Fetch the data  for export to csv
  exportToCSV() {
    console.log('Export', this.dbDetails);
    let result:string;
    const totalRecords = true;
    console.log( this.campListRecords);
    
    result = JSON.stringify(this.sortResult);
    this.campaignStatusService.exportToCSVRecords(this.rows, this.first, totalRecords, result).subscribe(
      response => this.downLoadFile(response),
      (error: any) => console.log(error)
    );
  }

  // This method will download the csv file
  downLoadFile(data: any) {

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();

    }
  }

}
