import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { CheckboxModule } from 'primeng/checkbox';

import { MultiSelectModule } from 'primeng/multiselect';
import { VehicleDetailRoutingModule } from './vehicle-detail-routing.module';

import { TranslateModule } from '@ngx-translate/core';
import { MessageService } from 'primeng/api';
import { AccordionModule } from 'primeng/accordion';
import { PanelModule } from 'primeng/panel';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule } from 'primeng/fileupload';
import { DialogModule } from 'primeng/dialog';
import { VehicleDetailComponent } from './vehicle-detail.component';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { SortableTableComponent } from './sortable-table';
import {ListboxModule} from 'primeng/listbox';

@NgModule({
  imports: [
    BreadcrumbModule,
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    AccordionModule,
    MultiSelectModule,
    PanelModule,
    DropdownModule,
    FileUploadModule,
    VehicleDetailRoutingModule,
    DialogModule,
    ListboxModule
  ],
  declarations: [VehicleDetailComponent,
    SortableTableComponent],
  providers: [MessageService, DatePipe]
})
export class VehicleDetailModule { }
