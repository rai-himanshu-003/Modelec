import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'app-sortable-table',
    template: `<p-table #dt [columns]="columnList" [value]="dataList" [scrollable]="true" scrollHeight="360px" csvSeparator=";">
    <ng-template pTemplate="header" let-columns>
        <tr>
            <th *ngFor="let col of columns" [pSortableColumn]="col.field">
                {{col.header | translate}}
                <p-sortIcon [field]="col.field"></p-sortIcon>
            </th>
        </tr>
        <tr>
            <th *ngFor="let col of columns">
                <input class="ui-g-12" type="text" (input)="dt.filter($event.target.value, col.field, 'contains')">
            </th>
        </tr>
    </ng-template>
    <ng-template pTemplate="body" let-rowData let-columns="columns">
        <tr>  
            <td *ngFor="let col of columns" style="overflow-wrap: break-word;">
                {{rowData[col.field]}}
                <i *ngIf="col.field == 'Historic'" class="pi pi-eye pointer" (click)="showUpdatedAttribute(rowData)"></i>
            </td>
        </tr>
    </ng-template>
    <ng-template pTemplate="footer">
        <div class="ui-helper-clearfix ui-g-2" style="text-align: left" *ngIf="!hideExport">
            <button type="button" pButton icon="pi pi-file-o" iconPos="left" label="{{'Export To CSV' | translate}}" (click)="exportCSV(dt.filteredValue)" style="margin-right: 0.5em;"></button>
        </div>
    </ng-template>   
</p-table>`
  })
  export class SortableTableComponent implements OnInit {
    @Input() columnList: any[];
    @Input() dataList: any[];
    @Input() hideExport: boolean;
    @Output() callUpdatedAttribute = new EventEmitter<any>();
    csvSeparator: string = ";"

    constructor() { }
    
    ngOnInit(): void { }

    showUpdatedAttribute(rowData) {
        this.callUpdatedAttribute.emit(rowData);
    }

    exportCSV(filteredValue) {
        var _this = this;
        var data = filteredValue || this.dataList || [];
        var csv = 'sep=;\r\n';
        //headers
        for (var i = 0; i < this.columnList.length; i++) {
            var column = this.columnList[i];
            if (column.exportable !== false && column.field) {
                csv += '"' + (column.header || column.field) + '"';
                if (i < (this.columnList.length - 1)) {
                    csv += this.csvSeparator;
                }
            }
        }
        //body
        data.forEach(function (record) {
            csv += '\n';
            for (var i_1 = 0; i_1 < _this.columnList.length; i_1++) {
                var column = _this.columnList[i_1];
                if (column.exportable !== false && column.field) {
                     var cellData = record[column.field];
                     if (cellData != null) {
                        cellData = String(cellData).replace(/"/g, '""');
                     }
                     else {
                        cellData = '';
                     }
                     csv += '"' + cellData + '"';
                    if (i_1 < (_this.columnList.length - 1)) {
                        csv += _this.csvSeparator;
                    }
                }
            }
        });
        var blob = new Blob([csv], {
            type: 'text/csv;charset=utf-8;'
        });
        if (window.navigator.msSaveOrOpenBlob) {
            navigator.msSaveOrOpenBlob(blob, 'download.csv');
        }
        else {
            var link = document.createElement("a");
            link.style.display = 'none';
            document.body.appendChild(link);
            if (link.download !== undefined) {
                link.setAttribute('href', URL.createObjectURL(blob));
                link.setAttribute('download', 'download.csv');
                link.click();
            }
            else {
                csv = 'data:text/csv;charset=utf-8,' + csv;
                window.open(encodeURI(csv));
            }
            document.body.removeChild(link);
        }
    }
  }