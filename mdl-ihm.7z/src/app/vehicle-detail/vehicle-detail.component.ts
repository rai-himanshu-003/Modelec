import { Component, OnInit } from '@angular/core';
import { VehicleListService } from '../vehicle-list/vehicle-list.service';
import { IVehicleDetail } from '../models/vehicle-detail';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MenuItem, Message } from 'primeng/api';
import { DatePipe } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { RoutingService } from '../service/routing.service';
import { IAttributeVals } from '../models/attributeVals';
import { IAttributeRefVals } from '../models/attributeRefVals';
import { IManualInventory } from '../models/manualInventory';
import { IMnemonicVals } from '../models/mnemonicsVals';
import { V1labels } from '../models/vehicle-list';
import { HeaderService } from '../service/header.service';
import { Actionlabels } from '../models/breadcrumbsDTO';

@Component({
  selector: 'app-vehicle-detail',
  templateUrl: './vehicle-detail.component.html',
  styleUrls: ['./vehicle-detail.component.css'],
  providers: [ConfirmationService]
})
export class VehicleDetailComponent implements OnInit {
  campaignDetails: any = {};
  vehicleDetails: IVehicleDetail = {} as IVehicleDetail;
  programActionRecords = [];
  vehicleAttributes: any;
  vehicleElectronique: any;
  items: MenuItem[];
  displayBasic = false;
  displayDialog = false;
  message: string;
  dialogData: string[];
  vehicleHistory: boolean;
  fields: string[];
  msgs: Message[] = [];
  dossierListCols: { field: string; header: string; }[];
  vehicleElectroniqueCols: { field: string; header: string; }[];
  programActionRecordsCols: { field: string; header: string; }[];
  concat: string;
  collapsedFolder = true;
  collapsedAttribute = true;
  collapsedElectonique = true;
  collapsedProgram = true;
  displayAddAttribute = false;
  showUpdateAttribute = false;
  updateAttributeCols: { field: string; header: string; }[];
  updatedAttributes: any;
  refValue: string;
  refList: IAttributeRefVals[];
  selectedAttribute: IAttributeVals;
  selectedAttrRef: IAttributeRefVals;
  familyLabel: string;
  attributeData: IAttributeVals[];
  attributeLabel: string;
  selectedManualInventory: {mnemonicCode: string; mnemonicLabel: string; mnemonicValue:string; corvetValue:number; newValue:boolean}[] = [];
  generateIDOBtn:boolean = false;
  toImpactBtn:boolean = false;
  updateVehBtn:boolean = false;
  cancelVehBtn:boolean = false;
  addAttriBtn:boolean = false;
  items1: { label: string; }[];
  itemsDialog: { label: string; }[];
  vehicleAttributeCols: { field: string; header: string; }[];
  manualInventoryList: { mnemonicCode: string; mnemonicLabel: string; mnemonicValue: string; corvetValue: number; newValue: boolean; refList: any; }[];
  showManualInventory: boolean = false;
  idoCheck:boolean;
  manualInventory = {} as IMnemonicVals;
  newValues: { label: string; value: boolean; }[];
  val: any;
  campaignDtls={
    "Associations in the process of being published": "",
    "Automatic Inventory": "",
    "Manual Inventory": "",
    "Modernization": "",
    "White": ""

  }
  cancelVehicleMgs:any;
  updateCorvetAlert:any;
  labeltranslation= {} as V1labels
  pages:String="V1"
  actionpage="action";
  actiontranslation= {} as Actionlabels;
  
  

  constructor(private vehicleListService: VehicleListService,
    private route: ActivatedRoute,
    private router: Router,
    private confirmationService: ConfirmationService,
    public datepipe: DatePipe,
    private translate: TranslateService,
    private routingService : RoutingService,
    private headerService : HeaderService
  ) { 
    this.routingService.getAccessRole().subscribe((value)=>{
      if(value.includes('RETOUCHEUR')){
        this.generateIDOBtn = true;
        this.toImpactBtn = true;
        this.updateVehBtn = true;
        this.cancelVehBtn = true;
        this.addAttriBtn = true;
      }
    })
  }

  onKeydown(event, field:string){

    this.val= event.value;
    console.log(this.val)
    if(field == 'newValues' )
    {
      console.log(event);
      if(this.val){
        this.manualInventory.newValue = true;
      }
      else 
      {
        this.manualInventory.newValue = false;
      }
    }
  }


  async ngOnInit() {
    await this.getVehicleLabel();
    await this.getActionLabel();
    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getVehicleLabel();
          await this.getActionLabel();
          this.getPathName();
        }
      })
    this.getPathName();
    this.getVehicleDetails();
    this.getCampaignDetails();
    this.getvehicleattributes();
    this.getvehicleelectronique();

    
  }

async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }

setColumnHeader(){
  const codeVehicule = this.route.snapshot.paramMap.get('vin');
  this.newValues=[
    {label:this.labeltranslation.yes, value: true},
    {label:this.labeltranslation.no, value: false}   
  ];
  this.dossierListCols = [
    { field: 'codeDossier', header:this.labeltranslation.colonnenumeroDossier },
    { field: 'libDossier', header:this.labeltranslation.colonnelibelleDossier }
  ];

  this.vehicleAttributeCols = [
    { field: 'characteristic', header:this.labeltranslation.character },
    { field: 'libClass', header:this.labeltranslation.colonneattributlibelleClasse},
    { field: 'codeValue', header:this.labeltranslation.colonneattributvaleur },
    { field: 'libValue', header:this.labeltranslation.colonneattributlibelleClasse },
    { field: 'lcdv7Nature', header:this.labeltranslation.colonneattributnature },
    { field: 'lcdv7Indicator', header: this.labeltranslation.indicator },
    { field: 'Historic', header:this.labeltranslation.historic }
  ];

  this.vehicleElectroniqueCols = [
    { field: 'codeMnemonique', header: this.labeltranslation.colonnerefElecmnemonique },
    { field: 'libMnemonique', header:this.labeltranslation.colonnerefEleclibelle },
    { field: 'valueMnemonique', header:this.labeltranslation.colonnerefElecvaleur },
    { field: 'codeProduit', header:this.labeltranslation.product},
    { field: 'indice', header: 'Indice' }
  ];

  this.programActionRecordsCols = [
    { field: 'idGamme', header: this.labeltranslation.colonneactionnumeroGamme },
    { field: 'codeMnemonique', header:this.labeltranslation.colonneactionmnemonique },
    { field: 'libMnemonique', header: this.labeltranslation.colonneactionlibelle },
    { field: 'codeProduit', header:this.labeltranslation.product },
    { field: 'valeur', header:this.labeltranslation.colonneactionvaleur},
    { field: 'indice', header: 'Indice' }
  ];

  this.updateAttributeCols = [
    { field: 'characteristic', header:this.labeltranslation.character },
    { field: 'libClass', header: this.labeltranslation.colonneattributlibelleClasse },
    { field: 'codeValue', header:this.labeltranslation.colonneattributvaleur },
    { field: 'libValue', header:this.labeltranslation.colonneattributlibelleClasse },
    { field: 'lcdv7Nature', header:this.labeltranslation.colonneattributnature },
    { field: 'lcdv7Indicator', header: this.labeltranslation.indicator },
    { field: 'user', header:this.labeltranslation.user },
    { field: 'userAction', header:this.labeltranslation.status },
    { field: 'dateMajAttr', header:this.labeltranslation.date },
  ]
  const codeChantier = window.localStorage.getItem('campaignSearch');
    this.items1 = [

      { label: this.labeltranslation.chantier+ codeChantier },
      { label: this.labeltranslation.vehicle+ codeVehicule },
      { label: 'IDO' }

    ];
    this.itemsDialog = [
      { label: this.labeltranslation.chantier+ codeChantier },
      { label: this.labeltranslation.vehicle+ codeVehicule }
    ]
}
getPathName()
{
  const codeVehicule = this.route.snapshot.paramMap.get('vin');
    this.vehicleDetails.codeChantier = window.localStorage.getItem('campaignSearch');
    this.vehicleDetails.codeVehicule = codeVehicule;

   
      this.items = [
        { label: this.actiontranslation.rechercherChantiers, url: '../campaign-management' },
        {
          label: this.actiontranslation.detailChantier + this.vehicleDetails.codeChantier,
          url: '../campaign-number/' + this.vehicleDetails.codeChantier
        },
        { label: this.actiontranslation.listeVehicules, url: '../vehicle-list' },
        { label: this.actiontranslation.detailVehicule + this.vehicleDetails.codeVehicule }
      ];

  
}
  getCampaignDetails() {
    debugger
    const codeChantier = window.localStorage.getItem('campaignSearch');
    this.vehicleListService.getCampaignDetails(codeChantier).subscribe(data => {
     // this.translate.stream(['White', 'Manual Inventory', 'Automatic Inventory', 'Associations in the process of being published',
        //  'Modernization']).subscribe(val => {
        if (data) {
          this.campaignDetails = data.campaignInfoAreaDTO;
          let campType = []
          this.concat = '';
          if (data.campaignInfoAreaDTO.natureChantier === 'L') {
            campType.push('Local');
          }
          if (data.campaignInfoAreaDTO.chantierBlanc === 1) {
            campType.push(this.campaignDtls['White']);
          }
          if (data.campaignInfoAreaDTO.manualInventory === 1) {
            campType.push(this.campaignDtls['Manual Inventory']);
            setTimeout(() => {
              if(this.vehicleDetails.suiVehicleState == "CM" && this.vehicleDetails.remonteMsg == "TRACEABILITY SAVED") {
                this.showManualInventory = true;
                this.getManualInventory();
              }
            }, 500);
          }
          if (data.campaignInfoAreaDTO.automaticInventory === 1) {
            campType.push(this.campaignDtls['Automatic Inventory']);
          }
          if (data.campaignInfoAreaDTO.associationsProcess === 1) {
            campType.push(this.campaignDtls['Associations in the process of being published']);
            if (data.campaignInfoAreaDTO.natureChantier !== 'L' && data.campaignInfoAreaDTO.chantierBlanc !== 1
              && data.campaignInfoAreaDTO.manualInventory !== 1 && data.campaignInfoAreaDTO.automaticInventory !== 1) {
            campType.push(this.campaignDtls['Modernization']);
            }
          } else if (data.campaignInfoAreaDTO.natureChantier !== 'L' && data.campaignInfoAreaDTO.chantierBlanc !== 1
            && data.campaignInfoAreaDTO.manualInventory !== 1 && data.campaignInfoAreaDTO.automaticInventory !== 1
            && data.campaignInfoAreaDTO.associationsProcess !== 1) {

            campType.push(this.campaignDtls['Modernization']);
          }
          this.concat = campType.join(', ');
        }
     // });
    });


  }

  getVehicleDetails() {
    this.vehicleListService.getVehicleDetails(JSON.stringify(this.vehicleDetails)).subscribe(data => {
      if (data) {
        this.vehicleDetails = data;
        this.vehicleDetails.trackHistoryList[0].idoCheck=true;
        this.programActionRecords = data.collectionValorisationBean;
      }
    });
  }

  getvehicleattributes() {
    this.vehicleListService.getvehicleattributes(this.vehicleDetails.codeVehicule).subscribe(data => {
      if (data) {
        this.vehicleAttributes = data;
        this.vehicleAttributes.forEach((x:any)=> {
          x.characteristic = x.natureValue + x.codeClass;
        })
      }
    });
  }

  getvehicleelectronique() {
    this.vehicleListService.getvehicleelectronique(this.vehicleDetails.codeVehicule).subscribe(data => {
      if (data) {
        this.vehicleElectronique = data;
        this.vehicleElectronique.forEach(element => {
          element.libMnemonique = element.libMnemonique.replace(/\s/g, "");
        });
      }
    });
  }

  updateVehicle() {
    if(this.updateVehBtn == false){
    this.vehicleListService.updateVehicle(this.vehicleDetails.codeVehicule).subscribe(data => {
      if (data) {
        if(data.msg) {
          this.msgs = [{ severity: 'success', detail: data.message }];
          window.location.reload();
        } else {
          this.router.navigate(['/impact', this.vehicleDetails.codeVehicule, 'VEHICULE_UPDATE']);
        }
      }
    });
  }
  }

  showCancelVehicle() {
    if(this.cancelVehBtn == false){
    this.confirmationService.confirm({
      message: this.cancelVehicleMgs,
      header: this.labeltranslation.deleteconf,
      icon: 'pi pi-info-circle',
      accept: () => {
        this.cancelVehicle();
      }
    });
  }
  }

  cancelVehicle() {
    this.vehicleListService.cancelVehicle(this.vehicleDetails.codeChantier, this.vehicleDetails.codeVehicule).subscribe(data => {
      if (data) {
        this.msgs = [{ severity: 'info', summary: 'Confirmed', detail: this.labeltranslation.recorddelete }];
        
        window.location.reload();
      }
    });
  }

  generateidofile() {
    if(this.generateIDOBtn == false){
    this.vehicleListService.generateidofile(this.vehicleDetails.codeChantier, this.vehicleDetails.codeVehicule).subscribe(
      response => this.downLoadFile(response),
      (error: any) => console.log(error)
    );
    }
  }

  downLoadFile(data: any) {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    } else {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      element.click();
    }
  }

  redirectToImpact() {
    this.router.navigate(['/impact', this.vehicleDetails.codeVehicule, 'VEHICULE_UPDATE']);
  }


  showIDODialog(rowData) {
    let idoIndex = rowData.idoIndex;
    if(rowData.idoCheck==true){
      this.vehicleHistory = false;
    }else{
      this.vehicleHistory = true;
    }
    let id = rowData.id;
     this.displayBasic = true;
     const details = this.vehicleDetails.trackHistoryList[0];
    this.vehicleListService.getIDO(details.codeChantier, details.codeVehicule, idoIndex, this.vehicleHistory, id).subscribe((data: any) => {
     
        this.message = data.message;
        console.log(this.message,"this.message");
         
    });
  }

  showSQPDialog(rowData) {
    let idoIndex = rowData.idoIndex;
    if(rowData.idoCheck==true){
      this.vehicleHistory = false;
    }else{
      this.vehicleHistory = true;
    }
    let id = rowData.id;
    const details = this.vehicleDetails.trackHistoryList[0];
    this.vehicleListService.getSQP(details.codeChantier, details.codeVehicule, idoIndex, this.vehicleHistory, id).subscribe((data: any) => {
      this.dialogData = data;
      this.displayDialog = true;
      this.itemsDialog = this.itemsDialog.splice(0, 2);
      this.itemsDialog.push({ label: 'SQP' });
    })
  }
  showIMPDialog(rowData) {
    let idoIndex = rowData.idoIndex;
    if(rowData.idoCheck==true){
      this.vehicleHistory = false;
    }else{
      this.vehicleHistory = true;
    }
    let id = rowData.id;
    const details = this.vehicleDetails.trackHistoryList[0];
    this.vehicleListService.getIMP(details.codeChantier, details.codeVehicule, idoIndex, this.vehicleHistory, id).subscribe((data: any) => {
      this.dialogData = data;
      this.displayDialog = true;
      this.itemsDialog = this.itemsDialog.splice(0, 2);
      this.itemsDialog.push({ label: 'IMP' });
    });
  }
  showTRADialog(rowData) {
    let idoIndex = rowData.idoIndex;
    if(rowData.idoCheck==true){
      this.vehicleHistory = false;
    }else{
      this.vehicleHistory = true;
    }
    let id = rowData.id;
    console.log(rowData.id,"Fetch id");
    
    const details = this.vehicleDetails.trackHistoryList[0];
    this.vehicleListService.getTRA(details.codeChantier, details.codeVehicule, idoIndex, this.vehicleHistory, id).subscribe((data: any) => {
          this.dialogData = data;
        this.displayDialog = true;
      this.itemsDialog = this.itemsDialog.splice(0, 2);
      this.itemsDialog.push({ label: 'TRA' });
    });
  }

  showAddAttribute() {
    if(this.addAttriBtn == false){
    this.displayAddAttribute = true;
    let attributeCode = "";
    this.vehicleListService.getAttributeRecords(this.vehicleDetails.codeFamille, attributeCode).subscribe((data: any) => {
      this.attributeData = data.datalist;
    });
  }
  }

  selectedAttributeVal() {
    this.attributeLabel = this.selectedAttribute.attributeLabel;
    this.refValue = '';

    this.vehicleListService.getAttributeRecords(this.vehicleDetails.codeFamille, this.selectedAttribute.attributeCode).subscribe((data: any) => {
      data.datalist.forEach(element => {
        const list = element.refList; // array of references
        this.refList = list;
      });
    });
  }

  selectedReferenceVal() {
    this.refValue = this.selectedAttrRef.refValue;
  }

  approveValuation() {
    this.displayAddAttribute = false;
    let attributeUpdateVal = {
      attributeCode : this.selectedAttribute.attributeCode,
      vin : this.vehicleDetails.codeVehicule,
      attributeValue : this.selectedAttrRef.refCode,
      nature : this.selectedAttrRef.refNature,
      codeChantier : this.vehicleDetails.codeChantier
    }
    this.vehicleListService.updateattribute(JSON.stringify(attributeUpdateVal)).subscribe((data: any) => {
      if(data && data.msg) {
        this.msgs = [{ severity: 'success', detail: data.message }];
        this.getvehicleattributes();
      }
      else if(data.message=='impact') {
        this.router.navigate(['/impact', this.vehicleDetails.codeVehicule, 'VEHICULE_UPDATE']);
      }
    
    });
  }

  closeModal() {
    this.displayAddAttribute = false;
  }

  onShowAttribute(event) {
    this.showUpdateAttribute = true;
    this.updatedAttributes = [];
    this.getAttributeHistory(event);
  }

  getManualInventory() {
    this.vehicleListService.getManualInventory(this.vehicleDetails.codeChantier, this.vehicleDetails.codeVehicule).subscribe(data=> {
      if(data) {
       this.manualInventoryList = data;
      }
    });
  }

  exportManualInventory() {
    this.vehicleListService.exportManualInventory(this.vehicleDetails.codeChantier, this.vehicleDetails.codeVehicule).subscribe(
      response => this.downLoadFile(response),
      (error: any) => console.log(error)
    );
  }

  showUpdateCorvet() {
    this.confirmationService.confirm({
      message:this.updateCorvetAlert,
      header: this.labeltranslation.delete,
      icon: 'pi pi-info-circle',
      accept: () => {
        this.updateCorvet();
      }
    });
  }

  updateCorvet() {
    let postData: IManualInventory[] = [];
    this.selectedManualInventory.forEach(element => {
      postData.push({
        "codeMnemonique": element.mnemonicCode,
        "valueMnemonique": element.mnemonicValue,
        "codeChantier": this.vehicleDetails.codeChantier,
        "codeVehicle": this.vehicleDetails.codeVehicule
      })
    });

    this.vehicleListService.updateCorvetMI(postData).subscribe(data=> {
      if(data && data.message) {
        this.msgs = [{ severity: 'success', detail: data.message }];
      }
      setTimeout(() => {
        window.location.reload();
      }, 5000);
      
    });
    
  }

  getAttributeHistory(event) {
    this.vehicleListService.getAttributeHistory(this.vehicleDetails.codeVehicule, event).subscribe(data=> {
      this.updatedAttributes = data;
      this.updatedAttributes.map((x:any)=> {
        x.dateMajAttr = this.datepipe.transform(x.dateMajAttr, 'dd/MM/yyyy HH:mm:ss')
      })
    })
  }

  async getVehicleLabel()
  {
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.pages).toPromise().then(
    (data: any) => {
     this.labeltranslation = data.datalist.record;
     this.setColumnHeader()
     this.cancelVehicleMgs=this.labeltranslation.annulerVehiculeConfirm;
     this.updateCorvetAlert=this.labeltranslation.updatecovetalert;
     this.campaignDtls['Associations in the process of being published']=this.labeltranslation.association;
     this.campaignDtls['Automatic Inventory']=this.labeltranslation.auto;
     this.campaignDtls['Manual Inventory']=this.labeltranslation.manual;
     this.campaignDtls['Modernization']=this.labeltranslation.modern;
     this.campaignDtls['White']=this.labeltranslation.white
     console.log(this.labeltranslation)
    });  
  }
}
