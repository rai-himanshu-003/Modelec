import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IsAliveComponent } from './is-alive.component';

describe('IsAliveComponent', () => {
  let component: IsAliveComponent;
  let fixture: ComponentFixture<IsAliveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IsAliveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IsAliveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
