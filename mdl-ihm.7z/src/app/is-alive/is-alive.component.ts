import { Component, OnInit } from '@angular/core';
import { IsAliveService } from './is-alive.service';

@Component({
  selector: 'app-is-alive',
  templateUrl: './is-alive.component.html',
  styleUrls: ['./is-alive.component.scss']
})
export class IsAliveComponent implements OnInit {

  isAlive: string;

  constructor(private isAliveSer: IsAliveService) { }

  ngOnInit(): void {
    this.isAliveSer.returnIsAlive().subscribe(res => {
      this.isAlive = res;
      console.log(this.isAlive, "alive status");

    },
      error => {
        this.isAlive = "Not Successful";
        console.log(error);
      }
    )
  }


}
