import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { URLService } from '../service/url.service';

@Injectable({
  providedIn: 'root'
})
export class IsAliveService {

  constructor(private httpClient: HttpClient,
    private urlService: URLService) { }

  createAuthorizationHeader(headers: HttpHeaders) {
    headers.append('Authorization', '');
  }

  returnIsAlive(): Observable<any> {
    let headers = new HttpHeaders();
    this.createAuthorizationHeader(headers);
    return this.httpClient.get<any>(this.urlService.isAlive(), {
      headers: headers
    }).pipe(
      map(
        (res: any) => {
          return res;
        }
      )
    );
  }
}


 // get(url) {
    //   let headers = new Headers();
    //   this.createAuthorizationHeader(headers);
    //   return this.httpClient.get(url, {
    //     headers: headers
    //   });
    // }