import { LOCAL_STORAGE_TOKEN_NAME } from '../constant/auth-constant';

export default class LocalStorage {
  static readValue(valueToRead: string): string {
    const token = localStorage.getItem(valueToRead);

    if (token) {
      //return JSON.parse(atob(token));
      return token;
    }
    return null;
  }

  static removeItem(valueToRemove: string) {
    localStorage.removeItem(valueToRemove);
  }

  static readToken(): string {
    return LocalStorage.readValue(LOCAL_STORAGE_TOKEN_NAME);
  }

  static removeItems(valuesToRemove: string[]) {
    valuesToRemove.forEach(function(value) {
      LocalStorage.removeItem(value);
    });
  }

  static addItem(keyOfValueToAdd: string, valueToAdd: any) {
    localStorage.setItem(keyOfValueToAdd, btoa(JSON.stringify(valueToAdd)));
  }

  
}
