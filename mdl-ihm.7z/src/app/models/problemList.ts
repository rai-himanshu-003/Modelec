
export interface IProblemList {
    codeVehicule: string;
    error: boolean;
    status?: boolean | null;
    message: {
        args: string[];
        key: string;
    };

}

export class G4Label{
chantiers:string;
creeLe	:string;	
dontValides	:string;	
enregistrerGamme	:	string;
enregistrerGammeBrouillon	:string;	
errorComplier	:string;
evaluerImpactsGamme	:string;	
famille	:string;	
reference	:string;	
atClass	:	string;
type	:string;	
libelleGamme	:string;	
mettreLibelleGamme	:string;	
missCodeFamille	:string;	
numeroGamme	:string;	
regles	:string;
revenirValideeGamme	:string;	
successValidateRules	:string;	
valeur	:string;
validerModificationsGamme	:string;	
verifierRegles	:string;	
zoneHelperAttribut	:string;	
zoneHelperFamille	:string;	
zoneHelperMnemonique	:string;	
zoneInformationsGamme	:string;	
zoneRegles:string;
assoCamp:string;
fleet:string;
vnvo:string;

validate:string;
programtype:string;
programselect:string;
createdby:string;

}


export class R1Label{
annuler	:	string;
famille	:	string;
filtrerFamille	:	string;
validerValorisationFamille	:	string;
familyErr:string;
familyassist:string;
}

export class R2label{
 atClass	:	string;
famille	:	string;
filtrerClass	:string;
filtrerValeur	:string;
valeur	:	string;
validerValorisationAttribut	:	string;
attTitle:string;
familyErr:string;
cancel:string;

}

export class R3Label{
reference	:string;
annuler	:	string;
famille	:	string;
filtrerMnemonique	:	string;
filtrerReference	:	string;
libelleReference	:	string;
mnemonique	:	string
validerValorisationMnemonique	:	string;
mnemTitle:string;
familyErr:string;
value:string;
chooseprogram:string;
refrences:string;
}


