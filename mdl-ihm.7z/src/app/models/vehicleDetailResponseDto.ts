export class ResponseDto {
    id: string;
    msg: boolean;
    message: string;
}
