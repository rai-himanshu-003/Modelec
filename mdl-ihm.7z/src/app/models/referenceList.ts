export interface IReferenceList {
    referenceVal: string;
}
