export class campaignUploadDTO {
    // static final long serialVersionUID = 1L;
    // InputStream uploadedInputStream;
     uploadedInputStream: string|any;
     listVehicles: any[];
     numeroChantier: number;
     codeChantier: string;
     libDossier: string;
     codeCP: string;
     dateCreation: Date;
     userCreation: string;
     errMessage: string;
}
