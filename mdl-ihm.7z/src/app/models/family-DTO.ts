export class FamilyList {
    codeFamily: string;
    familyLabel: string;
}
