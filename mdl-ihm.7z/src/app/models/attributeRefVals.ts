export interface IAttributeRefVals {
    refCode: string;
    refValue: string;
    refNature: string
  }
