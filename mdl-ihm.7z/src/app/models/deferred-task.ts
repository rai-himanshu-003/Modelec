export interface IDeferredTask {
    idTask: number;
    taskType: string;
    debutExec: string;
    taskState: string;
    finExec: Date;
    parameters: string;
    dateCreation: string;
    toDateCreation: string;
    fromDateCreation: string;
    userCreation: string;
    taskStateOrder: string;
    taskTypeOrder: string;
    parametersOrder: string;
    userCreationOrder: string;
    idtaskOrder: string;
    dateCreationOrder: string;
    debutExecOrder: string;
    durationOrder: string;
    duration: number;
    fromDebutExec: string;
    toDebutExec: string;
}
