export class X2labels
{
attente:string;
colonneDateDeCreation:string;
colonneDateDeLancement:string;
colonneDuree:string;
colonneEtat:string;
colonneIdentifiantDuDemandeur:string;
colonneNumeroDeBatch:string;
colonneParametres:string;
colonneTypeTraitement:string; 
demandeEntre:string;
demandePar:string;
echec:string;
enCours:string;
etatTraitement:string;
executeEntre:string; 
pagingbanneritemname:string;
pagingbanneritemsname:string;
parametres:string;
rechercherTraitement:string;
succes:string;
termine:string;
typeTraitement:string;
zoneCriteres:string; 
zoneTraitements:string;
requestdatefrom: null;
keydate:string;
to:string;
asynchronusprocesslist:string;
status: string;
requestdate: string;
choose: string
processstatus:string;
enterfilter: string;
idoedition: string;
updatevehicle: string;
}


export class X3labels
{
dateCreation:string;
dateExecution:string; 
demandeur:string;
detail:string;
duree:string;
etatTraitement:string;
fermerlabel:string;
fermertitle:string;
numeroBatch:string;
parametres:string;
typeTraitement: string;
zoneDetailTraitement:string;

}