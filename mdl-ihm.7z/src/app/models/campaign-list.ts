export class CampaignListDTO {
    cp: string;
    campaignNo: string;
    campaignNature: boolean | string;
    white: boolean;
    vin: string;
    resume: boolean;
    toRefresh: boolean;
    linkToProgram: string;
    fromDate: Date | number | string;
    toDate: Date | number | string;
    createdDate: Date | number | string;
    status: any;
    totalNoOfVehicles: number;
    noOfVehiclesToBeMade: number;
    userCreation: string;
    userCreationOrder: string;
    cpOrder: string;
    campaignNoOrder: string;
    campaignNatureOrder: string;
    statusOrder: string;
    fromDateOrder: string;
    totalNoOfVehiclesOrder: string;
    noOfVehiclesToBeMadeOrder: string;
    resumeOrder:string;
    toRefreshOrder:string;

}


export class CampaignListLabel
{ 
chantierLocal:string;
codeVehicule: string;
centreProd: string;
codeChantier :string;
dateCreation:string;
etatChantier: string;
natureChantier: string;
nbVehiculesAFaire: string;
nbVehiculesTotal: string;
rafraichir: string;
reprendre: string;
createLocal: string;
chantierLocalHelp:string;
codeVehiculeHelp:string;
dateCreationHelp:string;
etatChantierState:string;
etatChantierHelp:string;
numeroChantierHelp:string;
gammeHelp: string;
alim: string;
clos: string;
engage: string;
help: string;
initialise: string
invalide: string;
valide: string;
chantierBlanc: string
gamme: string;
numeroChantier: string;
rechercher: string;
results: string;
userCreation: string;
userCreationHelp:string;
fromDate:string;
toDate:string;
choose:string;
vinStatHelp:string;
yes:string;
no:string;
toberefresh: string;
}


export class CampLocalprogramLabel
{
chargerListeVIN	:string;
codeCp	:string;
errorCodeCpRequired	:string;
errorFilePathNotSelected:string;
errorLength	:string;
errorsDuplicates:string;
noAlphanumeric:string;
errorsFileExceed:string;
libelleDossier:string;
listeVehiculesHelp:string
local:string;
numeroDossier:string;
zoneCentreProduction:string;
zoneListeVehicules:string;
campaignArea:string;
campaignNo:string;
selectVal:string;
createlocal: string;
}

export class C3label{
annuler:string;
annulerChantierConfirm:string
associateModification:string;
associationChantier	:string
associationModif:string;
associationValid:string;
chooseAssociation:string;
closed:string;
codeVehicule:string;
codeVehiculeHelp:string;
colonneAssociation:string;
colonneCodeDossier:string;
colonneIdGamme:string;
colonneLibDossier:string;
colonneLibGamme	:string;
controler:string;
create:string;
indiceRevisionIDO:string;
modifyAssociation:string;
nbARafraichir:string;
nbARefaire:string;
nbAReprendre:string;
nbAnnule:string;
nbHorsDossier:string;
nbIDOincomplets:string;
nbModernise	:string;
nbResteAFaire:string;
operateDate	:string;
operateUser	:string;
passerChantier:string;
passerEnChantierBlancConfirm:string;
searchVehicles:string;
telechargerIDO	:string;
validate:string;
zoneChantier:string;
zoneDossier:string;
zoneGamme:string;
zoneVehicle:string;

changeToAuto:string;
changeManuConfirm:string;
changeAutoConfirm:string;
manuSuccess:string;
autoSuccess:string;
successCancel:string;
campNo:string;
campType:string;
campStatus:string;
date:string;
user:string;
manual:string;
local:string;
white:string;
auto:string;
association:string;
modern:string;
camptomanual:string;

}

export class X1Labels                  //Consistency Check Labels
{
colonneAnomalieVin:string;
colonneConflitVin:string;
colonneCriticite:string;
colonneDescriptifAnomalie:string;
colonneMnemoniqueEnConflit:string;
colonneNbTotalDeVehiculesDansLeChantier:string;
colonneNbVehiculesAvecAnomaliesError:string;
colonneNbVehiculesAvecAnomaliesWarning:string;
colonneNbVehiculesAvecConflits:string;
colonneNumeroDeLaDeuxiemeGammeB:string;
colonneNumeroDeLaPremiereGammeA:string;
colonneValeurFixeeParLaDeuxiemeGammeB:string;
colonneValeurFixeeParLaPremiereGammeA:string;
criticiteError:string;
criticiteWarning:string; 
etatChantier:string;
numeroChantier:string;
passerEnHDLesVehiculesSansActionGeneratriceDIDO	: string;
passerEnHDLesVehiculesSansActionGeneratriceDIDOHelp	:string;
validerChantierLabel: string;
validerChantierTitle: string;
zoneAnomalies: string;
zoneConflits: string;
zoneInformationsDuChantier: string;
zoneSynthese: string;
campInfo:string;
updateVehRefresh:string;
abandonCurr:string;
abandonPrev:string;
correctiveAction:string;
saveAbandon:string;
searchbyval: string;
addattribute: string;
searchbyclass: string;
}


export class G6labels  //campaign program association
{
g_help:string;
action:string;
ajouterLAssociation:string;
ajouterLAssociationHelp:string;
auteur:string;
element:string;
errorGammeNotExist:string;
errorRecordsNotSelected	: string;
etat:string;
etatChantier:string;
evaluerLesImpacts:string;
evaluerLesImpactsHelp:string;
codeDossier:string;
libelleDeGamme:string;
libelleDelement:string;
numeroChantier:string
numeroDeGamme:string;
numeroGamme: string;
reveniraLaVersionValidee:string;
reveniraLaVersionValideeHelp:string;
supprimerLesActionsSelectionnees:string;
supprimerLesActionsSelectionneesHelp:string;
validerLesModifications:string;
validerLesModificationsHelp:string;
zoneAjouterUneNouvelleAssociation:string;
zoneAssociationsExistantes:string;
zoneFinaliserLesModifications:string;
zoneInformationsDuChantier:string;
creer:string;
a_SUPPRIMER:string;
valid:string;
modif:string
selectval: string;
}

export class G8Label{
apres:string;
avant:string;
chantier:string;
colonneLibelleMnemonique:string;
colonneMnemonique:string;
colonneNumeroDeGamme:string;
colonneValeur:string;
etatVehicule:string;
fermer:string;
lcdv24:string;
vin:string;
campno:string;
filter:string;
enterfilter:string;
export:string;
product:string;

}


