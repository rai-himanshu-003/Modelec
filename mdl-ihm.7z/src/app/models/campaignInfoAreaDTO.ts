export class CampaignInfoAreaDTO{

     chkConsistency:number;
     downloadIdoCampaign:number;
     cancelCampaign:number;
     chgCampaigntoWhite:number;
     chgManualInventory:number;
     chgAutomaticInventory:number;
     campaignnumber:number; // sitenumber
     campaignStatus:string; // status
     idoRevisionNo:string; // idoGlobalIndex
     localProgram:number; // natureChantier
     whiteCampaign:number; // white
     associationsProcess:number;
     manualInventory:number; //
     automaticInventory:number;
     createdDate:Date|number|string; // dateCreation
     createdBy:string; // userCreation
     validateDate:Date|number|string; // dateValidation
     validateBy:string; // userValidation
     closedDate:Date|number|string; // dateCancellation
     closedBy:string; // userCancellation
     nbResteAFaire:number;
}