export interface ITableHeaders {
    field: string;
    header: string;    
}