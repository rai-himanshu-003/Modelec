import { IReferenceList } from './referenceList';

export interface IMnemonicVals {
    newValue: boolean;
    mnemonicCode: string;
    mnemonicLabel: string;
    mnemonicValue: string;
    corvetValue : number;
    refList: IReferenceList[];
  }
