export interface IConsistencyCheck {
    
}