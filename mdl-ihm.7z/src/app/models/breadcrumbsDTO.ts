export class Actionlabels
{
accueil:string;
admin:string;
ajouterLAssociation:string;
annulerCopie:string;
associationChantierGamme:string;
chargerListeVIN:string;
controleDeCoherence:string;
copieGamme:string;
creationChantierLocal:string;
detailChantier:string;
detailGamme:string;
detailVehicule:string;
detailVehiculeCancel:string;
editionGamme:string;
etatDesTraitementsAsynchrones:string;
gestionChantiers:string;
gestionGammes:string;
impact:string;
listeGammes:string;
listeVehicules:string;
rechercherChantiers	:string;
rechercherTraitementAsynchrones	:string;
remonteeSQP:string;
remonteeSQPUpload:string;
resultatSqp:string; 
revenirALaVersionValideeAssociations:string;
supprimerLesActionsSelectionnees:string;
traitementsAsynchrones:string;
validerCopie:string;
validerModificationsAssociations:string;
}