export class G7labels
{
alerte:string;
avertissement:string;
colonneAnomalieVin:string;
colonneConflitVin:string;
colonneCriticite:string;
colonneDescriptifAnomalie:string; 
colonneEtatVehicule:string; 
colonneMnemoniqueEnConflit:string;
colonneNumeroChantier:string;
colonneNumeroDeLaGammeA:string;	  
colonneNumeroDeLaGammeB:string;
colonneNumeroRevisionIDO:string;
colonneValeurFixeeParLaGammeA:string;
colonneValeurFixeeParLaGammeB:string;
colonneVehiculeARappeler:string;
colonneVin:string;
conflictsOverflow:string;
erreur:string;
impact:string;
impacts:string;
miseAJourVehicule:string;
modificationDAssociationChantierGamme:string;
modificationDeReglesDUneGamme:string;
origine:string;
problemsOverflow:string;
zoneAnomalies:string;
zoneConflits:string;
zoneListImpact:string;
zoneOrigineImpact:string;
error: string;
filter: string;
enterfilter:string;
export: string;
}