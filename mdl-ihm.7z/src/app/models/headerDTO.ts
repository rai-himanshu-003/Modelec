export class HeaderLabel
{ 
contact: string;
help: string;
logout: string;
portal: string;
title:string;
welcome:string;
lang:string;
english:string;
french:string;
}
