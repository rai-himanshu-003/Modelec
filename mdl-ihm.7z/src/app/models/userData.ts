

export class userData {
    id: number;
    userId: string;
    type: string;
    value: string;
}


