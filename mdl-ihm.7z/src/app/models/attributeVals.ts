import { IAttributeRefVals } from './attributeRefVals';

export interface IAttributeVals {
    attributeCode: string;
    attributeLabel: string;
    attributeValue: string;
    refList: IAttributeRefVals[];
}
