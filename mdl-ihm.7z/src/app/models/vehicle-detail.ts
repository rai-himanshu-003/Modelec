export interface IVehicleDetail {
    codeChantier: string;
    codeVehicule: string;
    numeroChantier: number;
    codeDossier: number;
    suiVehicleState: string;
    idoIndiceGlobal: string;
    chantierLocal: string;
    chantierBlanc: number;
    status: string;
    lcdv24: string;
    refresh: boolean;
    hasFolderIea: boolean;
    trackHistoryList: any;
    dossierList: any;
    disableButtons: boolean;
    incompleteDoteDtos: any;
    codeFamille: any;
    manualInventoryList: any;
    impacted: any;
    resume: any;
    canceled: any;
    inIDOComplete: any;
    remonteMsg: string;
    idoCheck:boolean;
}
