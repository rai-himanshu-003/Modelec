export class ListDto {
    label: string;
    value: string;
}
