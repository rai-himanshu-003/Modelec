export interface IConflictList {
    codeVehicule: string,
    mnemonic: string,
    idGammeB: string,
    valueB: string,
    idGammeA: string,
    valueA: string
}