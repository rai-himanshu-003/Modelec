export class SideBarLabel
{ 
admin: string;
camapignMGMT: string;
programMGMT: string;
remonteSQP: string;
asychProcessing: string;
logout:string;
collapseSidebar:string;
filter:string;
linesPerpage: string;
noOfRecs:string;
enterfilter: string;
export: string;

}
