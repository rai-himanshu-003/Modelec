export interface iRangeDetails {
    programNo: string;
    programLabel: string;
    userModifier: string;
    createdBy: string;
    updatedDate: Date | number | string;
    createdDate: Date | number | string;
    noOfCampaigns: number;
    noOfValidCampaigns: number;
    outstandingEdit: boolean;
    type: string;
    definitionValable: string;
}
