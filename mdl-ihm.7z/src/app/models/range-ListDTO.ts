export class RangeListDTO {
    programNo: string;
    programLabel: string;
    userModifier: string;
    createdBy: string;
    fromDate: Date | number | string;
    toDate: Date | number | string;
    updatedDate: Date | number | string;
    createdDate: Date | number | string;
    noOfCampaigns: number;
    noOfValidCampaigns: number;
    outstandingEdit: boolean;
    includingFamily: string;
    linkToCampaign: string;
    programNoOrder: string;
    programLabelOrder: string;
    userModifierOrder: string;
    updatedDateOrder: string;
    noOfCampaignsOrder: string;
    noOfValidCampaignsOrder: string;
    outstandingEditOrder: string;
    type: string;
    definitionValable: string;
}


//program information DTO
export class G3labels
{
    afficherLesRegles:string;
    associes:string;
    chantiers:string
    confirmDelete:string
    copierGamme:string
    creeLe:string
    dontValides	:string
    enCoursEdition:string
    libelleGamme:string
    modifierGamme:string
    numeroGamme:string
    par:string
    regles:string
    supprimerGamme:string
    validees:string
    zoneInformationsGamme:string
    yes:string
    no:string
    deleteSuccess:string
    deletfail:string;
    progType:string;
    validate: string;
}

//Search Program
export class ProgramListLabel{
    associeeAuChantier : string;
    associeeAuChantierHelp : string;
    colonneDateDeDerniereMiseAJour : string;
    colonneEncoursDEdit : string;
    colonneIdentifiantDuDernierModificateur : string;
    colonneLibelleGamme : string;
    colonneNombreDeChantiersAssocies : string;
    colonneNombreDeChantiersAssociesDansLetatValide : string;
    colonneNumeroGamme : string;
    creeModifiePar : string;
    creeModifieParHelp : string;
    creerGamme : string;
    dateMajEntre : string;
    dateMajEntreHelp : string;
    incluantLaFamille : string;
    incluantLaFamilleHelp : string;
    lancerRechercheGamme : string;
    libelleGamme : string;
    libelleGammeHelp : string;
    numeroGamme : string;
    numeroGammeHelp : string;
    zoneCriteres : string;
    dateFrom : string;
    zoneListeGammes : string;
    dateTo : string;
    
}

//copy program dto
export class G5labels
{
annulerCopie:string
associes: string
chantiers:string
copie: string
copieNom:string
creeeLe	:string 
errorMaxlength:string
gammeNom:string
numero:string
par	:string
validerCopie:string
valides	:string
zoneInformationsGammeACopier: string
zoneModalitesCopie: string
progType: string
}