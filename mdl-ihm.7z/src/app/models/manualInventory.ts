export interface IManualInventory {
    codeMnemonique: string,
    valueMnemonique: string,
    codeVehicle: string,
    codeChantier: string
}