class CenterProdDto {

     codeCp:string;

     libCp:string;
}