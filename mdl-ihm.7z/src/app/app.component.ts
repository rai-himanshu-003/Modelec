import { Component, OnInit } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';

//import { TranslateService } from '@ngx-translate/core';
import { RoutingService } from './service/routing.service';
import { AppConfig } from './app.config';
import { filter } from 'rxjs/internal/operators/filter';
import { BnNgIdleService } from 'bn-ng-idle';
import { ConfirmationService } from 'primeng/api';
import jwt_decode from 'jwt-decode';
// Un comment for local use only
import { authCodeFlowConfig } from './sso.config';
import LocalStorage from './util/local-storage';
import { LOCAL_STORAGE_USER_LOCALE, LOCAL_STORAGE_USER_NAME } from './constant/auth-constant';
import { HeaderService } from './service/header.service';
import { TranslateService } from '@ngx-translate/core';
import { userData } from './models/userData';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 username:string;
 userDetails:userData;
  token: string;
  isAlive: string;
  constructor(
    private oauthService: OAuthService,
    private routingService:RoutingService,
    private appConfig:AppConfig,
    private bnIdle : BnNgIdleService,
    private translate: TranslateService,
    private headerService:HeaderService,
    private confirmationService:ConfirmationService,
//private translateService:TranslateService

  ) {
     // code for local env
    this.oauthService.configure(authCodeFlowConfig);
   
    // Code for dev env
    //this.configureSingleSignOn();
      this.oauthService.loadDiscoveryDocumentAndLogin().then(res => {
        console.log(res);
        if (res) {
         
            this.token = this.oauthService.getAccessToken();
            let decodeToken:any;
            decodeToken= jwt_decode(this.token)
            LocalStorage.addItem(LOCAL_STORAGE_USER_NAME, decodeToken.username);
           
          window.localStorage.setItem('Auth',this.token);
          console.log(this.token);
          //let expTime= this.oauthService.getAccessTokenExpiration();
          // console.log(expTime,"EXPPIRE");
          // Saving data into BehaviouralSubject..
          this.routingService.setTokenValue(this.token);
        }
        else{
          console.log(res);
        }
        
      }).catch(err => {
        console.log("Unable to login", err);
      })
      this.oauthService.setStorage(localStorage);
  
      this.oauthService.events
        .pipe(filter(e => e.type === 'discovery_document_loaded'))
        .subscribe(_ => this.oauthService.loadUserProfile());
     

        setTimeout(() => {
          
          this.getUserData();
         
             }, 300); 
      

  }
  title = 'Modelec';

  // This method will prevent default right click
  onRightClick() {
    return false;
  }

  ngOnInit() {
   // LocalStorage.addItem( LOCAL_STORAGE_USER_LOCALE, 'en');
  //+++++++++++++++++++++++ To check User is IDLE is not+++++++++++++++++++++    
    this.bnIdle.startWatching(1200).subscribe((isTimedOut: boolean) => {
      if (isTimedOut) {
        let confirm=false;
        let reject=false
        setTimeout(() => {
          if(confirm == false && reject == false){
          this.oauthService.logOut();
          }
        }, 30000);
    this.confirmationService.confirm({
      message: ("Your session is about to expire. Press OK to continue or Cancel to Logout."),
      header: 'Session IDLE',
      icon: 'pi pi-info-circle',
      accept: () => {
        confirm=true;
        console.log("hi");
      },
      reject: () => {
        reject=true;
        setTimeout(() => {
          this.oauthService.logOut();
        }, 1000);
    }
    });
  }
  })
    
  }

  configureSingleSignOn() {
    // For local env only
    //this.oauthService.configure(authCodeFlowConfig);

    this.oauthService.redirectUri = this.appConfig.getAppConfig().redirectUri
    this.oauthService.dummyClientSecret = this.appConfig.exposedClientSecretVar; 
    this.oauthService.issuer = this.appConfig.exposedIssuerURL;
    this.oauthService.redirectUri = this.appConfig.exposedRedirectURL;
    this.oauthService.logoutUrl = this.appConfig.exposedLogoutURL;
    this.oauthService.clientId = this.appConfig.exposedClientID;
    this.oauthService.scope = this.appConfig.exposedScopeVar;

     this.oauthService.responseType = 'code';
     this.oauthService.showDebugInformation= true;
     this.oauthService.timeoutFactor = 0.9;
    


    console.log("issuer URL",this.oauthService.issuer );
    console.log("redirectUri",this.oauthService.redirectUri );
    console.log("logoutUrl",this.oauthService.logoutUrl );
    console.log("clientId",this.oauthService.clientId );
    console.log("scope",this.oauthService.scope );
    console.log("dummyClientSecret ",this.oauthService.dummyClientSecret  );
    console.log("responseType",this.oauthService.responseType );

  }
getUserData(){
  const user : any = JSON.parse(atob(LocalStorage.readValue(LOCAL_STORAGE_USER_NAME)));
      this.username = user;

      let browserLang = this.translate.getBrowserLang();
      
     this.headerService.getUserData(this.username,"LANGUAGE",browserLang).subscribe(
          (data:any) => {
             
              this.userDetails = data;
              let selectedLang = this.userDetails.value;
              LocalStorage.addItem( LOCAL_STORAGE_USER_LOCALE, selectedLang);
              console.log("user locale default lang",selectedLang)
            //  this.translate.setDefaultLang(selectedLang);
            //  this.translate.use(selectedLang);
          },
          (error: any) => console.log(error)
        )
}
}
