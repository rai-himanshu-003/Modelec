import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { RoutingService } from '../service/routing.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  role: string;

  constructor(private routingService: RoutingService) { 
    this.routingService.getAccessRole().subscribe((value) => {
      console.log(value, "Program Role")
      this.role = value;
    });
  }

  canActivate(
    _next: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
   
    if (!this.role.includes('RETOUCHEUR')) {
      return true;
    }
      return false;
  
  }
}
