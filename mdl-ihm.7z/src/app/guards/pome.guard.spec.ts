import { TestBed } from '@angular/core/testing';

import { PomeGuard } from './pome.guard';

describe('PomeGuard', () => {
  let guard: PomeGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(PomeGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
