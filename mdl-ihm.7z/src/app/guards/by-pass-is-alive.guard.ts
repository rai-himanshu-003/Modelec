import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ByPassIsAliveGuard implements CanActivate {
  accessToken:any;
  constructor(private oauthService: OAuthService,
  ) {
  }

  canActivate(
    _next: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    var hasIdToken = this.oauthService.hasValidIdToken();
    var hasAccessToken = null


    if (hasIdToken && hasAccessToken) {
      return true
    }
    return false
  }

}
