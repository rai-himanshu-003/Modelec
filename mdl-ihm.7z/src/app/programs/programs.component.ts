import { Component, OnInit } from '@angular/core';
import { CampaignNumberService } from '../service/campaign-number.service';
import { Router } from '@angular/router';
import { GetSelectedCPService } from '../service/getCP.service';
import { RoutingService } from '../service/routing.service';
import { C3label } from '../models/campaign-list';
import { HeaderService } from '../service/header.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-programs',
  templateUrl: './programs.component.html',
  styleUrls: ['./programs.component.css']
})
export class ProgramsComponent implements OnInit {
  prog: any[];
  valid: boolean;
  publish: number;
  vehSearchRecords: any[]=[];
  isDataAvailable : boolean= false;
  validated1: boolean;
  checked :boolean = true;
  campaignData: string;
  value: boolean;
  validateValue = 'VALIDE';
  campaignValue: string;
  associate: boolean;
  check: string;
  formval: any[];
  formData: any[];
  sortResult: any;
  progNumber: any;
  modifyButton:string;
  pages:string="C3"
  labeltranslation= {} as C3label
  modify:boolean=true;
  role:any;
  constructor(
    private campaignNumberService: CampaignNumberService,
    public router: Router,
    private getSelectedCPService: GetSelectedCPService,
    private routingService: RoutingService,
    private headerService:HeaderService,
    private translate: TranslateService
  ) { 
    
  }

  ngOnInit(): void {
    this.getCampaignLabel();
    this.headerService.notifyObservable.subscribe(res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          this.getCampaignLabel();
        }
      })
    this.routingService.getAccessRole().subscribe(value=>{
      this.role=value;
    }
      );
     this.campaignData = window.localStorage.getItem('campaignSearch');
    
      this.getCheckData(this.validateValue);
    this.storeCampaignCode();
    // this.prog = [
    //   { field: 'number', header: 'Program Number' },
    //   { field: 'label', header: 'Program label' },
    //   { field: 'association', header: 'Association' },
    // ];
  }

  storeCampaignCode() {

    // Set the value of Vin number in variable
    this.campaignData = window.localStorage.getItem('campaignSearch');

    // If value is not null or undefined then call get data
    if (this.campaignData != null && this.campaignData != undefined) {
      window.localStorage.setItem('campaignData', this.campaignData);
      this.getRecordsFromDB();
    }

  }

  getRecordsFromDB() {
    const campaignNumber: string = window.localStorage.getItem('campaignData');

    if (campaignNumber != null && campaignNumber != undefined) {
     
      this.campaignValue = campaignNumber;
      console.log(this.campaignValue);
    } else {
      console.log('no Vin found');
    }
   
    this.campaignNumberService.getRecords(this.campaignValue).subscribe(
      (data: any) => {
        
        this.publish = data.datalist.campaignInfoAreaDTO.associationsProcess;
        if (this.publish == 1) {
          this.isDataAvailable = true;
        } else if (this.publish == 0) {
          this.isDataAvailable = false;
        }
        this.modifyButton=data.datalist.campaignInfoAreaDTO.campaignStatus;
        console.log("mod", this.modifyButton)
        if(this.role.includes('RETOUCHEUR')){
          this.modify=true;
        }
        else if(this.modifyButton ==="INITIALISE" || this.modifyButton ==="VALIDE" || this.modifyButton ==="ENGAGE"){
          this.modify=false;
        }
        console.log(this.vehSearchRecords);
      }
    );
  }

  getassociate(checkBox) {
    this.check = checkBox;
    console.log(this.check);
    this.campaignNumberService.getCheckBoxData(this.campaignData, "MODIF").subscribe(

      (data: any) => {
        this.vehSearchRecords = data.datalist;
        for (let i = 0; i < data.datalist.length; i++) {
          for (const key in data.datalist[i]) {
            if (key === 'codeDossier' && data.datalist[i][key] === null) {
              data.datalist[i][key] = 'Campaign';
            }
          }
        }
      }
    );
  }
  getCheckData(checkBox) {
    this.check = checkBox;
    console.log(this.check);
    this.campaignNumberService.getCheckBoxData(this.campaignData, "VALIDE").subscribe(
      (data: any) => {
        this.vehSearchRecords = data.datalist;
        for (let i = 0; i < data.datalist.length; i++) {
          for (const key in data.datalist[i]) {
            if (key === 'codeDossier' && data.datalist[i][key] === null) {
              data.datalist[i][key] = 'Campaign';
            }
          }
        }
      }
    );
  }

  goToPage(_event, pNumber) {
    this.progNumber = pNumber;
    console.log(this.progNumber);
    this.getSelectedCPService.setselectedProgramNumber(this.progNumber);
    const progSearch = window.localStorage.getItem('progSearch');
    if (progSearch != null && progSearch != undefined) {
      window.localStorage.removeItem('progSearch');
      window.localStorage.setItem('progSearch', this.progNumber);
    } else {
      window.localStorage.setItem('progSearch', this.progNumber);
    }

    if (this.progNumber) {
      this.router.navigate(['/program-list', pNumber]);
      console.log(pNumber);
    }
    
  }

  modifyAssociate() {
    if(this.modify===false){
    this.router.navigate(['/associations', this.campaignData]);
    console.log('qawsedrftgy', this.campaignData);
    }
  }

  getCampaignLabel()
{
let lang= this.headerService.getlang(); 
this.headerService.getLabel(lang, this.pages).subscribe(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
}
