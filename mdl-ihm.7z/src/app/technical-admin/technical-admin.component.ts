import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technical-admin',
  templateUrl: './technical-admin.component.html',
  styleUrls: ['./technical-admin.component.css']
})
export class TechnicalAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
