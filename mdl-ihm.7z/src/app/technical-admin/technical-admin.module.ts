import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';

import { TechadminManagementRoutingModule } from './technical-admin-routing.module';
import { TechnicalAdminComponent } from './technical-admin.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    CalendarModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    TechadminManagementRoutingModule
  ],
  declarations: [TechnicalAdminComponent]
})
export class TechnicalAdminManagementModule {}
