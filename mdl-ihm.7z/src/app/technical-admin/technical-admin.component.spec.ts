import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalAdminComponent } from './technical-admin.component';

describe('TechnicalAdminComponent', () => {
  let component: TechnicalAdminComponent;
  let fixture: ComponentFixture<TechnicalAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TechnicalAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnicalAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
