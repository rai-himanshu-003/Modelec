import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnicalAdminComponent } from './technical-admin.component';

const routes: Routes = [
  {
    path: '',
    component: TechnicalAdminComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TechadminManagementRoutingModule { }
