import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConsistencyCheckRoutingModule } from './consistency-check-routing.module';
import { ConsistencyCheckComponent } from './consistency-check.component';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TranslateModule } from '@ngx-translate/core';
import { DialogModule } from 'primeng/dialog';
import { ListboxModule } from 'primeng/listbox';


@NgModule({
  declarations: [ConsistencyCheckComponent],
  imports: [
    CommonModule,
    FormsModule,
    ConsistencyCheckRoutingModule,
    PanelModule,
    TableModule,
    CheckboxModule,
    ButtonModule,
    RadioButtonModule,
    BreadcrumbModule,
    TranslateModule,
    DialogModule,
    ListboxModule
  ]
})
export class ConsistencyCheckModule { }
