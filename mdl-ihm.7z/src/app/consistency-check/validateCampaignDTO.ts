export class checkConsistencyRequestDto  {
    
    vehicleList:any;
    forceHd :boolean;
    vehicleRefresh :boolean;
    codeChantier :string|any;

}