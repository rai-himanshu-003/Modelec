import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { IAttributeRefVals } from '../models/attributeRefVals';
import { IAttributeVals } from '../models/attributeVals';
import { IConflictList } from '../models/conflictList';
import { IProblemList, R2label } from '../models/problemList';
import { ITableHeaders } from '../models/tableHeaders';
import { IVehicleDetail } from '../models/vehicle-detail';
import { ConsistencyCheckService } from '../service/consistency-check.service';
import { RoutingService } from '../service/routing.service';
import * as lodash from 'lodash';
import { checkConsistencyRequestDto  } from './validateCampaignDTO';
import { X1Labels } from '../models/campaign-list';
import {HeaderService} from '../service/header.service';
import { Actionlabels } from '../models/breadcrumbsDTO';
export class IVehChantair {
  "chantierVehicleList": IChantierVehicleList;
  "codeChantier": string
}

export class IChantierVehicleList {
  key: any;
  value: string
}

@Component({
  selector: 'app-consistency-check',
  templateUrl: './consistency-check.component.html',
  styleUrls: ['./consistency-check.component.scss']
})
export class ConsistencyCheckComponent implements OnInit {

  disableAddAttrBtn: boolean = true;

  campaign_number: string;
  campaign_status: string;

  totalVehicles: string;
  vWarnings: string;
  vErrors: string;
  vConflicts: string;
  // checkbox variables
  switchToHD: boolean = false;
  switchToHD1: boolean = true;
  updateVehicle: boolean = false;
  updateVehicle1: boolean = true;
  validateCampaign: boolean= true;

  updateVehicleClck: boolean;
  switchToHDClck: boolean;

  // variable to store data from API
  consistencyChkData: any;
  problemsList: IProblemList[];
  conflictList: IConflictList[];
  mnemonic: string;
  idGammeA: string;
  idGammeB: string;
  valueA: string;
  valueB: string;

  waitingsqpRadio: string = 'error.chantier.process.waitingsqp';
  attributeBtn: string = 'error.gamme.runner.noValueForLcdvAttribute';
  attributeBtn1: string = 'error.chantier.process.missingattributes';

  breadCrubmsItems = [];
  vehicleDetails: IVehicleDetail = {} as IVehicleDetail;
  checkConsistencyRequestDto:checkConsistencyRequestDto = {} as checkConsistencyRequestDto;

  anomoliesTable: ITableHeaders[];
  conflictsTable: ITableHeaders[];
  vehicleVIN: string;

  // to display attribute assistant pop up
  displayBasic = false;
  attributeData: IAttributeVals[];
  selectedAttribute: IAttributeVals;
  refList: IAttributeRefVals[];
  selectedAttrRef: IAttributeRefVals;
  attributeLabel: string;
  refValue: string;
  searchTerm: string;
  arrAttribute = [];
  arrAttrRef = [];
  familyCode: string;

  selectedValues: any[] = [];
  attributeCode: string;
  refCode: string;
  natureRef: string;

  // array to send Selected campaing to abandon
  chantierVehicleList = [];
  abandonCampStatus = [];
  allCheckChantiers = [];
  checkAllInThisCamp: boolean | undefined = false;
  checkAllInThisCamp1: boolean | undefined = false;
  chantierVehicleObj: any;
  CheckConsistencyResponseDto: any;
  switchToHDArr: any[]=[];
  updateVehArr: any[]=[];
  pages="X1";
  labeltranslation= {} as  X1Labels;
  actionpage="action";
  actiontranslation= {} as Actionlabels;
  page:string="R2"
  attributelabeltranslation= {} as R2label
 

  flag: boolean;

  

  constructor(private router: Router,
    private translate: TranslateService,
    private routingService: RoutingService,
    private consistencyStatus: ConsistencyCheckService,
    private headerService: HeaderService) { }

  async ngOnInit() {
    
    console.log(this.updateVehicle);

    await this.getConsistencyChkLabel();
    await this.getAttributeAsssitantLabel();
    await this.getActionLabel();
    this.vehicleDetails.codeChantier = window.localStorage.getItem('campaignSearch');
    this.getPathName();

    // to load the data for first time
    this.displayData();
    this.getTableHeader();
        

    this.headerService.notifyObservable.subscribe(async res=>
      {
        if(res.refresh)
        {
          this.translate.currentLang=res.lang;
          await this.getConsistencyChkLabel();
          await this.getActionLabel();
          await this.getAttributeAsssitantLabel();
          this.getTableHeader();
          this.getPathName();
        }
      })
  }


async getConsistencyChkLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.pages).toPromise().then(
  (data: any) => {
   this.labeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
getTableHeader()
{
  this.anomoliesTable = [
    { field: 'codeVehicule', header: this.labeltranslation.zoneAnomalies},
    { field: 'error', header: this.labeltranslation.colonneCriticite },
    { field: 'message.key', header: this.labeltranslation.colonneDescriptifAnomalie }
  ];

  this.conflictsTable = [
    { field: 'codeVehicule', header: this.labeltranslation.colonneConflitVin },
    { field: 'mnemonic', header: this.labeltranslation.colonneMnemoniqueEnConflit },
    { field: 'idGammeB', header: this.labeltranslation.colonneNumeroDeLaDeuxiemeGammeB },
    { field: 'valueB', header: this.labeltranslation.colonneValeurFixeeParLaPremiereGammeA },
    { field: 'idGammeA', header: this.labeltranslation.colonneNumeroDeLaPremiereGammeA },
    { field: 'valueA', header: this.labeltranslation.colonneValeurFixeeParLaDeuxiemeGammeB}
  ]
}
async getActionLabel()
{
  let lang= this.headerService.getlang(); 
  await this.headerService.getLabel(lang, this.actionpage).toPromise().then(
    (data: any) => {
     this.actiontranslation = data.datalist.record;
     console.log(this.actiontranslation)
    });  
  }
getPathName()
{
  this.breadCrubmsItems = [
    { label: this.actiontranslation.rechercherChantiers, url: '../campaign-management' },
    {
      label: this.actiontranslation.detailChantier + this.vehicleDetails.codeChantier,
      url: '../campaign-number/' + this.vehicleDetails.codeChantier
    },
    { label: this.actiontranslation.controleDeCoherence, url: '/consistency-check' },
  ];

}
async getAttributeAsssitantLabel()
{
let lang= this.headerService.getlang(); 
await this.headerService.getLabel(lang, this.page).toPromise().then(
  (data: any) => {
   this.attributelabeltranslation = data.datalist.record;
   console.log(this.labeltranslation)
  });  
}
  clickSwitchToHD(switchToHD, updateVehicle) {
    this.switchToHDClck = switchToHD;
    if (switchToHD == true && updateVehicle==true) 
    {
      this.validateCampaign = false;
    }
    else {
      this.validateCampaign = true;
    }
  }

  clickUpdateVehicle(updateVehicle, switchToHD) {
   
    this.updateVehicleClck = updateVehicle;
    if (updateVehicle == true && switchToHD==true)
     {
      this.validateCampaign = false;
    }
    else {
      this.validateCampaign = true;
    }
  }

  // When all the check boxes are selected from header
  allCheckBox(event, selectedStatus) {
    this.checkAllInThisCamp1 = false;
    this.checkAllInThisCamp = false;
    if (event.target.checked) {
      this.allCheckChantiers = [];
      if (selectedStatus == 1) {
        this.checkAllInThisCamp = true;
        this.problemsList.forEach(e => {
          if (e.message.key == "error.chantier.process.waitingsqp") {
            e.status = true;
            let vehicleVin = e.codeVehicule;
            let codeChantierVal = this.vehicleDetails.codeChantier;
            this.abandonCampStatus = [vehicleVin, codeChantierVal]
            this.allCheckChantiers.push(this.abandonCampStatus);
          }
        })
        this.checkAllInThisCamp1 = false;
      }
      else if (selectedStatus == 2) {
        this.allCheckChantiers = [];
        this.checkAllInThisCamp1 = true;
        this.problemsList.forEach(e => {
          if (e.message.key == "error.chantier.process.waitingsqp") {
            e.status = false;
            let vehicleVin = e.codeVehicule;
            let codeChantierVal = e.message.args[1];
            this.abandonCampStatus = [vehicleVin, codeChantierVal]
            this.allCheckChantiers.push(this.abandonCampStatus);
          }
        })
        this.checkAllInThisCamp = false;
      }
    } else {
      this.problemsList.forEach(e => {
        e.status = undefined;
      })
    }
  }
  // When all the check boxes are selected from header

  // When single checkbox are selected
  toggleCheckbox(_eveCheckedStatus, rowData, selectedStatus, _codeChantier) {
    if (rowData.status == undefined) {
      (selectedStatus == 1) ? rowData.status = false : rowData.status = true;
    }

    if (_eveCheckedStatus) {
      rowData.status = !rowData.status;
    } else {
      rowData.status = undefined;
    }

    let index = this.chantierVehicleList.findIndex(e => {
      return e[0] == rowData.message.args[0];
    })
    if (index >= 0) {
      this.chantierVehicleList.splice(index, 1);
    }
    debugger
    if (_eveCheckedStatus && selectedStatus == 1) {
      let vehicleVin = rowData.codeVehicule;
      let codeChantierVal = this.vehicleDetails.codeChantier
      this.abandonCampStatus = [vehicleVin, codeChantierVal]
      this.chantierVehicleList.push(this.abandonCampStatus);
      console.log(codeChantierVal, "status 1");


    } else if (_eveCheckedStatus && selectedStatus == 2) {
      let vehicleVin = rowData.codeVehicule;
      let codeChantierVal = rowData.message.args[1];
      this.abandonCampStatus = [vehicleVin, codeChantierVal]
      this.chantierVehicleList.push(this.abandonCampStatus);
      console.log(codeChantierVal, "status 2");
    }
  }
  // When single checkbox are selected

  // Common function to display data in Anomolies Table
  commonConsistencyData(consistencyChkData) {
    this.campaign_number = consistencyChkData.campaignInfoSynthesisAreaDTO.campaignNumber;
    this.campaign_status = consistencyChkData.campaignInfoSynthesisAreaDTO.campaignStatus;
    this.totalVehicles = consistencyChkData.campaignInfoSynthesisAreaDTO.totalNoVehicle;
    this.vWarnings = consistencyChkData.campaignInfoSynthesisAreaDTO.totalNoVehicleWarning;
    this.vConflicts = consistencyChkData.campaignInfoSynthesisAreaDTO.totalNoVehicleConflict;
    this.vErrors = consistencyChkData.campaignInfoSynthesisAreaDTO.totalNoVehicleError;
    this.problemsList = consistencyChkData.problemsList;
    this.conflictList = consistencyChkData.conflictList;

    if (this.problemsList && this.problemsList.length == 0) {
      this.validateCampaign = false;
    } else {
      this.validateCampaign = true;
    }

    if (this.problemsList) {
      this.problemsList.forEach(e => {

        if (e.message.key == "error.gamme.runner.missingIEA" || e.message.key == "error.chantier.process.waitrefresh") {
          this.updateVehicle1 = false; // checkbox for refresh is enabaled
        }

        if (e.message.key == "error.chantier.process.nonidogenerator") {
          this.switchToHD1 = false; //checkbox for Switch to HD is enabled
        }

        if (e.message.key.includes("error.gamme.runner.missinghard" || "error.gamme.runner.noautovalue"
          || "error.chantier.process.missingattributes" || "error.gamme.runner.noValueForLcdvAttribute" ||
          'error.gamme.runner.noLcdvAttributeFoundForCentralAttribute' || "error.gamme.runner.conflict"
          || "error.gamme.runner.missingkey")) {
          this.conflictList.forEach(v => {
            if (v.codeVehicule == e.codeVehicule) {
              this.idGammeA = v.idGammeA;
              this.idGammeB = v.idGammeB;
              this.valueA = v.valueA;
              this.valueB = v.valueB;
            }
          })
        }
      })
    }
  }
  // Common function to display data in Anomolies Table

  saveAbandons() {
    // to check if checkboxes are checked from header or individual checkboxes selected
    let obj = {};
    if (this.checkAllInThisCamp || this.checkAllInThisCamp1) {
      this.allCheckChantiers.forEach((x, i) => {
        return obj[i] = x
      })
    } else {
      this.chantierVehicleList.forEach((x, i) => {
        return obj[i] = x
      })
    }
    // to check if checkboxes are checked from header or individual checkboxes selected

    this.chantierVehicleObj = {
      "chantierVehicleList": [obj],
      "codeChantier": this.vehicleDetails.codeChantier
    }

    this.consistencyStatus.saveAbandonsCampaignRecords(this.chantierVehicleObj).subscribe((data: any) => {
      this.consistencyChkData = data;
      this.commonConsistencyData(this.consistencyChkData);
      // empty the array after successful response
      if (data) {
        obj = {};
      }
    })
  }

  displayData() {
    let codeChantier = this.vehicleDetails.codeChantier;
    this.consistencyStatus.getConsistencyRecords(codeChantier).subscribe((consistencyData: any) => {
      this.consistencyChkData = consistencyData;
      console.log(this.consistencyChkData);
      this.CheckConsistencyResponseDto = lodash.cloneDeep(consistencyData);
      console.log(this.CheckConsistencyResponseDto,"Cloning");
      
      this.commonConsistencyData(this.consistencyChkData);
      console.log(this.problemsList, "from displayData");

      if (this.problemsList) {
        this.problemsList.forEach(e => {
  
          if (e.message.key == "error.gamme.runner.missingIEA" || e.message.key == "error.chantier.process.waitrefresh") {
            this.updateVehArr.push(e.codeVehicule);
          }
  
          if (e.message.key == "error.chantier.process.nonidogenerator") {
            this.switchToHDArr.push(e.codeVehicule);
          }
        })
        }
        let val:any;
        val = {
          "forceHdAr" : this.switchToHDArr,
          "vehRefAr" : this.updateVehArr
        }
        this.checkConsistencyRequestDto.vehicleList= val;
        this.checkConsistencyRequestDto.codeChantier=this.vehicleDetails.codeChantier;
    });
  }

  validateCampaignMthd() {
    if(this.validateCampaign==false){
    this.checkConsistencyRequestDto.forceHd=this.switchToHD;
    this.checkConsistencyRequestDto.vehicleRefresh=this.updateVehicle;
    console.log(this.checkConsistencyRequestDto);
    
  // this.consistencyStatus.validateConsistencyRecord(this.checkConsistencyRequestDto)
   this.consistencyStatus.validateConsistencyRecord(this.vehicleDetails.codeChantier, this.switchToHD, this.updateVehicle)
      .subscribe((data: any) => {
        this.consistencyChkData = data;
        this.commonConsistencyData(this.consistencyChkData);
        
        if(data){
          this.router.navigate(['/status-async'])
        }
      })
    this.routingService.setValidateAsynParameter(true); 
    } 
  }

  vehicleRedirect(codevehicle: number) {
    this.router.navigate(['/vehicle-detail', codevehicle])
  }

  getAttributeValue(rowData) {
    this.displayBasic = true;
    this.vehicleVIN = rowData.codeVehicule;
    let attrCode = "";
    let nature = "";
    let reference = ""
    this.consistencyStatus.getVehicleFamilyDataRecord(this.vehicleVIN).subscribe((data: any) => {
      this.familyCode = data.codeFamily;

      if (this.familyCode) {
        this.consistencyStatus.addAttributeButtonRecord(this.familyCode,attrCode,reference,nature).subscribe((data: any) => {
          this.attributeData = data;
        })
      }
    })
  }

  closeMnemonicModal() { this.displayBasic = false; }

  selectedAttributeVal() {
    this.attributeCode = this.selectedAttribute.attributeCode;
    this.attributeLabel = this.selectedAttribute.attributeLabel;
    this.refValue = '';
    this.refCode = '';
    this.arrAttribute.push(this.selectedAttribute);
    let nature = "P,D"

    if(this.refValue == ""){
      this.disableAddAttrBtn = true;
    }

    this.consistencyStatus.addAttributeButtonRecord(this.familyCode,this.attributeCode,this.refCode,nature).subscribe((data: any) => {
      data.forEach(ele => {
        this.refList = ele.refList;
      })
    })
    if (this.attributeCode && this.refCode) {
      this.disableAddAttrBtn = false;
    }
  }

  // attribute pop function for referenceValues on RHS
  selectedReferenceVal() {
    this.refCode = this.selectedAttrRef.refCode;
    this.refValue = this.selectedAttrRef.refValue;
    this.natureRef = this.selectedAttrRef.refNature;
    this.arrAttrRef.push(this.selectedAttrRef);

    if (this.attributeCode && this.refCode) {
      this.disableAddAttrBtn = false;
    }
  }

  approveValuation() {
    if (this.attributeCode && this.refCode) {
      this.consistencyStatus.getAttributeRecords(this.vehicleDetails.codeChantier, this.vehicleVIN, this.attributeCode, this.refCode, this.natureRef)
        .subscribe((data: any) => {
          this.consistencyChkData = data;
          this.commonConsistencyData(this.consistencyChkData);
        })
    }
    this.displayBasic = false;
  }
}