import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import jwt_decode, { } from 'jwt-decode'
import { MessageService } from 'primeng/api';
import { RoutingService } from '../../../service/routing.service';
import * as versionConfig from './versionConfig.json';
import {HeaderService} from '../../../service/header.service'
import {HeaderLabel} from '../../../models/headerDTO';
import LocalStorage from 'src/app/util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from 'src/app/constant/auth-constant';
import { userData } from 'src/app/models/userData';
//import { getLocaleNumberSymbol } from '@angular/common';
// import { BnNgIdleService } from 'bn-ng-idle';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    providers: [MessageService],
})
export class HeaderComponent implements OnInit {
    pushRightClass = 'push-right';
    welcomeMessage: string;
    username: string;
    response: any;
    responseMsg: boolean;
    versionNo: string;
    tokenId: any;
    tokenAccess: any;
    decoded: any;
    countTimer:any;
    headerTime:any;
    timeLeft: number = 10;
    interval;
    timeLeftinmin: string;
    lang= this.translate.getBrowserLang();
    pages="header";
    labeltranslation= {} as HeaderLabel;
    updatedUser:userData;
    userDeatils:userData;

    constructor(
        private translate: TranslateService,
        public router: Router,
        public messageService: MessageService,
        private routingService:RoutingService,
        private headerService:HeaderService,

        // private bnIdle:BnNgIdleService
    ) {
        this.getVersion();

        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
        setTimeout(() => {
          
            this.getHeaderLabels(this.pages);
            this.getUserData(); 
                }, 400);   
        setTimeout(() => {
            
            let value = window.localStorage.getItem('Auth');
            this.tokenAccess = value;
            console.log(this.tokenAccess,"flagValid")
            this.decoded = jwt_decode(this.tokenAccess)
            this.welcomeMessage = ` ${this.decoded.firstname ? this.decoded.firstname : ''} ` + `${this.decoded.lastname ? this.decoded.lastname : ''} (${this.decoded.roles})`;
            console.log(this.welcomeMessage);
            
                 this.routingService.setUserID(this.decoded.username);
           this.checkRole(this.decoded.roles)
           
                }, 250);
          
        
        
    }

     ngOnInit() {
       
          
            
        // this.routingService.getTokenValue().subscribe((value) => {
        //let langs=this.translate.getBrowserLang();
            
    }
  getcurrentLang()
  {
      return this.translate.currentLang;
  }
    getlang(language)
    {
     //let language = this.translate.getBrowserLang();
    let currentlang;
    if(language=="en")
    {
    currentlang="en_GB"
    }
    else if(language=="fr")
    {
        currentlang="fr_FR"
    }
    else if(language=="de")
    {
        currentlang=="de_DE"
    }
    else if(language=="")
    {
        currentlang="en_GB"
    }
    return currentlang;
    }
    
    getHeaderLabels( pages)
    {

        let lang= this.headerService.getlang();
        console.log("lang",lang);
        this.headerService.getLabel(lang, pages).subscribe(
            (data: any) => {
                
             this.labeltranslation = data.datalist.record;
             
             console.log("welcome message ",this.labeltranslation.welcome)
            });
    }

    startTimer():any {
        this.timeLeft=10;
      this.interval = setInterval(() => {
        if(this.timeLeft > 0) {
          this.timeLeft--;
          var date = new Date(null);
          date.setSeconds(this.timeLeft); // specify value for SECONDS here
          this.timeLeftinmin = date.toISOString().substr(11, 8);
         } 
      },1000)
    }

    checkRole(roles){
        console.log(roles,"After");
        this.routingService.setAccessRole(roles);
    }
  
    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    changeLang(language: string) {

       // this.translate.use(language);
        LocalStorage.addItem('userLocale',language);
        //this.headerService.notifyOther({refresh: true})
        this.headerService.notifyOther({refresh: true,lang:language});
        this.getHeaderLabels(this.pages);
        this. updateUserLang(language);
    }
    
    // This will clear the message after 5 sec
    clearMessage() {
        setTimeout(() => {
            this.messageService.clear();
        }, 5000);
    }

    getVersion() {
      this.versionNo = "v" + versionConfig.ihmVersion;
    }

    updateUserLang(lang){
        const user : any = JSON.parse(atob(LocalStorage.readValue(LOCAL_STORAGE_USER_NAME)));
        let tempObj = {} as  userData;
        tempObj.id = this.userDeatils.id;
        tempObj.userId = user
        tempObj.type = "LANGUAGE";
        tempObj.value = lang;
        //let selectedLang = lang;
        //this.translate.use(selectedLang);
        
        this.headerService.updateUserData(tempObj).subscribe(
            (data:any) => {
                console.log(data);
                this.response = data.responseList;
                console.log(this.response);
                this.responseMsg = this.response[0].msg;

                if(this.responseMsg == true){
                    
                     this.messageService.add({ severity: 'success', summary: "Success", 
                     detail: `The Language for user ${tempObj.userId} is updated to ${tempObj.value}` });
                }
                else if (this.responseMsg == false) {
                    this.messageService.add({severity: 'error', summary: "Error Message",
                    detail: `<div>The Language for user ${tempObj.userId} is not updated</div>`
                    })
                }
                this.clearMessage();
                //this.ngOnInit();
            },
            (error:any) => console.log(error)
        )
    }

     // Get required User details
     getUserData(){
    
        const user : any = JSON.parse(atob(LocalStorage.readValue(LOCAL_STORAGE_USER_NAME)));
        this.username = user;

        let browserLang = this.translate.getBrowserLang();
        
       this.headerService.getUserData(this.username,"LANGUAGE",browserLang).subscribe(
            (data:any) => {
               
                this.userDeatils = data;
               // let selectedLang = this.userDeatils.value;
                // this.translate.setDefaultLang(selectedLang);
                // this.translate.use(selectedLang);
            },
            (error: any) => console.log(error)
          )
    }
}