import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../guards/auth.guard';
import { PomeGuard } from '../guards/pome.guard';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,

        children: [
            { path: '', redirectTo: 'campaign-management', pathMatch: 'prefix' },

            {
                path: 'campaign-management',
                loadChildren: () => import('../campaign-management/campaign-management.module')
                .then(m => m.CampaignManagementModule)
            },

            {
                path: 'campaign-information',
                loadChildren: () => import('../campaign-information/campaign-information.module')
                .then(m => m.CampaignInformationModule)
            },

            {
                path: 'program-management',
                loadChildren: () => import('../program-management/program-management.module')
                .then(m => m.ProgramManagementModule),
            },

            {
                path: 'program-management/:code',
                loadChildren: () => import('../program-management/program-management.module')
                .then(m => m.ProgramManagementModule),
            },

            {
                path: 'status-async',
                loadChildren: () => import('../status-async/status-async.module')
                .then(m => m.StatusManagementModule),
                canActivate:[AuthGuard]
            },

            {
                path: 'sqp-uplift',
                loadChildren: () => import('../sqp-uplift/sqp-uplift.module')
                .then(m => m.SQPManagementModule)
            },

            {
                path: 'technical-admin',
                loadChildren: () => import('../technical-admin/technical-admin.module')
                .then(m => m.TechnicalAdminManagementModule)
            },
            

            {
                path: 'campaign-number/:code',
                loadChildren: () => import('../campaign-number/campaign-number.module')
                    .then(m => m.CampaignNumberModule)
            },

            {
                path: 'program-list/:Program_number',
                loadChildren: () => import('../program-list/program-list.module')
                    .then(m => m.ProgramListModule)
            },

            {
                path: 'copy-program/:Program_number',
                loadChildren: () => import('../copy-program/copy-program.module')
                    .then(m => m.CopyProgramModule),
                    canActivate:[AuthGuard, PomeGuard]
            },

            {
                path: 'change-program',
                loadChildren: () => import('../change-program/change-program.module')
                    .then(m => m.ChangeProgramModule),
                    canActivate:[AuthGuard, PomeGuard]
            },
            {
                path: 'impact/:impactVal/:input',
                loadChildren: () => import('../impact/impact.module')
                    .then(m => m.ImpactModule),
                    canActivate:[AuthGuard]
            },
            {
                path: 'impact-details/:codeVeh',
                loadChildren: () => import('../impact-details/impact-details.module')
                    .then(m => m.ImpactDetailsModule),
                    canActivate:[AuthGuard]
            },

            {
                path: 'associations/:code',
                loadChildren: () => import('../associations/associations.module')
                    .then(m => m.AssociationsModule),
                    canActivate:[AuthGuard]
            },

            {
                path: 'vehicle-list',
                loadChildren: () => import('../vehicle-list/vehicle-list.module')
                    .then(m => m.VehicleListModule)
            },

            {
                path: 'vehicle-list/:key/:value',
                loadChildren: () => import('../vehicle-list/vehicle-list.module')
                    .then(m => m.VehicleListModule)
            },

            {
                path: 'vehicle-detail/:vin',
                loadChildren: () => import('../vehicle-detail/vehicle-detail.module')
                    .then(m => m.VehicleDetailModule)
            },
            {
                path: 'consistency-check',
                loadChildren: () => import('../consistency-check/consistency-check.module')
                    .then(m => m.ConsistencyCheckModule),
                    canActivate:[AuthGuard]
            },
            
            {
                path: 'impact/:vin',
                loadChildren: () => import('../impact/impact.module')    
                .then(m => m.ImpactModule),
                    canActivate:[AuthGuard]
            },

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
