import { Component, OnInit } from '@angular/core';
// import { IsAliveService } from '../is-alive/is-alive.service';

@Component({
    selector: 'app-layout',
    templateUrl: './layout.component.html',
    styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

    collapedSideBar: boolean;
    isAlive: string;
    isAliveStatus: boolean;

    constructor() { }

    ngOnInit() {
        // this.isAliveSer.returnIsAlive().subscribe(res => {
        //     this.isAlive = res;
        //     this.isAliveStatus = true;
        //     console.log(this.isAlive, "alive status");

        // },
        //     error => {
        //         this.isAliveStatus = false;
        //         this.isAlive = "Not Successful";
        //         console.log(error);
        //     }
        // )
    }

    receiveCollapsed($event) {
        this.collapedSideBar = $event;
    }

    onRightClick() {
        return false;
    }


}
