import { HttpClient } from "@angular/common/http";
import { TranslateLoader } from "@ngx-translate/core";
import { Observable } from "rxjs";
import { AppConfig } from './app.config';


export class TranslationHttpLoader implements TranslateLoader {
  constructor(private httpClient: HttpClient, private appConfig: AppConfig) {}

  /**
   * Gets the translations from the server
   */
  public getTranslation(lang: string): Observable<Object> {
    if (lang === null) {
      lang === "en";
    }
    
    let url = this.appConfig.getAppConfig().apiURL + "/component/getComponentLabels/";

    let observer1 = new Observable(observer => {
      this.httpClient.get(url+lang).subscribe(
        data => {
          observer.next(data);
          observer.complete();
        },
        error => {
          console.log(error);
        }
      );
    });
    return observer1;
  }
}
