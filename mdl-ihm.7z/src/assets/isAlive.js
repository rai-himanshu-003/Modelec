isAliveFn([
    {
    "url": "https://modelec-dev.psa-cloud.com/mdlmicroservice/alive/isAlive"
    }
    ]);